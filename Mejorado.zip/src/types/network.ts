export type TipoDispositivo =
  | 'firewall'
  | 'router'
  | 'switch'
  | 'access_point'
  | 'servidor'
  | 'ups'
  | 'onu'
  | 'radioenlace'
  | 'modem'
  | 'otro';

export type EstadoDispositivo =
  | 'operativo'
  | 'en_mantenimiento'
  | 'averiado'
  | 'retirado'
  | 'propuesto';

export type RolUsuario = 'administrador' | 'tecnico' | 'consulta';

export type EstadoDiseno = 'actual' | 'propuesto';

export type TipoMantenimiento = 'preventivo' | 'correctivo' | 'inspeccion';

export type EstadoMantenimiento =
  | 'programado'
  | 'en_curso'
  | 'completado'
  | 'cancelado';

export interface Ubicacion {
  id_ubicacion: string;
  sede: string;
  piso: number | null;
  ambiente: string;
}

export interface Interfaz {
  id_interfaz: string;
  id_dispositivo: string;
  nombre: string;
  mac: string;
  ip: string;
  id_subred?: string;
  asignacion: 'estatica' | 'dhcp';
}

export interface Dispositivo {
  id_dispositivo: string;
  nombre: string;
  tipo: TipoDispositivo;
  marca: string;
  modelo: string;
  numero_serie?: string;
  id_ubicacion: string;
  ubicacion?: Ubicacion;
  estado: EstadoDispositivo;
  fecha_instalacion: string;
  mantenimiento_cada_meses: number | null;
  ultimo_mantenimiento?: string;
  observaciones?: string;
  interfaces?: Interfaz[];
}

export interface Vlan {
  id_vlan: string;
  numero: number;
  nombre: string;
  funcion: string;
  estado_diseno: EstadoDiseno;
  rango_ip?: string;
  gateway?: string;
  num_equipos?: number;
}

export interface Subred {
  id_subred: string;
  red: string;
  id_vlan?: string;
  vlan?: Vlan;
  gateway: string;
  funcion: string;
  estado_diseno: EstadoDiseno;
}

export interface Mantenimiento {
  id_mantenimiento: string;
  id_dispositivo: string;
  dispositivo_nombre?: string;
  id_usuario: string;
  usuario_nombre?: string;
  tipo: TipoMantenimiento;
  descripcion: string;
  estado: EstadoMantenimiento;
  fecha_programada: string;
  fecha_realizada?: string | null;
  fecha_registro: string;
  observaciones_cierre?: string;
}

export interface Usuario {
  id_usuario: string;
  nombre: string;
  email: string;
  rol: RolUsuario;
  activo: boolean;
  fecha_registro: string;
  ultimo_acceso?: string;
}

export interface AuditoriaLog {
  id_auditoria: number;
  fecha: string;
  id_usuario_app: string;
  usuario_nombre: string;
  tabla: string;
  operacion: 'INSERT' | 'UPDATE' | 'DELETE' | 'EXECUTE';
  id_registro: string;
  detalles: string;
}

export interface PruebaPacketTracer {
  id: number;
  desde: string;
  comando: string;
  ipDestino: string;
  servicio: string;
  v1Esperado: string;
  v2Esperado: string;
  motivo: string;
  resultado?: 'permitido' | 'bloqueado' | 'unidireccional';
}
