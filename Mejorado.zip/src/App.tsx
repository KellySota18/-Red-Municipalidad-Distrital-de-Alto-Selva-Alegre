/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { MntnLandingView } from './components/MntnLandingView';
import { Dashboard } from './components/Dashboard';
import { DeviceInventory } from './components/DeviceInventory';
import { AclSimulatorView } from './components/AclSimulatorView';
import { PerformanceBenchmarkView } from './components/PerformanceBenchmarkView';
import { VlanTopologyView } from './components/VlanTopologyView';
import { MaintenanceManager } from './components/MaintenanceManager';
import { PowerShellConsole } from './components/PowerShellConsole';
import { DocumentationViewer } from './components/DocumentationViewer';
import { UserAuditView } from './components/UserAuditView';
import {
  INITIAL_DISPOSITIVOS,
  INITIAL_UBICACIONES,
  INITIAL_VLANS,
  INITIAL_SUBREDES,
  INITIAL_MANTENIMIENTOS,
  INITIAL_USUARIOS,
  INITIAL_AUDITORIA,
} from './data/mockData';
import {
  Dispositivo,
  Ubicacion,
  Vlan,
  Subred,
  Mantenimiento,
  Usuario,
  AuditoriaLog,
  RolUsuario,
} from './types/network';
import { Github, Shield, MapPin, Heart } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('landing');
  const [rolActual, setRolActual] = useState<RolUsuario>('administrador');

  // Core Data Stores
  const [dispositivos, setDispositivos] = useState<Dispositivo[]>(INITIAL_DISPOSITIVOS);
  const [ubicaciones] = useState<Ubicacion[]>(INITIAL_UBICACIONES);
  const [vlans] = useState<Vlan[]>(INITIAL_VLANS);
  const [subredes] = useState<Subred[]>(INITIAL_SUBREDES);
  const [mantenimientos, setMantenimientos] = useState<Mantenimiento[]>(INITIAL_MANTENIMIENTOS);
  const [usuarios, setUsuarios] = useState<Usuario[]>(INITIAL_USUARIOS);
  const [auditoria, setAuditoria] = useState<AuditoriaLog[]>(INITIAL_AUDITORIA);

  // Handlers with audit logging
  const handleAddDispositivo = (disp: Dispositivo) => {
    setDispositivos((prev) => [disp, ...prev]);
    const log: AuditoriaLog = {
      id_auditoria: Date.now(),
      fecha: new Date().toISOString().replace('T', ' ').substring(0, 19),
      id_usuario_app: 'usr-1',
      usuario_nombre: 'Ing. Carlos Mendoza (Admin)',
      tabla: 'infra.dispositivos',
      operacion: 'INSERT',
      id_registro: `${disp.id_dispositivo} (${disp.nombre})`,
      detalles: `Registro de nuevo activo: ${disp.marca} ${disp.modelo} en catálogo`,
    };
    setAuditoria((prev) => [log, ...prev]);
  };

  const handleUpdateDispositivo = (disp: Dispositivo) => {
    setDispositivos((prev) =>
      prev.map((d) => (d.id_dispositivo === disp.id_dispositivo ? disp : d))
    );
    const log: AuditoriaLog = {
      id_auditoria: Date.now(),
      fecha: new Date().toISOString().replace('T', ' ').substring(0, 19),
      id_usuario_app: 'usr-1',
      usuario_nombre: 'Ing. Carlos Mendoza (Admin)',
      tabla: 'infra.dispositivos',
      operacion: 'UPDATE',
      id_registro: `${disp.id_dispositivo} (${disp.nombre})`,
      detalles: `Actualización de ficha técnica y parámetros de dispositivo`,
    };
    setAuditoria((prev) => [log, ...prev]);
  };

  const handleAddMantenimiento = (mant: Mantenimiento) => {
    setMantenimientos((prev) => [mant, ...prev]);
    const log: AuditoriaLog = {
      id_auditoria: Date.now(),
      fecha: new Date().toISOString().replace('T', ' ').substring(0, 19),
      id_usuario_app: 'usr-1',
      usuario_nombre: 'Ing. Carlos Mendoza (Admin)',
      tabla: 'infra.mantenimientos',
      operacion: 'INSERT',
      id_registro: `${mant.id_mantenimiento} (${mant.dispositivo_nombre})`,
      detalles: `Programación de orden ${mant.tipo}: ${mant.descripcion.substring(0, 45)}...`,
    };
    setAuditoria((prev) => [log, ...prev]);
  };

  const handleUpdateMantenimiento = (mant: Mantenimiento) => {
    setMantenimientos((prev) =>
      prev.map((m) => (m.id_mantenimiento === mant.id_mantenimiento ? mant : m))
    );
    const log: AuditoriaLog = {
      id_auditoria: Date.now(),
      fecha: new Date().toISOString().replace('T', ' ').substring(0, 19),
      id_usuario_app: 'usr-1',
      usuario_nombre: 'Tec. Raúl Huamán',
      tabla: 'infra.mantenimientos',
      operacion: 'UPDATE',
      id_registro: `${mant.id_mantenimiento}`,
      detalles: `Cambio de estado a [${mant.estado}]. Bitácora: ${mant.observaciones_cierre || 'En proceso'}`,
    };
    setAuditoria((prev) => [log, ...prev]);
  };

  const handleAddUsuario = (user: Usuario) => {
    setUsuarios((prev) => [...prev, user]);
    const log: AuditoriaLog = {
      id_auditoria: Date.now(),
      fecha: new Date().toISOString().replace('T', ' ').substring(0, 19),
      id_usuario_app: 'usr-1',
      usuario_nombre: 'Ing. Carlos Mendoza (Admin)',
      tabla: 'infra.usuarios',
      operacion: 'INSERT',
      id_registro: user.email,
      detalles: `Alta de usuario con rol: ${user.rol}`,
    };
    setAuditoria((prev) => [log, ...prev]);
  };

  const handleUpdateUsuarioRol = (id: string, nuevoRol: RolUsuario) => {
    setUsuarios((prev) =>
      prev.map((u) => (u.id_usuario === id ? { ...u, rol: nuevoRol } : u))
    );
    const log: AuditoriaLog = {
      id_auditoria: Date.now(),
      fecha: new Date().toISOString().replace('T', ' ').substring(0, 19),
      id_usuario_app: 'usr-1',
      usuario_nombre: 'Ing. Carlos Mendoza (Admin)',
      tabla: 'infra.usuarios',
      operacion: 'UPDATE',
      id_registro: id,
      detalles: `Modificación de privilegios de acceso a [${nuevoRol}]`,
    };
    setAuditoria((prev) => [log, ...prev]);
  };

  return (
    <div className="min-h-screen bg-[#0B1D26] text-slate-100 flex flex-col font-sans selection:bg-[#FBD784] selection:text-[#0B1D26]">
      {/* Global Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        rolActual={rolActual}
        setRolActual={setRolActual}
      />

      {/* Main Content Area */}
      {activeTab === 'landing' ? (
        <MntnLandingView
          dispositivos={dispositivos}
          vlans={vlans}
          onNavigate={(t) => setActiveTab(t)}
        />
      ) : (
        <>
          <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
            {activeTab === 'dashboard' && (
              <Dashboard
                dispositivos={dispositivos}
                vlans={vlans}
                mantenimientos={mantenimientos}
                onNavigate={(t) => setActiveTab(t)}
              />
            )}

            {activeTab === 'dispositivos' && (
              <DeviceInventory
                dispositivos={dispositivos}
                ubicaciones={ubicaciones}
                rolActual={rolActual}
                onAddDispositivo={handleAddDispositivo}
                onUpdateDispositivo={handleUpdateDispositivo}
              />
            )}

            {activeTab === 'acls' && <AclSimulatorView />}

            {activeTab === 'rendimiento' && <PerformanceBenchmarkView />}

            {activeTab === 'vlans' && (
              <VlanTopologyView vlans={vlans} subredes={subredes} />
            )}

            {activeTab === 'mantenimiento' && (
              <MaintenanceManager
                mantenimientos={mantenimientos}
                dispositivos={dispositivos}
                rolActual={rolActual}
                onAddMantenimiento={handleAddMantenimiento}
                onUpdateMantenimiento={handleUpdateMantenimiento}
              />
            )}

            {activeTab === 'terminal' && (
              <PowerShellConsole
                dispositivos={dispositivos}
                vlans={vlans}
                subredes={subredes}
                mantenimientos={mantenimientos}
                usuarios={usuarios}
              />
            )}

            {activeTab === 'documentacion' && <DocumentationViewer />}

            {activeTab === 'usuarios' && (
              <UserAuditView
                usuarios={usuarios}
                auditoria={auditoria}
                rolActual={rolActual}
                onAddUsuario={handleAddUsuario}
                onUpdateUsuarioRol={handleUpdateUsuarioRol}
              />
            )}
          </main>

          {/* Workspace Footer with MDASA Official Logo */}
          <footer className="mt-16 border-t border-white/[0.08] bg-[#0B1D26]/90 backdrop-blur-md py-8 text-xs text-slate-400">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-12 rounded-xl bg-gradient-to-b from-white/95 to-slate-200 p-1 shadow-md ring-1 ring-white/20 shrink-0 flex items-center justify-center">
                  <img
                    src="/assets/aistudio/escudo_municidad_af859de9.jpg"
                    alt="Escudo MDASA"
                    className="w-full h-full object-contain shrink-0"
                  />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white tracking-[-0.01em]">
                      Municipalidad Distrital de Alto Selva Alegre
                    </span>
                    <span className="text-slate-600">·</span>
                    <span className="text-emerald-400 font-medium">Arequipa, Perú</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Subgerencia de Tecnologías de la Información y Comunicación · Proyecto Red v1.0
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-4">
                <a
                  href="https://github.com/KellySota18/-Red-Municipalidad-Distrital-de-Alto-Selva-Alegre"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-white/[0.08] text-slate-300 hover:text-white transition-all duration-150 active:scale-[0.97]"
                >
                  <Github className="w-4 h-4" />
                  <span>KellySota18 / -Red-MDASA</span>
                </a>
                <span className="text-slate-600">·</span>
                <span className="font-mono text-[11px] text-[#FBD784] px-2 py-0.5 rounded bg-slate-900 border border-white/[0.06] tabular-nums">
                  Build 2026.11
                </span>
              </div>
            </div>
          </footer>
        </>
      )}
    </div>
  );
}
