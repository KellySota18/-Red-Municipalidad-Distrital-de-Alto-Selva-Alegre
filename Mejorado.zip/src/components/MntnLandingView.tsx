import React, { useState } from 'react';
import {
  ArrowRight,
  ArrowDown,
  Instagram,
  Twitter,
  Github,
  Shield,
  Server,
  Zap,
  Layers,
  Terminal,
  Activity,
  CheckCircle2,
  ExternalLink,
} from 'lucide-react';
import { Dispositivo, Vlan } from '../types/network';

interface MntnLandingViewProps {
  dispositivos: Dispositivo[];
  vlans: Vlan[];
  onNavigate: (tab: string) => void;
}

export const MntnLandingView: React.FC<MntnLandingViewProps> = ({
  dispositivos,
  vlans,
  onNavigate,
}) => {
  const [activeSection, setActiveSection] = useState<'start' | '01' | '02' | '03'>('start');

  const scrollTo = (id: string, section: 'start' | '01' | '02' | '03') => {
    setActiveSection(section);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen bg-[#0B1D26] text-white overflow-hidden selection:bg-[#FBD784] selection:text-[#0B1D26]">
      {/* Floating Left Social Bar (From MNTN Figma Design) */}
      <div className="fixed left-6 top-1/2 -translate-y-1/2 z-40 hidden xl:flex flex-col items-center gap-6 text-xs text-white/70">
        <span className="font-semibold tracking-[0.2em] -rotate-90 origin-center text-white/60 mb-6 uppercase text-[11px]">
          SÍGUENOS
        </span>
        <a
          href="https://instagram.com"
          target="_blank"
          rel="noopener noreferrer"
          className="p-1 hover:text-[#FBD784] transition-colors"
          title="Instagram"
        >
          <Instagram className="w-4 h-4" />
        </a>
        <a
          href="https://twitter.com"
          target="_blank"
          rel="noopener noreferrer"
          className="p-1 hover:text-[#FBD784] transition-colors"
          title="Twitter"
        >
          <Twitter className="w-4 h-4" />
        </a>
        <a
          href="https://github.com/KellySota18/-Red-Municipalidad-Distrital-de-Alto-Selva-Alegre"
          target="_blank"
          rel="noopener noreferrer"
          className="p-1 hover:text-[#FBD784] transition-colors"
          title="GitHub"
        >
          <Github className="w-4 h-4" />
        </a>
      </div>

      {/* Floating Right Slider Bar (From MNTN Figma Design) */}
      <div className="fixed right-8 top-1/2 -translate-y-1/2 z-40 hidden xl:flex flex-col items-end gap-3 text-xs font-semibold tabular-nums">
        <button
          onClick={() => scrollTo('mntn-hero', 'start')}
          className={`group flex items-center gap-3 transition-colors ${
            activeSection === 'start' ? 'text-white' : 'text-white/40 hover:text-white'
          }`}
        >
          <span>Inicio</span>
          <span
            className={`w-0.5 transition-all duration-300 ${
              activeSection === 'start' ? 'h-8 bg-white shadow-sm shadow-white' : 'h-4 bg-white/30'
            }`}
          />
        </button>
        <button
          onClick={() => scrollTo('section-01', '01')}
          className={`group flex items-center gap-3 transition-colors ${
            activeSection === '01' ? 'text-white' : 'text-white/40 hover:text-white'
          }`}
        >
          <span>01</span>
          <span
            className={`w-0.5 transition-all duration-300 ${
              activeSection === '01' ? 'h-8 bg-[#FBD784] shadow-sm shadow-[#FBD784]' : 'h-4 bg-white/30'
            }`}
          />
        </button>
        <button
          onClick={() => scrollTo('section-02', '02')}
          className={`group flex items-center gap-3 transition-colors ${
            activeSection === '02' ? 'text-white' : 'text-white/40 hover:text-white'
          }`}
        >
          <span>02</span>
          <span
            className={`w-0.5 transition-all duration-300 ${
              activeSection === '02' ? 'h-8 bg-[#FBD784] shadow-sm shadow-[#FBD784]' : 'h-4 bg-white/30'
            }`}
          />
        </button>
        <button
          onClick={() => scrollTo('section-03', '03')}
          className={`group flex items-center gap-3 transition-colors ${
            activeSection === '03' ? 'text-white' : 'text-white/40 hover:text-white'
          }`}
        >
          <span>03</span>
          <span
            className={`w-0.5 transition-all duration-300 ${
              activeSection === '03' ? 'h-8 bg-[#FBD784] shadow-sm shadow-[#FBD784]' : 'h-4 bg-white/30'
            }`}
          />
        </button>
      </div>

      {/* HERO SECTION */}
      <section
        id="mntn-hero"
        className="relative min-h-[92vh] flex flex-col items-center justify-center px-4 sm:px-8 text-center pt-12 pb-24"
      >
        {/* Mountain Atmosphere Gradients & Horizon */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0B1D26]/40 via-[#0B1D26]/70 to-[#0B1D26] z-0 pointer-events-none" />

        {/* Ambient Glow & Mountain Silhouette Layer */}
        <div className="absolute top-0 inset-x-0 h-[650px] bg-gradient-to-b from-indigo-950/30 via-slate-900/40 to-transparent pointer-events-none" />
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[900px] h-[550px] bg-[#FFA34D]/10 rounded-full blur-[140px] pointer-events-none" />

        {/* Mountain Backdrop Illustration (Misti Volcano & Andes Atmosphere) */}
        <div className="absolute bottom-0 inset-x-0 h-96 opacity-30 bg-gradient-to-t from-[#0B1D26] via-transparent to-transparent pointer-events-none flex items-end justify-center">
          <svg
            className="w-full h-72 text-slate-900/60 fill-current"
            viewBox="0 0 1440 320"
            preserveAspectRatio="none"
          >
            <path d="M0,224L80,208C160,192,320,160,480,170.7C640,181,800,235,960,229.3C1120,224,1280,160,1360,128L1440,96L1440,320L1360,320C1280,320,1120,320,960,320C800,320,640,320,480,320C320,320,160,320,80,320L0,320Z" />
          </svg>
        </div>

        {/* Center Hero Content */}
        <div className="relative z-10 max-w-4xl mx-auto space-y-6 animate-in fade-in duration-700">
          {/* MNTN Pre-Title Tag with Yellow Line */}
          <div className="inline-flex items-center gap-4 text-[#FBD784] text-xs font-bold uppercase tracking-[0.25em]">
            <span className="w-16 h-0.5 bg-[#FBD784]" />
            <span>GUÍA DE TELECOMUNICACIONES & REDES</span>
          </div>

          {/* Majestic MNTN Serif Heading */}
          <h1 className="font-serif text-4xl sm:text-6xl md:text-7xl lg:text-[76px] font-bold text-white tracking-tight leading-[1.1]">
            Preparado para la cumbre y la seguridad de la red
          </h1>

          <p className="text-slate-300 text-sm sm:text-base max-w-[65ch] mx-auto leading-relaxed font-sans">
            Sistema de Inventario, Gestión de Telecomunicaciones y Simulación de Seguridad ACL
            para la infraestructura tecnológica de la Municipalidad Distrital de Alto Selva Alegre.
          </p>

          {/* Quick Action Badges */}
          <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => onNavigate('dashboard')}
              className="px-6 py-3 rounded-full bg-[#FBD784] hover:bg-[#ffe39d] text-[#0B1D26] font-bold text-xs tracking-wider uppercase transition-all duration-150 active:scale-[0.97] shadow-xl shadow-[#FBD784]/20 flex items-center gap-2"
            >
              <span>Abrir Panel de Control</span>
              <ArrowRight className="w-4 h-4 text-[#0B1D26]" />
            </button>
            <button
              onClick={() => onNavigate('acls')}
              className="px-6 py-3 rounded-full bg-slate-900/80 hover:bg-slate-800 text-white font-medium text-xs tracking-wider uppercase border border-white/10 transition-all duration-150 active:scale-[0.97] flex items-center gap-2"
            >
              <Shield className="w-4 h-4 text-[#FBD784]" />
              <span>Simulador ACL</span>
            </button>
          </div>

          {/* MNTN "Scroll Down" Indicator */}
          <div className="pt-12">
            <button
              onClick={() => scrollTo('section-01', '01')}
              className="group inline-flex items-center gap-2 text-xs font-semibold text-white/80 hover:text-[#FBD784] transition-colors"
            >
              <span>Desplazar hacia abajo</span>
              <ArrowDown className="w-4 h-4 text-[#FBD784] group-hover:translate-y-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* STORY SECTION 01: INVENTARIO (Right-aligned visual, Left-aligned text) */}
      <section
        id="section-01"
        className="relative max-w-6xl mx-auto px-6 sm:px-12 py-24 border-t border-white/[0.04]"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Text Column: 7 cols */}
          <div className="lg:col-span-7 space-y-6 relative">
            {/* Ghost Background Number "01" */}
            <span className="font-serif font-extrabold text-[140px] sm:text-[190px] text-white/[0.07] absolute -top-24 -left-6 select-none pointer-events-none z-0">
              01
            </span>

            <div className="relative z-10 space-y-4">
              <div className="inline-flex items-center gap-4 text-[#FBD784] text-xs font-bold uppercase tracking-[0.25em]">
                <span className="w-16 h-0.5 bg-[#FBD784]" />
                <span>INICIO / CATÁLOGO DE ACTIVOS</span>
              </div>

              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight leading-[1.15]">
                ¿Qué equipamiento resguarda la Municipalidad?
              </h2>

              <p className="text-slate-300 text-sm leading-relaxed max-w-[65ch]">
                Consolidación completa del inventario físico y lógico: Firewall central FortiGate 90G,
                router MikroTik L009UiGS-RM, conmutadores administrables TP-Link Omada PoE de 24 puertos,
                switches Huawei de distribución en los pisos municipales, terminación de fibra óptica Misticom
                (200 Mbps simétrico) y servidores MEF del SIAF y Rentas.
              </p>

              <div className="pt-2">
                <button
                  onClick={() => onNavigate('dispositivos')}
                  className="group inline-flex items-center gap-2 text-sm font-bold text-[#FBD784] hover:text-[#ffe49d] transition-all"
                >
                  <span>Explorar inventario completo</span>
                  <ArrowRight className="w-4 h-4 text-[#FBD784] group-hover:translate-x-1.5 transition-transform" />
                </button>
              </div>
            </div>
          </div>

          {/* Right Card Column: 5 cols */}
          <div className="lg:col-span-5 relative">
            <div className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-white/[0.08] shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
                <div className="flex items-center gap-2">
                  <Server className="w-5 h-5 text-[#FBD784]" />
                  <span className="font-mono font-bold text-xs text-white">DATACENTER PISO 4</span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  {dispositivos.length} Activos
                </span>
              </div>

              <div className="space-y-2.5">
                {dispositivos.slice(0, 4).map((d) => (
                  <div
                    key={d.id_dispositivo}
                    className="p-3 rounded-xl bg-[#0B1D26]/80 border border-white/[0.06] flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-mono font-bold text-[#FBD784] block">{d.nombre}</span>
                      <span className="text-[11px] text-slate-400">{d.modelo}</span>
                    </div>
                    <span className="font-mono text-cyan-400 text-[11px]">
                      {d.interfaces?.[0]?.ip || '—'}
                    </span>
                  </div>
                ))}
              </div>

              <div className="pt-2 flex justify-between text-[11px] text-slate-400 border-t border-white/[0.06]">
                <span>Paginación 20 por página</span>
                <span className="text-emerald-400">100% Catálogo</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* STORY SECTION 02: SEGURIDAD ACL (Left-aligned visual, Right-aligned text) */}
      <section
        id="section-02"
        className="relative max-w-6xl mx-auto px-6 sm:px-12 py-24 border-t border-white/[0.04]"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Visual Column: 5 cols */}
          <div className="lg:col-span-5 order-2 lg:order-1 relative">
            <div className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-white/[0.08] shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-emerald-400" />
                  <span className="font-mono font-bold text-xs text-white">REGLAS PERIMETRALES</span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#FBD784]/20 text-[#FBD784] border border-[#FBD784]/30">
                  Deny by Default
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-[#0B1D26] border border-white/[0.06] font-mono text-xs space-y-2">
                <div className="text-slate-400">! Inspección Stateful FortiGate 90G</div>
                <div className="text-emerald-400 flex items-center justify-between">
                  <span>permit tcp AREA_X SERVERS eq 443</span>
                  <span className="text-[10px] font-sans">SIAF TLS</span>
                </div>
                <div className="text-emerald-400 flex items-center justify-between">
                  <span>permit udp AREA_X SERVERS eq 53</span>
                  <span className="text-[10px] font-sans">DNS Local</span>
                </div>
                <div className="text-rose-400 flex items-center justify-between">
                  <span>deny tcp AREA_X SERVERS eq 80</span>
                  <span className="text-[10px] font-sans">Bloqueo P5</span>
                </div>
                <div className="text-rose-400 flex items-center justify-between">
                  <span>deny tcp any any eq 23</span>
                  <span className="text-[10px] font-sans">Telnet P8</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-900/40 text-xs text-emerald-300">
                <strong>18 de 18 pruebas Packet Tracer aprobadas:</strong> Aislamiento de capas 3 y 4
                comprobado al 100%.
              </div>
            </div>
          </div>

          {/* Right Text Column: 7 cols */}
          <div className="lg:col-span-7 order-1 lg:order-2 space-y-6 relative">
            {/* Ghost Background Number "02" */}
            <span className="font-serif font-extrabold text-[140px] sm:text-[190px] text-white/[0.07] absolute -top-24 -left-6 select-none pointer-events-none z-0">
              02
            </span>

            <div className="relative z-10 space-y-4">
              <div className="inline-flex items-center gap-4 text-[#FBD784] text-xs font-bold uppercase tracking-[0.25em]">
                <span className="w-16 h-0.5 bg-[#FBD784]" />
                <span>SEGURIDAD / CONTROL DE ACCESO</span>
              </div>

              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight leading-[1.15]">
                Filtrado riguroso: solo tráfico autorizado llega a los servidores
              </h2>

              <p className="text-slate-300 text-sm leading-relaxed max-w-[65ch]">
                Implementación de la Matriz de Políticas P1 a P8 con denegación por defecto. Se clausura
                terminantemente el protocolo Telnet en texto plano (P8) y se exige cifrado TLS 1.3
                HTTPS (P5) para las conexiones de ejecución presupuestaria del Estado y recaudación tributaria.
              </p>

              <div className="pt-2">
                <button
                  onClick={() => onNavigate('acls')}
                  className="group inline-flex items-center gap-2 text-sm font-bold text-[#FBD784] hover:text-[#ffe49d] transition-all"
                >
                  <span>Probar simulador de paquetes ACL</span>
                  <ArrowRight className="w-4 h-4 text-[#FBD784] group-hover:translate-x-1.5 transition-transform" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* STORY SECTION 03: RENDIMIENTO & TOPOLOGÍA (Right-aligned visual, Left-aligned text) */}
      <section
        id="section-03"
        className="relative max-w-6xl mx-auto px-6 sm:px-12 py-24 border-t border-white/[0.04]"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Text Column: 7 cols */}
          <div className="lg:col-span-7 space-y-6 relative">
            {/* Ghost Background Number "03" */}
            <span className="font-serif font-extrabold text-[140px] sm:text-[190px] text-white/[0.07] absolute -top-24 -left-6 select-none pointer-events-none z-0">
              03
            </span>

            <div className="relative z-10 space-y-4">
              <div className="inline-flex items-center gap-4 text-[#FBD784] text-xs font-bold uppercase tracking-[0.25em]">
                <span className="w-16 h-0.5 bg-[#FBD784]" />
                <span>MAPA / ARQUITECTURA & RENDIMIENTO</span>
              </div>

              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight leading-[1.15]">
                Segmentación en 6 VLANs y latencia p95 ≤ 500 ms
              </h2>

              <p className="text-slate-300 text-sm leading-relaxed max-w-[65ch]">
                Rediseño de la red plana hacia 6 VLANs independientes (VLAN 10 Servidores, 20 Impresoras,
                30 Área X, 40 Área Y, 50 Serenazgo y 99 Gestión Out-of-Band). Optimización integral
                con índices PostgreSQL GIN trigram que reducen las consultas a 0.18 ms, pool de conexiones y compresión de red.
              </p>

              <div className="pt-2">
                <button
                  onClick={() => onNavigate('rendimiento')}
                  className="group inline-flex items-center gap-2 text-sm font-bold text-[#FBD784] hover:text-[#ffe49d] transition-all"
                >
                  <span>Ver telemetría de rendimiento y topología</span>
                  <ArrowRight className="w-4 h-4 text-[#FBD784] group-hover:translate-x-1.5 transition-transform" />
                </button>
              </div>
            </div>
          </div>

          {/* Right Visual Column: 5 cols */}
          <div className="lg:col-span-5 relative">
            <div className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-white/[0.08] shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
                <div className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-amber-400" />
                  <span className="font-mono font-bold text-xs text-white">SLA & BENCHMARK</span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 tabular-nums">
                  p95: 58 ms
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-[#0B1D26] border border-white/[0.06]">
                  <span className="text-slate-400 block text-[11px]">VLANs IEEE 802.1Q</span>
                  <span className="font-mono font-bold text-xl text-white">6 Segmentos</span>
                </div>
                <div className="p-3 rounded-xl bg-[#0B1D26] border border-white/[0.06]">
                  <span className="text-slate-400 block text-[11px]">Consultas BD</span>
                  <span className="font-mono font-bold text-xl text-emerald-400">&lt; 0.4 ms</span>
                </div>
                <div className="p-3 rounded-xl bg-[#0B1D26] border border-white/[0.06]">
                  <span className="text-slate-400 block text-[11px]">Uso CPU Servidor</span>
                  <span className="font-mono font-bold text-xl text-purple-400">46% Máx</span>
                </div>
                <div className="p-3 rounded-xl bg-[#0B1D26] border border-white/[0.06]">
                  <span className="text-slate-400 block text-[11px]">Tasa de Errores</span>
                  <span className="font-mono font-bold text-xl text-emerald-400">0.00%</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#0B1D26]/80 border border-white/[0.06] flex items-center justify-between text-xs">
                <span className="text-slate-400">Compresión de Respuestas JSON:</span>
                <span className="font-mono font-bold text-[#FBD784]">~82% de Ahorro</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* MNTN EDITORIAL FOOTER (Fidelity to Figma Community Template) */}
      <footer className="relative max-w-6xl mx-auto px-6 sm:px-12 py-16 border-t border-white/[0.08]">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 items-start">
          {/* Left Brand Column: 6 cols */}
          <div className="md:col-span-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-12 rounded-xl bg-white p-1 shadow-md ring-1 ring-white/20 shrink-0 flex items-center justify-center">
                <img
                  src="/assets/aistudio/escudo_municidad_af859de9.jpg"
                  alt="MDASA Logo"
                  className="w-full h-full object-contain shrink-0"
                />
              </div>
              <span className="font-serif text-2xl font-black text-white tracking-tight">
                MDASA
              </span>
            </div>

            <p className="text-xs text-slate-400 max-w-[45ch] leading-relaxed">
              Diseño y modernización de la infraestructura de telecomunicaciones y seguridad perimetral
              de la Municipalidad Distrital de Alto Selva Alegre, Arequipa.
            </p>

            <p className="text-[11px] text-slate-500 pt-6">
              Copyright 2026 MDASA. Inspirado en el diseño editorial MNTN por Kryston Schwarze.
            </p>
          </div>

          {/* Middle Column: 3 cols */}
          <div className="md:col-span-3 space-y-3 text-xs">
            <h4 className="font-bold text-[#FBD784] uppercase tracking-wider text-[11px]">
              Herramientas de Red
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button
                  onClick={() => onNavigate('dispositivos')}
                  className="hover:text-white transition-colors"
                >
                  Inventario de Activos
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('acls')}
                  className="hover:text-white transition-colors"
                >
                  Simulador de Reglas ACL
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('rendimiento')}
                  className="hover:text-white transition-colors"
                >
                  Pruebas de Carga & SLAs
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('vlans')}
                  className="hover:text-white transition-colors"
                >
                  Topología y Subredes
                </button>
              </li>
            </ul>
          </div>

          {/* Right Column: 3 cols */}
          <div className="md:col-span-3 space-y-3 text-xs">
            <h4 className="font-bold text-[#FBD784] uppercase tracking-wider text-[11px]">
              Institucional & Documentos
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button
                  onClick={() => onNavigate('documentacion')}
                  className="hover:text-white transition-colors"
                >
                  Manual de Usuario v1.0
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('documentacion')}
                  className="hover:text-white transition-colors"
                >
                  Manual de Despliegue
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('terminal')}
                  className="hover:text-white transition-colors"
                >
                  Consola PowerShell RedCli
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('usuarios')}
                  className="hover:text-white transition-colors"
                >
                  Auditoría PostgreSQL
                </button>
              </li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  );
};
