import React, { useState, useRef, useEffect } from 'react';
import {
  Terminal as TerminalIcon,
  Play,
  RotateCcw,
  Copy,
  Check,
  Maximize2,
  ChevronRight,
  Info,
} from 'lucide-react';
import { Dispositivo, Vlan, Subred, Mantenimiento, Usuario } from '../types/network';
import { simularPaqueteAcl, ZonaId, DestinoId, ServicioId } from '../services/aclSimulator';

interface PowerShellConsoleProps {
  dispositivos: Dispositivo[];
  vlans: Vlan[];
  subredes: Subred[];
  mantenimientos: Mantenimiento[];
  usuarios: Usuario[];
}

interface CommandHistoryItem {
  command: string;
  output: string;
  isError?: boolean;
}

export const PowerShellConsole: React.FC<PowerShellConsoleProps> = ({
  dispositivos,
  vlans,
  subredes,
  mantenimientos,
  usuarios,
}) => {
  const [inputVal, setInputVal] = useState('');
  const [history, setHistory] = useState<CommandHistoryItem[]>([
    {
      command: 'Import-Module .\\scripts\\RedCli.psm1 -Force',
      output:
        'Módulo RedCli v1.0 importado correctamente.\nCmdlets disponibles: Connect-Red, Get-RedDispositivo, Get-RedVlan, Get-RedSubred, Get-RedMantenimiento, Test-RedAcl, Export-RedInventario, Get-RedUsuario.',
    },
    {
      command: 'Connect-Red -Url http://127.0.0.1:3000 -Correo admin@altoselvaalegre.gob.pe',
      output:
        'Conexión segura establecida con la API de la Municipalidad Distrital de Alto Selva Alegre.\nSesión iniciada como: Ing. Carlos Mendoza (Rol: Administrador)\nToken CSRF de doble envío y cookie __Host-sid verificados.',
    },
  ]);
  const [historyIdx, setHistoryIdx] = useState<number>(-1);
  const [copied, setCopied] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const executeCommand = (cmdText: string) => {
    const raw = cmdText.trim();
    if (!raw) return;

    const lower = raw.toLowerCase();

    if (lower === 'clear' || lower === 'cls') {
      setHistory([]);
      setInputVal('');
      return;
    }

    let out = '';
    let isErr = false;

    if (lower.startsWith('help') || lower.startsWith('get-help')) {
      out = `SISTEMA DE GESTIÓN DE RED MDASA — REDCLI PSM1 (Actualizado con Mejoras de Rendimiento)
Comandos disponibles:
  Get-RedDispositivo [-Tipo <t>] [-Pagina <N>] [-Limite <M>] [-Todos]
                                           Lista dispositivos con paginación optimizada (20 por defecto)
  Resolve-RedDispositivo -Dispositivo <nom> Busca por índice trigram en BD (evita descargar catálogo)
  Get-RedVlan                              Muestra las VLANs del diseño propuesto (Caché 60s)
  Get-RedSubred                            Lista las subredes AS-IS y TO-BE (Caché 60s)
  Get-RedMantenimiento [-Estado <e>] [-Pagina <N>] [-Limite <M>] [-Todos]
                                           Consulta órdenes de mantenimiento con paginación
  Test-RedAcl -Origen <Z> -Destino <D>     Valida paquetes contra la matriz de ACLs
  Export-RedInventario -Formato csv        Genera el informe de inventario
  Get-RedUsuario                           Lista el personal autorizado en RBAC
  Clear / cls                              Limpia la pantalla de la consola`;
    } else if (lower.startsWith('resolve-reddispositivo')) {
      const dMatch = raw.match(/-dispositivo\s+([^\s]+)/i) || raw.match(/resolve-reddispositivo\s+([^\s]+)/i);
      const targetName = dMatch ? dMatch[1].replace(/["']/g, '') : '';
      const found = dispositivos.find(
        (d) =>
          d.nombre.toLowerCase().includes(targetName.toLowerCase()) ||
          d.id_dispositivo.toLowerCase() === targetName.toLowerCase()
      );
      if (found) {
        out = `[RESOLVED VIA GIN TRIGRAM INDEX (ix_dispositivos_nombre_trgm)]
ID:          ${found.id_dispositivo}
Nombre:      ${found.nombre}
Tipo:        ${found.tipo}
Modelo:      ${found.marca} ${found.modelo}
Estado:      ${found.estado}
IP Primaria: ${found.interfaces?.[0]?.ip || '—'}
Consulta ejecutada en PostgreSQL en 0.35 ms (objetivo <= 200 ms cumplido).`;
      } else {
        out = `No se encontró un dispositivo llamado '${targetName}'. Use Get-RedDispositivo para ver los nombres exactos.`;
        isErr = true;
      }
    } else if (lower.startsWith('get-reddispositivo')) {
      const tipoMatch = raw.match(/-tipo\s+([a-zA-Z0-9_]+)/i);
      const paginaMatch = raw.match(/-pagina\s+([0-9]+)/i);
      const limiteMatch = raw.match(/-limite\s+([0-9]+)/i);
      const esTodos = lower.includes('-todos');

      const tipoFilter = tipoMatch ? tipoMatch[1].toLowerCase() : null;
      let items = tipoFilter
        ? dispositivos.filter((d) => d.tipo.toLowerCase() === tipoFilter)
        : dispositivos;

      const pag = paginaMatch ? Number(paginaMatch[1]) : 1;
      const lim = esTodos ? items.length : limiteMatch ? Number(limiteMatch[1]) : 20;
      const offset = (pag - 1) * lim;
      const paginados = esTodos ? items : items.slice(offset, offset + lim);

      const header = 'Nombre'.padEnd(22) + 'Tipo'.padEnd(14) + 'Marca / Modelo'.padEnd(30) + 'Estado'.padEnd(14) + 'IP';
      const sep = '-'.repeat(88);
      const rows = paginados.map((d) => {
        const ip = d.interfaces?.[0]?.ip || '—';
        return (
          d.nombre.padEnd(22) +
          d.tipo.padEnd(14) +
          `${d.marca} ${d.modelo}`.substring(0, 28).padEnd(30) +
          d.estado.padEnd(14) +
          ip
        );
      });
      out = `[PAGINACIÓN API: Pagina=${pag}, Limite=${lim}, HayMas=${offset + lim < items.length}]\n${header}\n${sep}\n${rows.join('\n')}\n\nMostrando ${paginados.length} de ${items.length} activos registrados.`;
    } else if (lower.startsWith('get-redvlan')) {
      const header = 'Numero'.padEnd(8) + 'Nombre'.padEnd(14) + 'Gateway'.padEnd(16) + 'Rango IP'.padEnd(18) + 'Funcion';
      const sep = '-'.repeat(85);
      const rows = vlans.map((v) => {
        return (
          String(v.numero).padEnd(8) +
          v.nombre.padEnd(14) +
          (v.gateway || '—').padEnd(16) +
          (v.rango_ip || '—').padEnd(18) +
          v.funcion
        );
      });
      out = `[DATOS DE CACHÉ EN MEMORIA (TTL 60s)]\n${header}\n${sep}\n${rows.join('\n')}`;
    } else if (lower.startsWith('get-redsubred')) {
      const header = 'Red CIDR'.padEnd(18) + 'Gateway'.padEnd(16) + 'Diseno'.padEnd(12) + 'Funcion';
      const sep = '-'.repeat(80);
      const rows = subredes.map((s) => {
        return (
          s.red.padEnd(18) +
          s.gateway.padEnd(16) +
          s.estado_diseno.padEnd(12) +
          s.funcion
        );
      });
      out = `[DATOS DE CACHÉ EN MEMORIA (TTL 60s)]\n${header}\n${sep}\n${rows.join('\n')}`;
    } else if (lower.startsWith('get-redmantenimiento')) {
      const header = 'Dispositivo'.padEnd(22) + 'Tipo'.padEnd(14) + 'Estado'.padEnd(14) + 'Fecha Prog'.padEnd(14) + 'Descripcion';
      const sep = '-'.repeat(90);
      const rows = mantenimientos.map((m) => {
        return (
          (m.dispositivo_nombre || 'Equipo').padEnd(22) +
          m.tipo.padEnd(14) +
          m.estado.padEnd(14) +
          m.fecha_programada.padEnd(14) +
          m.descripcion.substring(0, 30)
        );
      });
      out = `${header}\n${sep}\n${rows.join('\n')}`;
    } else if (lower.startsWith('test-redacl')) {
      const oMatch = raw.match(/-origen\s+([a-zA-Z0-9_]+)/i);
      const dMatch = raw.match(/-destino\s+([a-zA-Z0-9_]+)/i);
      const sMatch = raw.match(/-servicio\s+([a-zA-Z0-9_]+)/i);

      const oz: ZonaId = (oMatch ? oMatch[1].toUpperCase() : 'X') as ZonaId;
      const dz: DestinoId = (dMatch ? dMatch[1].toUpperCase() : 'SERVERS') as DestinoId;
      const sz: ServicioId = (sMatch ? sMatch[1].toLowerCase() : 'tcp443') as ServicioId;

      const res = simularPaqueteAcl(oz, dz, sz);

      out = `DICTAMEN DE INSPECCION ACL:
=============================================
Origen:   ${oz}
Destino:  ${dz}
Servicio: ${sz}
Estado:   ${res.estado} [${res.permitido ? 'PERMITIDO' : 'PAQUETE DESCARTADO'}]
Regla:    ${res.aclAplicada}
Motivo:   ${res.motivo}
Ruta:     ${res.saltoRuta.join(' ➔ ')}`;
    } else if (lower.startsWith('export-redinventario')) {
      out = `[INFO] Exportación completada exitosamente.
Archivo generado: C:\\Users\\Public\\inventario_mdasa_${new Date().toISOString().split('T')[0]}.csv
Total de registros exportados: ${dispositivos.length} equipos con sus correspondientes interfaces y estados.`;
    } else if (lower.startsWith('get-redusuario')) {
      const header = 'Nombre'.padEnd(25) + 'Email'.padEnd(35) + 'Rol'.padEnd(15) + 'Activo';
      const sep = '-'.repeat(80);
      const rows = usuarios.map((u) => {
        return (
          u.nombre.padEnd(25) +
          u.email.padEnd(35) +
          u.rol.padEnd(15) +
          (u.activo ? 'True' : 'False')
        );
      });
      out = `${header}\n${sep}\n${rows.join('\n')}`;
    } else if (lower.startsWith('connect-red')) {
      out = `Conexión reconectada. Sesión activa: admin@altoselvaalegre.gob.pe (Rol: Administrador)`;
    } else {
      out = `'${raw}' no se reconoce como un comando o cmdlet interno de RedCli.\nEscriba 'help' o 'Get-Help' para ver los comandos disponibles.`;
      isErr = true;
    }

    setHistory((prev) => [...prev, { command: raw, output: out, isError: isErr }]);
    setInputVal('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      executeCommand(inputVal);
    }
  };

  const quickCommands = [
    'Get-RedDispositivo -Pagina 1 -Limite 5',
    'Resolve-RedDispositivo -Dispositivo FW-FORTIGATE-90G',
    'Get-RedDispositivo -Tipo servidor',
    'Get-RedDispositivo -Tipo switch',
    'Get-RedVlan',
    'Get-RedSubred',
    'Get-RedMantenimiento -Pagina 1 -Limite 20',
    'Test-RedAcl -Origen X -Destino SERVERS -Servicio tcp443',
    'Test-RedAcl -Origen X -Destino SERVERS -Servicio tcp80',
    'Test-RedAcl -Origen X -Destino R1B -Servicio tcp23',
    'Get-RedUsuario',
    'help',
  ];

  return (
    <div className="space-y-6">
      {/* Title with MNTN Style */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-3 text-[#FBD784] text-xs font-bold uppercase tracking-[0.2em]">
            <span className="w-10 h-0.5 bg-[#FBD784]" />
            <span>CLI CLIENT / INTERFAZ DE COMANDOS</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-[-0.02em] flex items-center gap-3">
            <TerminalIcon className="w-6 h-6 text-[#FBD784]" />
            Consola Operativa PowerShell 7 (RedCli.psm1)
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-[65ch] leading-relaxed">
            Emulador del cliente de línea de comandos del repositorio original para auditoría y gestión por terminal.
          </p>
        </div>

        <button
          onClick={() => setHistory([])}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#0B1D26]/90 hover:bg-slate-800 text-slate-200 text-xs font-semibold border border-white/[0.08] transition-all duration-150 active:scale-[0.97]"
        >
          <RotateCcw className="w-3.5 h-3.5 text-[#FBD784]" />
          Limpiar Pantalla (cls)
        </button>
      </div>

      {/* Quick Launch Buttons */}
      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
        <span className="text-[11px] font-semibold text-slate-400">
          Comandos Rápidos de Auditoría:
        </span>
        <div className="flex flex-wrap gap-1.5">
          {quickCommands.map((cmd) => (
            <button
              key={cmd}
              onClick={() => executeCommand(cmd)}
              className="px-2.5 py-1 rounded bg-slate-950 hover:bg-blue-950/60 border border-slate-800 hover:border-blue-700/60 text-slate-300 hover:text-cyan-300 font-mono text-[11px] transition"
            >
              {cmd}
            </button>
          ))}
        </div>
      </div>

      {/* Windows Terminal Container (Fidelity with u01-u14 HTML captures) */}
      <div className="rounded-xl overflow-hidden border border-slate-800 bg-[#0c0c0c] shadow-2xl">
        {/* Window Title Bar */}
        <div className="h-10 bg-[#20262d] flex items-center justify-between px-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="flex gap-1.5">
              <span className="w-3 h-3 rounded-full bg-[#ff5f57] inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-[#febc2e] inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-[#28c840] inline-block"></span>
            </div>
            <span className="ml-3 text-xs font-mono font-medium text-slate-300">
              Windows PowerShell 7.4.x — RedCli MDASA (http://127.0.0.1:3000)
            </span>
          </div>
          <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800">
            TLS 1.3 Active
          </span>
        </div>

        {/* Console Body */}
        <div className="p-4 sm:p-5 font-mono text-xs sm:text-[13px] leading-relaxed text-[#d7e2ec] max-h-[500px] overflow-y-auto space-y-4">
          <div className="text-slate-500 text-xs">
            PowerShell 7.4.2 · MDASA Network Management Console v1.0{'\n'}
            Copyright (c) Municipalidad Distrital de Alto Selva Alegre. Todos los derechos reservados.
          </div>

          {history.map((item, idx) => (
            <div key={idx} className="space-y-1">
              <div className="flex items-start gap-1 text-[#7cd3ff] font-semibold">
                <span className="text-emerald-400">PS C:\proyecto_red&gt;</span>
                <span>{item.command}</span>
              </div>
              <pre
                className={`whitespace-pre-wrap font-mono text-xs ${
                  item.isError ? 'text-rose-400' : 'text-[#d7e2ec]'
                }`}
              >
                {item.output}
              </pre>
            </div>
          ))}

          {/* Active Input Line */}
          <div className="flex items-center gap-1.5 text-[#7cd3ff] pt-2">
            <span className="text-emerald-400 font-semibold shrink-0">
              PS C:\proyecto_red&gt;
            </span>
            <input
              type="text"
              autoFocus
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Escribe un comando... (ej: Get-RedDispositivo o help)"
              className="w-full bg-transparent border-none text-[#d7e2ec] font-mono text-xs sm:text-[13px] focus:outline-none placeholder-slate-600"
            />
          </div>
          <div ref={bottomRef} />
        </div>
      </div>
    </div>
  );
};
