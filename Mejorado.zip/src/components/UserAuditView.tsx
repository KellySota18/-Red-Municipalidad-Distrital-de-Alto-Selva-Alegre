import React, { useState } from 'react';
import {
  Users,
  Shield,
  Activity,
  UserPlus,
  Key,
  Lock,
  Clock,
  CheckCircle,
  AlertCircle,
  FileText,
} from 'lucide-react';
import { Usuario, AuditoriaLog, RolUsuario } from '../types/network';

interface UserAuditViewProps {
  usuarios: Usuario[];
  auditoria: AuditoriaLog[];
  rolActual: RolUsuario;
  onAddUsuario: (u: Usuario) => void;
  onUpdateUsuarioRol: (id: string, nuevoRol: RolUsuario) => void;
}

export const UserAuditView: React.FC<UserAuditViewProps> = ({
  usuarios,
  auditoria,
  rolActual,
  onAddUsuario,
  onUpdateUsuarioRol,
}) => {
  const [tab, setTab] = useState<'usuarios' | 'auditoria'>('usuarios');
  const [mostrarModalNuevo, setMostrarModalNuevo] = useState(false);
  const [nombre, setNombre] = useState('');
  const [email, setEmail] = useState('');
  const [rol, setRol] = useState<RolUsuario>('consulta');

  const handleCrear = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nombre || !email) return;

    const nuevo: Usuario = {
      id_usuario: 'usr-' + Date.now(),
      nombre: nombre.trim(),
      email: email.trim().toLowerCase(),
      rol,
      activo: true,
      fecha_registro: new Date().toISOString(),
      ultimo_acceso: 'Recién registrado',
    };

    onAddUsuario(nuevo);
    setMostrarModalNuevo(false);
    setNombre('');
    setEmail('');
  };

  const getRolBadge = (r: RolUsuario) => {
    switch (r) {
      case 'administrador':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-red-500/15 text-red-400 border border-red-500/30">
            Administrador
          </span>
        );
      case 'tecnico':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/15 text-blue-400 border border-blue-500/30">
            Técnico
          </span>
        );
      case 'consulta':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            Consulta (Auditor)
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with MNTN Style */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-3 text-[#FBD784] text-xs font-bold uppercase tracking-[0.2em]">
            <span className="w-10 h-0.5 bg-[#FBD784]" />
            <span>SEGURIDAD RBAC / AUDITORÍA INMUTABLE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-[-0.02em] flex items-center gap-3">
            <Users className="w-6 h-6 text-[#FBD784]" />
            Control de Usuarios RBAC y Registro de Auditoría PostgreSQL
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-[65ch] leading-relaxed">
            Aislamiento de privilegios mediante Row Level Security (RLS) y bitácora de no repudio inmutable.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="flex p-1 rounded-2xl bg-[#0B1D26]/90 border border-white/[0.08] shadow-inner">
            <button
              onClick={() => setTab('usuarios')}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all duration-150 active:scale-[0.97] ${
                tab === 'usuarios'
                  ? 'bg-[#FBD784] text-[#0B1D26] shadow-md shadow-[#FBD784]/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Usuarios ({usuarios.length})
            </button>
            <button
              onClick={() => setTab('auditoria')}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all duration-150 active:scale-[0.97] ${
                tab === 'auditoria'
                  ? 'bg-[#FBD784] text-[#0B1D26] shadow-md shadow-[#FBD784]/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Auditoría ({auditoria.length})
            </button>
          </div>

          {tab === 'usuarios' && rolActual === 'administrador' && (
            <button
              onClick={() => setMostrarModalNuevo(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#FBD784] hover:bg-[#ffe39d] text-[#0B1D26] text-xs font-bold uppercase tracking-wider shadow-lg shadow-[#FBD784]/20 transition-all duration-150 active:scale-[0.97]"
            >
              <UserPlus className="w-4 h-4 text-[#0B1D26]" />
              Nuevo Usuario
            </button>
          )}
        </div>
      </div>

      {tab === 'usuarios' ? (
        <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/60 shadow-lg">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider">
                <th className="py-3 px-4">Personal / Funcionario</th>
                <th className="py-3 px-4">Correo Institucional</th>
                <th className="py-3 px-4">Rol en el Sistema</th>
                <th className="py-3 px-4">Estado</th>
                <th className="py-3 px-4">Última Actividad</th>
                {rolActual === 'administrador' && <th className="py-3 px-4 text-center">Cambiar Rol</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {usuarios.map((u) => (
                <tr key={u.id_usuario} className="hover:bg-slate-800/30 transition">
                  <td className="py-3 px-4 font-semibold text-white flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-cyan-400">
                      {u.nombre.charAt(0)}
                    </div>
                    <span>{u.nombre}</span>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-300">{u.email}</td>
                  <td className="py-3 px-4">{getRolBadge(u.rol)}</td>
                  <td className="py-3 px-4">
                    <span className="flex items-center gap-1 text-emerald-400 font-medium">
                      <CheckCircle className="w-3.5 h-3.5" /> Activo
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-400">{u.ultimo_acceso || 'Hoy'}</td>
                  {rolActual === 'administrador' && (
                    <td className="py-3 px-4 text-center">
                      <select
                        value={u.rol}
                        onChange={(e) =>
                          onUpdateUsuarioRol(u.id_usuario, e.target.value as RolUsuario)
                        }
                        className="px-2 py-1 bg-slate-950 border border-slate-700 rounded text-slate-200 text-xs focus:outline-none"
                      >
                        <option value="administrador">Administrador</option>
                        <option value="tecnico">Técnico</option>
                        <option value="consulta">Consulta</option>
                      </select>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        /* Auditoria Log */
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              Disparador transaccional activo: <code>infra.trg_auditoria_segura</code>
            </span>
            <span className="font-mono text-cyan-400">PostgreSQL 16 · Inmutable Log</span>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/60 shadow-lg">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider font-mono">
                  <th className="py-2.5 px-3">ID Log</th>
                  <th className="py-2.5 px-3">Fecha y Hora</th>
                  <th className="py-2.5 px-3">Usuario App</th>
                  <th className="py-2.5 px-3">Tabla Afectada</th>
                  <th className="py-2.5 px-3">Operación</th>
                  <th className="py-2.5 px-3">Registro Afectado</th>
                  <th className="py-2.5 px-3">Detalle de Operación</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
                {auditoria.map((a) => (
                  <tr key={a.id_auditoria} className="hover:bg-slate-800/30 transition">
                    <td className="py-2.5 px-3 text-slate-500 font-bold">#{a.id_auditoria}</td>
                    <td className="py-2.5 px-3 text-slate-400">{a.fecha}</td>
                    <td className="py-2.5 px-3 font-sans text-cyan-300 font-medium">
                      {a.usuario_nombre}
                    </td>
                    <td className="py-2.5 px-3 text-blue-400">{a.tabla}</td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          a.operacion === 'INSERT'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : a.operacion === 'UPDATE'
                            ? 'bg-amber-500/20 text-amber-400'
                            : a.operacion === 'EXECUTE'
                            ? 'bg-purple-500/20 text-purple-400'
                            : 'bg-red-500/20 text-red-400'
                        }`}
                      >
                        {a.operacion}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">{a.id_registro}</td>
                    <td className="py-2.5 px-3 font-sans text-[11px] text-slate-400">
                      {a.detalles}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Nuevo Usuario */}
      {mostrarModalNuevo && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleCrear}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-blue-400" />
                Registrar Nuevo Funcionario en RBAC
              </h3>
              <button
                type="button"
                onClick={() => setMostrarModalNuevo(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-slate-400">Nombre Completo y Cargo</label>
                <input
                  required
                  type="text"
                  placeholder="ej: Lic. Roberto Paredes"
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-400">Correo Electrónico Institucional</label>
                <input
                  required
                  type="email"
                  placeholder="rparedes@altoselvaalegre.gob.pe"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-400">Rol Asignado</label>
                <select
                  value={rol}
                  onChange={(e) => setRol(e.target.value as RolUsuario)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="consulta">Consulta (Solo lectura de inventario y manuales)</option>
                  <option value="tecnico">Técnico (Inspección y cierre de mantenimientos)</option>
                  <option value="administrador">Administrador (Control total de red y ACLs)</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setMostrarModalNuevo(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md shadow-blue-600/30"
              >
                Crear Usuario
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
