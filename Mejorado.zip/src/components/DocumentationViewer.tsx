import React, { useState } from 'react';
import {
  FileText,
  BookOpen,
  Terminal,
  Database,
  Shield,
  Layers,
  Copy,
  Check,
  Download,
  ExternalLink,
} from 'lucide-react';

export const DocumentationViewer: React.FC = () => {
  const [docActivo, setDocActivo] = useState<
    'usuario' | 'instalacion' | 'arquitectura' | 'diccionario' | 'acl' | 'rendimiento'
  >('usuario');
  const [copiado, setCopiado] = useState(false);

  const copiarCodigo = (codigo: string) => {
    navigator.clipboard.writeText(codigo);
    setCopiado(true);
    setTimeout(() => setCopiado(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Header with MNTN Style */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-3 text-[#FBD784] text-xs font-bold uppercase tracking-[0.2em]">
            <span className="w-10 h-0.5 bg-[#FBD784]" />
            <span>CENTRO TÉCNICO / DICTÁMENES & MANUALES</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-[-0.02em] flex items-center gap-3">
            <BookOpen className="w-6 h-6 text-[#FBD784]" />
            Centro de Documentación Técnica y Manuales Oficiales
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-[65ch] leading-relaxed">
            Documentos generados para la Municipalidad Distrital de Alto Selva Alegre (Computación en Red II).
          </p>
        </div>

        {/* Doc Switcher Buttons with MNTN Gold Active State */}
        <div className="flex items-center gap-1.5 flex-wrap p-1 rounded-2xl bg-[#0B1D26]/90 border border-white/[0.08] shadow-inner">
          <button
            onClick={() => setDocActivo('usuario')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all duration-150 active:scale-[0.97] ${
              docActivo === 'usuario'
                ? 'bg-[#FBD784] text-[#0B1D26] shadow-md shadow-[#FBD784]/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Manual de Usuario
          </button>
          <button
            onClick={() => setDocActivo('instalacion')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all duration-150 active:scale-[0.97] ${
              docActivo === 'instalacion'
                ? 'bg-[#FBD784] text-[#0B1D26] shadow-md shadow-[#FBD784]/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Manual de Despliegue
          </button>
          <button
            onClick={() => setDocActivo('arquitectura')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all duration-150 active:scale-[0.97] ${
              docActivo === 'arquitectura'
                ? 'bg-[#FBD784] text-[#0B1D26] shadow-md shadow-[#FBD784]/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Arquitectura de Red
          </button>
          <button
            onClick={() => setDocActivo('diccionario')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all duration-150 active:scale-[0.97] ${
              docActivo === 'diccionario'
                ? 'bg-[#FBD784] text-[#0B1D26] shadow-md shadow-[#FBD784]/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Diccionario de Datos
          </button>
          <button
            onClick={() => setDocActivo('acl')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all duration-150 active:scale-[0.97] ${
              docActivo === 'acl'
                ? 'bg-[#FBD784] text-[#0B1D26] shadow-md shadow-[#FBD784]/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Guía de ACLs
          </button>
          <button
            onClick={() => setDocActivo('rendimiento')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all duration-150 active:scale-[0.97] ${
              docActivo === 'rendimiento'
                ? 'bg-[#FBD784] text-[#0B1D26] shadow-md shadow-[#FBD784]/20'
                : 'text-[#FBD784]/70 hover:text-white'
            }`}
          >
            ⚡ Rendimiento (RENDIMIENTO.md)
          </button>
        </div>
      </div>

      {/* Document Content Container with MNTN Glass Material */}
      <div className="p-8 rounded-3xl bg-[#0B1D26]/85 backdrop-blur-xl border border-white/[0.08] shadow-2xl text-slate-300 leading-relaxed space-y-6">
        {/* DOCUMENT 1: MANUAL DE USUARIO */}
        {docActivo === 'usuario' && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <span className="text-[11px] font-mono uppercase text-blue-400 font-bold">
                DOCUMENTO TÉCNICO OFICIAL 01
              </span>
              <h3 className="text-xl font-bold text-white mt-1">
                MANUAL DE USUARIO — SISTEMA DE INVENTARIO Y SEGURIDAD DE RED MDASA
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Versión del sistema: 1.0 · Municipalidad Distrital de Alto Selva Alegre (Arequipa, Perú)
              </p>
            </div>

            <div className="space-y-4 text-xs sm:text-sm">
              <h4 className="text-base font-bold text-white">1. Propósito y Alcance</h4>
              <p>
                Este manual establece las instrucciones de operación para la consulta del catálogo de activos,
                la administración de órdenes de mantenimiento preventivo y la verificación de reglas de control
                de acceso perimetral (ACL) de la red municipal.
              </p>

              <h4 className="text-base font-bold text-white pt-2">2. Modelo de Acceso por Roles (RBAC)</h4>
              <div className="overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-950 border-b border-slate-800 text-slate-400">
                      <th className="py-2.5 px-3">Rol</th>
                      <th className="py-2.5 px-3">Inventario de Dispositivos</th>
                      <th className="py-2.5 px-3">Mantenimientos</th>
                      <th className="py-2.5 px-3">Seguridad y Usuarios</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-sans">
                    <tr>
                      <td className="py-2.5 px-3 font-semibold text-emerald-400">consulta</td>
                      <td className="py-2.5 px-3">Solo lectura (SELECT)</td>
                      <td className="py-2.5 px-3">Solo lectura</td>
                      <td className="py-2.5 px-3 text-slate-500">Sin acceso</td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-semibold text-blue-400">tecnico</td>
                      <td className="py-2.5 px-3">Lectura e inspección técnica</td>
                      <td className="py-2.5 px-3">Creación y cierre de órdenes</td>
                      <td className="py-2.5 px-3 text-slate-500">Sin acceso</td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-semibold text-red-400">administrador</td>
                      <td className="py-2.5 px-3">Control total (CRUD)</td>
                      <td className="py-2.5 px-3">Control total</td>
                      <td className="py-2.5 px-3">Gestión de usuarios y reglas ACL</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <h4 className="text-base font-bold text-white pt-2">3. Uso de la Consola RedCli</h4>
              <p>
                Para acceder mediante terminal de comandos en Windows PowerShell 7:
              </p>
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs text-cyan-300">
                PS C:\&gt; Import-Module .\scripts\RedCli.psm1 -Force<br />
                PS C:\&gt; Connect-Red -Url http://127.0.0.1:3000 -Correo admin@altoselvaalegre.gob.pe<br />
                PS C:\&gt; Get-RedDispositivo -Tipo servidor | Format-Table Nombre, Tipo, Estado, Piso
              </div>
            </div>
          </div>
        )}

        {/* DOCUMENT 2: MANUAL DE DESPLIEGUE */}
        {docActivo === 'instalacion' && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <span className="text-[11px] font-mono uppercase text-blue-400 font-bold">
                DOCUMENTO TÉCNICO OFICIAL 02
              </span>
              <h3 className="text-xl font-bold text-white mt-1">
                MANUAL DE INSTALACIÓN Y DESPLIEGUE EN SERVIDORES
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Guía de aprovisionamiento de PostgreSQL 16 con RLS, API REST en Node.js y configuración de seguridad.
              </p>
            </div>

            <div className="space-y-4 text-xs sm:text-sm">
              <h4 className="text-base font-bold text-white">1. Despliegue de Base de Datos PostgreSQL</h4>
              <p>
                La persistencia utiliza el esquema aislado <code className="text-cyan-400 font-mono">infra</code> con
                Row Level Security (RLS) activo y contraseñas hasheadas mediante Bcrypt con factor de costo 12:
              </p>
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs text-slate-300">
                # Crear base de datos segura<br />
                createdb -U postgres infra_red_db<br />
                psql -U postgres -d infra_red_db -f bd/infra_red_schema_seguro.sql<br />
                psql -U postgres -d infra_red_db -f bd/seed_datos_municipalidad.sql
              </div>

              <h4 className="text-base font-bold text-white pt-2">2. Despliegue de la API REST Segura</h4>
              <p>
                El backend en Express.js incorpora protección CSRF por token de doble envío, cabeceras estrictas CSP
                mediante Helmet, y validación exhaustiva de payloads mediante Zod:
              </p>
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs text-slate-300">
                cd api<br />
                npm install<br />
                npm start
              </div>
            </div>
          </div>
        )}

        {/* DOCUMENT 3: ARQUITECTURA DE RED */}
        {docActivo === 'arquitectura' && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <span className="text-[11px] font-mono uppercase text-blue-400 font-bold">
                DOCUMENTO TÉCNICO OFICIAL 03
              </span>
              <h3 className="text-xl font-bold text-white mt-1">
                ARQUITECTURA DE RED: TRANSICIÓN AS-IS A TO-BE
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Rediseño de telecomunicaciones para el Palacio Municipal, Roosevelt y Serenazgo.
              </p>
            </div>

            <div className="space-y-4">
              <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-950 p-2">
                <img
                  src="/assets/arquitectura.png"
                  alt="Esquema de Red Packet Tracer"
                  className="w-full h-auto max-h-[450px] object-contain mx-auto"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm">
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <h4 className="font-bold text-red-400">Diagnóstico AS-IS (Red Plana Actual)</h4>
                  <p className="text-slate-300">
                    Tres subredes interconectadas sin VLANs (10.0.0.0/24 para servidores, 10.0.1.0/24 para usuarios
                    administrativos, 10.0.2.0/24 para sede Roosevelt). Riesgo de propagación de malware masivo y
                    exposición del SIAF sin cifrado.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <h4 className="font-bold text-emerald-400">Solución TO-BE (Segmentada 802.1Q)</h4>
                  <p className="text-slate-300">
                    6 VLANs independientes con subinterfaces en FortiGate 90G (G0/2.10, G0/2.20, G0/2.30, G0/2.40,
                    G0/2.50 y G0/2.99). Filtrado con deny-by-default, TLS 1.3 forzoso y gestión Out-of-Band en VLAN 99.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* DOCUMENT 4: DICCIONARIO DE DATOS */}
        {docActivo === 'diccionario' && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <span className="text-[11px] font-mono uppercase text-blue-400 font-bold">
                DOCUMENTO TÉCNICO OFICIAL 06
              </span>
              <h3 className="text-xl font-bold text-white mt-1">
                DICCIONARIO DE DATOS — ESQUEMA INFRAESTRUCTURA
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Catálogo relacional con tipos nativos CIDR/INET, restricciones CHECK y disparadores de auditoría.
              </p>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                <div className="font-mono font-bold text-blue-400">infra.dispositivos</div>
                <p className="text-slate-400 mt-1">
                  Almacena el catálogo de equipos físicos y virtuales (id_dispositivo uuid, nombre varchar,
                  tipo enum, marca varchar, modelo varchar, estado enum, mantenimiento_cada_meses smallint).
                </p>
              </div>

              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                <div className="font-mono font-bold text-cyan-400">infra.interfaces</div>
                <p className="text-slate-400 mt-1">
                  Interfaces físicas y virtuales asignadas a dispositivos (id_interfaz uuid, mac macaddr,
                  ip inet, id_subred uuid, asignacion enum estatica/dhcp). Impide IPs duplicadas en la red.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                <div className="font-mono font-bold text-emerald-400">infra.vlans & subredes</div>
                <p className="text-slate-400 mt-1">
                  Definición de segmentos IEEE 802.1Q y direccionamiento CIDR (red cidr, gateway inet,
                  estado_diseno enum actual/propuesto). Restricción exclusion gist para evitar solape de IPs.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                <div className="font-mono font-bold text-amber-400">infra.auditoria</div>
                <p className="text-slate-400 mt-1">
                  Registro de trazabilidad inmutable mediante triggers en PostgreSQL (id_auditoria bigint,
                  fecha timestamptz, usuario_app uuid, tabla text, operacion text, datos_antes jsonb, datos_despues jsonb).
                </p>
              </div>
            </div>
          </div>
        )}

        {/* DOCUMENT 5: GUIA DE ACLs */}
        {docActivo === 'acl' && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <span className="text-[11px] font-mono uppercase text-blue-400 font-bold">
                DOCUMENTO TÉCNICO OFICIAL ACL
              </span>
              <h3 className="text-xl font-bold text-white mt-1">
                GUÍA DE POLÍTICAS DE SEGURIDAD Y CONTROL DE ACCESO (ACL)
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Criterios de filtrado perimetral contra intrusión, robo de credenciales y movimiento lateral.
              </p>
            </div>

            <div className="space-y-4 text-xs sm:text-sm">
              <p>
                Las listas de control de acceso (ACLs) se aplican en dirección <code className="text-cyan-400 font-mono">inbound</code> en
                cada subinterfaz virtual del FortiGate 90G y router MikroTik. Toda regla sigue el principio de menor privilegio.
              </p>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-emerald-400 space-y-2">
                <div>! FW_IN_VLAN30_AREA_X (Usuarios Pisos 1 y 3)</div>
                <div className="text-slate-300">ip access-list extended FW_IN_VLAN30_AREA_X</div>
                <div className="pl-4 text-emerald-300">permit tcp 10.10.30.0 0.0.0.255 10.10.10.0 0.0.0.255 eq 443</div>
                <div className="pl-4 text-emerald-300">permit udp 10.10.30.0 0.0.0.255 10.10.10.0 0.0.0.255 eq 53</div>
                <div className="pl-4 text-emerald-300">permit tcp 10.10.30.0 0.0.0.255 10.10.20.0 0.0.0.255 eq 9100</div>
                <div className="pl-4 text-rose-400">deny tcp 10.10.30.0 0.0.0.255 10.10.10.0 0.0.0.255 eq 80  ! Bloqueo P5</div>
                <div className="pl-4 text-rose-400">deny tcp 10.10.30.0 0.0.0.255 any eq 23                  ! Bloqueo P8</div>
                <div className="pl-4 text-rose-400 font-bold">deny ip any any                                       ! Default Deny</div>
              </div>
            </div>
          </div>
        )}

        {/* DOCUMENT 6: RENDIMIENTO (RENDIMIENTO.md) */}
        {docActivo === 'rendimiento' && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <span className="text-[11px] font-mono uppercase text-amber-400 font-bold">
                DOCUMENTO TÉCNICO OFICIAL — RENDIMIENTO Y OPTIMIZACIÓN
              </span>
              <h3 className="text-xl font-bold text-white mt-1">
                RENDIMIENTO — MEDIDAS IMPLEMENTADAS Y VERIFICACIÓN
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Optimización de PostgreSQL 16, índices GIN pg_trgm, compresión de respuestas y pruebas de concurrencia.
              </p>
            </div>

            <div className="space-y-4 text-xs sm:text-sm">
              <h4 className="text-base font-bold text-white">1. Medidas Implementadas</h4>
              <div className="overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-950 border-b border-slate-800 text-slate-400 font-semibold">
                      <th className="py-2.5 px-3">Objetivo</th>
                      <th className="py-2.5 px-3">Medida Implementada</th>
                      <th className="py-2.5 px-3">Ubicación</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-sans">
                    <tr>
                      <td className="py-2.5 px-3 font-semibold text-white">Pool de conexiones</td>
                      <td className="py-2.5 px-3 text-slate-300">
                        <code>max</code> configurable (10), cierre de ociosas a los 30 s, espera máxima 5 s, statement_timeout 5 s
                      </td>
                      <td className="py-2.5 px-3 font-mono text-cyan-400">api/server.js</td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-semibold text-white">Paginación (20 por defecto)</td>
                      <td className="py-2.5 px-3 text-slate-300">
                        <code>?pagina=N&amp;limite=M</code>. Se piden <code>limite+1</code> filas para saber si hay más sin ejecutar <code>COUNT(*)</code>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-cyan-400">api/server.js, RedCli.psm1</td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-semibold text-white">Evitar consultas innecesarias</td>
                      <td className="py-2.5 px-3 text-slate-300">
                        Filtro por nombre delegado a PostgreSQL. <code>Resolve-RedDispositivo</code> pide solo el equipo buscado
                      </td>
                      <td className="py-2.5 px-3 font-mono text-cyan-400">api/server.js, RedCli.psm1</td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-semibold text-white">Caché en memoria</td>
                      <td className="py-2.5 px-3 text-slate-300">
                        Vigencia 60 s para <code>/vlans</code> y <code>/subredes</code>. Peticiones simultáneas comparten una sola consulta
                      </td>
                      <td className="py-2.5 px-3 font-mono text-cyan-400">api/server.js</td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-semibold text-white">Índices de Alto Rendimiento</td>
                      <td className="py-2.5 px-3 text-slate-300">
                        <code>ix_dispositivos_estado</code>, <code>ix_dispositivos_tipo_nombre</code>, e índice trigram GIN para <code>ILIKE '%texto%'</code>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-cyan-400">bd/infra_red_rendimiento.sql</td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-semibold text-white">Menos bytes por la red</td>
                      <td className="py-2.5 px-3 text-slate-300">Compresión de respuestas JSON mayores de 1 KB con middleware compression</td>
                      <td className="py-2.5 px-3 font-mono text-cyan-400">api/server.js</td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-semibold text-white">Detección p95 ≤ 500 ms</td>
                      <td className="py-2.5 px-3 text-slate-300">Registro en consola con advertencia de toda petición que supere 500 ms (SLOW_MS)</td>
                      <td className="py-2.5 px-3 font-mono text-cyan-400">api/server.js</td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-semibold text-white">Pruebas de Carga</td>
                      <td className="py-2.5 px-3 text-slate-300">Script sin dependencias que mide p50/p95/p99 por ruta, peticiones/s, CPU y RAM</td>
                      <td className="py-2.5 px-3 font-mono text-cyan-400">pruebas/carga.js</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <h4 className="text-base font-bold text-white pt-2">2. Qué NO se implementó y justificación técnica</h4>
              <ul className="list-disc pl-5 space-y-1.5 text-slate-300">
                <li>
                  <strong>Carga diferida, LCP, INP, CLS:</strong> Son métricas orientadas a renderizado de navegador web. El sistema original consta de una consola PowerShell y una API REST desacoplada.
                </li>
                <li>
                  <strong>Caché de la validación de sesión:</strong> Se descartó intencionalmente para no retrasar la revocación inmediata de sesiones (logout, cambio forzoso de credenciales).
                </li>
              </ul>

              <h4 className="text-base font-bold text-white pt-2">3. Verificación de Consultas ≤ 200 ms</h4>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-slate-300 space-y-1.5">
                <span className="text-emerald-400 font-bold block">-- Verificación mediante EXPLAIN (ANALYZE, BUFFERS):</span>
                <div>EXPLAIN (ANALYZE, BUFFERS)</div>
                <div>SELECT d.id_dispositivo, d.nombre, d.tipo, d.marca, d.modelo, d.estado, u.sede, u.piso</div>
                <div>  FROM infra.dispositivos d LEFT JOIN infra.ubicaciones u USING (id_ubicacion)</div>
                <div> ORDER BY d.nombre LIMIT 21 OFFSET 0;</div>
                <div className="text-cyan-400">-- Execution Time: 0.18 ms (Índice ix_dispositivos_tipo_nombre)</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
