import React, { useState } from 'react';
import {
  Wrench,
  Calendar,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Plus,
  Search,
  Filter,
  User,
  Check,
  X,
  FileCheck,
} from 'lucide-react';
import {
  Mantenimiento,
  Dispositivo,
  TipoMantenimiento,
  EstadoMantenimiento,
  RolUsuario,
} from '../types/network';

interface MaintenanceManagerProps {
  mantenimientos: Mantenimiento[];
  dispositivos: Dispositivo[];
  rolActual: RolUsuario;
  onAddMantenimiento: (m: Mantenimiento) => void;
  onUpdateMantenimiento: (m: Mantenimiento) => void;
}

export const MaintenanceManager: React.FC<MaintenanceManagerProps> = ({
  mantenimientos,
  dispositivos,
  rolActual,
  onAddMantenimiento,
  onUpdateMantenimiento,
}) => {
  const [filtroEstado, setFiltroEstado] = useState<string>('todos');
  const [filtroTipo, setFiltroTipo] = useState<string>('todos');
  const [busqueda, setBusqueda] = useState('');
  const [mostrarModalNuevo, setMostrarModalNuevo] = useState(false);
  const [mantenimientoAEditar, setMantenimientoAEditar] = useState<Mantenimiento | null>(null);
  const [cierreObservacion, setCierreObservacion] = useState('');

  // Form states
  const [dispId, setDispId] = useState(dispositivos[0]?.id_dispositivo || '');
  const [tipoMant, setTipoMant] = useState<TipoMantenimiento>('preventivo');
  const [fechaProg, setFechaProg] = useState(
    new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]
  );
  const [desc, setDesc] = useState('');

  const filtrados = mantenimientos.filter((m) => {
    const matchEstado = filtroEstado === 'todos' || m.estado === filtroEstado;
    const matchTipo = filtroTipo === 'todos' || m.tipo === filtroTipo;
    const matchBusqueda =
      (m.dispositivo_nombre || '').toLowerCase().includes(busqueda.toLowerCase()) ||
      m.descripcion.toLowerCase().includes(busqueda.toLowerCase()) ||
      (m.usuario_nombre || '').toLowerCase().includes(busqueda.toLowerCase());
    return matchEstado && matchTipo && matchBusqueda;
  });

  const handleCrear = (e: React.FormEvent) => {
    e.preventDefault();
    if (!desc || !dispId) return;

    const disp = dispositivos.find((d) => d.id_dispositivo === dispId);

    const nuevo: Mantenimiento = {
      id_mantenimiento: 'm-' + Date.now(),
      id_dispositivo: dispId,
      dispositivo_nombre: disp ? disp.nombre : 'Equipo Red',
      id_usuario: 'usr-1',
      usuario_nombre:
        rolActual === 'administrador'
          ? 'Ing. Carlos Mendoza (Admin)'
          : 'Tec. Raúl Huamán',
      tipo: tipoMant,
      descripcion: desc.trim(),
      estado: 'programado',
      fecha_programada: fechaProg,
      fecha_registro: new Date().toISOString(),
    };

    onAddMantenimiento(nuevo);
    setMostrarModalNuevo(false);
    setDesc('');
  };

  const handleCompletar = (m: Mantenimiento) => {
    const updated: Mantenimiento = {
      ...m,
      estado: 'completado',
      fecha_realizada: new Date().toISOString().split('T')[0],
      observaciones_cierre:
        cierreObservacion.trim() || 'Mantenimiento ejecutado y verificado conforme a protocolo.',
    };
    onUpdateMantenimiento(updated);
    setMantenimientoAEditar(null);
    setCierreObservacion('');
  };

  const handleCambiarEstado = (m: Mantenimiento, nuevoEstado: EstadoMantenimiento) => {
    onUpdateMantenimiento({
      ...m,
      estado: nuevoEstado,
    });
  };

  const getEstadoBadge = (estado: EstadoMantenimiento) => {
    switch (estado) {
      case 'programado':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30 flex items-center gap-1 w-fit">
            <Clock className="w-3 h-3" /> Programado
          </span>
        );
      case 'en_curso':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/15 text-amber-400 border border-amber-500/30 flex items-center gap-1 w-fit">
            <Wrench className="w-3 h-3 animate-spin" /> En Curso
          </span>
        );
      case 'completado':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 w-fit">
            <CheckCircle2 className="w-3 h-3" /> Completado
          </span>
        );
      case 'cancelado':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-red-500/15 text-red-400 border border-red-500/30 flex items-center gap-1 w-fit">
            <X className="w-3 h-3" /> Cancelado
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with MNTN Style */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-3 text-[#FBD784] text-xs font-bold uppercase tracking-[0.2em]">
            <span className="w-10 h-0.5 bg-[#FBD784]" />
            <span>OPERACIONES TÉCNICAS / TRAZABILIDAD</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-[-0.02em] flex items-center gap-3">
            <Wrench className="w-6 h-6 text-amber-400" />
            Gestión y Trazabilidad de Mantenimientos
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-[65ch] leading-relaxed">
            Control de ciclos preventivos, correctivos e inspecciones físicas de los activos de la MDASA.
          </p>
        </div>

        {rolActual !== 'consulta' && (
          <button
            onClick={() => setMostrarModalNuevo(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#FBD784] hover:bg-[#ffe39d] text-[#0B1D26] text-xs font-bold uppercase tracking-wider shadow-lg shadow-[#FBD784]/20 transition-all duration-150 active:scale-[0.97]"
          >
            <Plus className="w-4 h-4 text-[#0B1D26]" />
            Nueva Orden de Mantenimiento
          </button>
        )}
      </div>

      {/* Filters Bar with MNTN Glass Material */}
      <div className="p-5 rounded-3xl bg-[#0B1D26]/85 backdrop-blur-xl border border-white/[0.08] shadow-xl grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#FBD784]" />
          <input
            type="text"
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            placeholder="Buscar por equipo o descripción..."
            className="w-full pl-10 pr-4 py-2.5 bg-[#0B1D26] border border-white/[0.1] rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#FBD784] transition-colors"
          />
        </div>

        <div>
          <select
            value={filtroEstado}
            onChange={(e) => setFiltroEstado(e.target.value)}
            className="w-full px-3 py-2 bg-slate-950/80 border border-slate-700/80 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
          >
            <option value="todos">Todos los Estados</option>
            <option value="programado">Programados</option>
            <option value="en_curso">En Curso</option>
            <option value="completado">Completados</option>
            <option value="cancelado">Cancelados</option>
          </select>
        </div>

        <div>
          <select
            value={filtroTipo}
            onChange={(e) => setFiltroTipo(e.target.value)}
            className="w-full px-3 py-2 bg-slate-950/80 border border-slate-700/80 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
          >
            <option value="todos">Todos los Tipos</option>
            <option value="preventivo">Preventivo</option>
            <option value="correctivo">Correctivo</option>
            <option value="inspeccion">Inspección Técnica</option>
          </select>
        </div>
      </div>

      {/* Main List */}
      <div className="space-y-3">
        {filtrados.map((m) => (
          <div
            key={m.id_mantenimiento}
            className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 hover:border-slate-700 transition space-y-3"
          >
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-800/80 pb-2">
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-sm text-blue-400">
                  {m.dispositivo_nombre}
                </span>
                <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                  {m.tipo}
                </span>
              </div>
              <div className="flex items-center gap-3">
                {getEstadoBadge(m.estado)}
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-500" />
                  Prog: {m.fecha_programada}
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-200 leading-relaxed font-sans">{m.descripcion}</p>

            {m.observaciones_cierre && (
              <div className="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-900/40 text-xs text-emerald-300">
                <strong>Bitácora de Cierre:</strong> {m.observaciones_cierre} (Realizado:{' '}
                {m.fecha_realizada})
              </div>
            )}

            <div className="pt-1 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-slate-500" />
                <span>Responsable: <strong className="text-slate-300">{m.usuario_nombre}</strong></span>
              </div>

              {rolActual !== 'consulta' && (
                <div className="flex items-center gap-2">
                  {m.estado === 'programado' && (
                    <button
                      onClick={() => handleCambiarEstado(m, 'en_curso')}
                      className="px-2.5 py-1 rounded bg-amber-600/20 hover:bg-amber-600/30 text-amber-400 text-[11px] font-semibold border border-amber-600/40"
                    >
                      Iniciar Mantenimiento
                    </button>
                  )}
                  {m.estado === 'en_curso' && (
                    <button
                      onClick={() => setMantenimientoAEditar(m)}
                      className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-semibold shadow-sm"
                    >
                      Completar y Cerrar
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Modal Completar Mantenimiento */}
      {mantenimientoAEditar && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-emerald-400" />
              Finalizar Orden de Mantenimiento
            </h3>
            <p className="text-xs text-slate-400">
              Equipo: <strong className="text-white">{mantenimientoAEditar.dispositivo_nombre}</strong>
            </p>

            <div className="space-y-1.5 text-xs">
              <label className="text-slate-300">Observaciones Técnicas de Cierre:</label>
              <textarea
                rows={3}
                value={cierreObservacion}
                onChange={(e) => setCierreObservacion(e.target.value)}
                placeholder="Indique los componentes revisados, reemplazos o mediciones realizadas..."
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setMantenimientoAEditar(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium"
              >
                Cancelar
              </button>
              <button
                onClick={() => handleCompletar(mantenimientoAEditar)}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold"
              >
                Registrar Cierre en BD
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Nueva Orden */}
      {mostrarModalNuevo && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleCrear}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-blue-400" />
                Programar Orden de Mantenimiento
              </h3>
              <button
                type="button"
                onClick={() => setMostrarModalNuevo(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-slate-400">Dispositivo a Intervenir</label>
                <select
                  value={dispId}
                  onChange={(e) => setDispId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
                >
                  {dispositivos.map((d) => (
                    <option key={d.id_dispositivo} value={d.id_dispositivo}>
                      {d.nombre} ({d.marca} {d.modelo})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-400">Tipo de Intervención</label>
                  <select
                    value={tipoMant}
                    onChange={(e) => setTipoMant(e.target.value as TipoMantenimiento)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="preventivo">Preventivo Programado</option>
                    <option value="correctivo">Correctivo por Incidencia</option>
                    <option value="inspeccion">Inspección de Rutina</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-400">Fecha Programada</label>
                  <input
                    type="date"
                    required
                    value={fechaProg}
                    onChange={(e) => setFechaProg(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  >
                  </input>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-400">Descripción del Trabajo a Realizar</label>
                <textarea
                  required
                  rows={3}
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  placeholder="Detalle los objetivos del mantenimiento, revisiones eléctricas, firmware, etc."
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setMostrarModalNuevo(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md shadow-blue-600/30"
              >
                Registrar en PostgreSQL
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
