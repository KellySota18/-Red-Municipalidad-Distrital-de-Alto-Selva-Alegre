import React from 'react';
import {
  Server,
  ShieldCheck,
  Layers,
  Wrench,
  Wifi,
  Zap,
  ArrowUpRight,
  AlertTriangle,
  CheckCircle,
  Network,
  Activity,
  Cpu,
  HardDrive,
  ExternalLink,
} from 'lucide-react';
import { Dispositivo, Vlan, Mantenimiento } from '../types/network';

interface DashboardProps {
  dispositivos: Dispositivo[];
  vlans: Vlan[];
  mantenimientos: Mantenimiento[];
  onNavigate: (tab: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  dispositivos,
  vlans,
  mantenimientos,
  onNavigate,
}) => {
  const servidores = dispositivos.filter((d) => d.tipo === 'servidor');
  const enrutadores = dispositivos.filter((d) => d.tipo === 'router' || d.tipo === 'firewall');
  const switches = dispositivos.filter((d) => d.tipo === 'switch');
  const mantPendientes = mantenimientos.filter(
    (m) => m.estado === 'programado' || m.estado === 'en_curso'
  );

  return (
    <div className="space-y-6">
      {/* Welcome Banner with MDASA Official Crest and Apple-style lighting */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 border border-white/[0.08] p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-96 h-96 bg-blue-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-16 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="flex items-start gap-5">
            {/* Illuminated Official Coat of Arms */}
            <div className="hidden sm:flex shrink-0 w-16 h-20 rounded-2xl bg-gradient-to-b from-white/95 to-slate-200 p-1.5 shadow-2xl ring-1 ring-white/20 items-center justify-center">
              <img
                src="/assets/aistudio/escudo_municidad_af859de9.jpg"
                alt="Escudo MDASA"
                className="w-full h-full object-contain shrink-0"
              />
            </div>

            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-300 text-xs font-semibold border border-emerald-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Infraestructura Crítica Municipal · Red MDASA (1992)
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-[-0.02em]">
                Panel de Control de Telecomunicaciones
              </h2>
              <p className="text-slate-300 text-xs sm:text-sm max-w-[65ch] leading-relaxed">
                Supervisión de la topología lógica, inventario de hardware y auditoría de seguridad
                perimetral con reglas ACL del edificio central, sede Roosevelt y Seguridad Ciudadana.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => onNavigate('rendimiento')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-medium text-xs sm:text-sm shadow-lg shadow-amber-600/30 transition-all duration-150 active:scale-[0.97]"
            >
              <Zap className="w-4 h-4 text-white" />
              ⚡ Pruebas de Carga
            </button>
            <button
              onClick={() => onNavigate('acls')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs sm:text-sm shadow-lg shadow-blue-600/30 transition-all duration-150 active:scale-[0.97]"
            >
              <ShieldCheck className="w-4 h-4" />
              Simular Tráfico ACL
            </button>
            <button
              onClick={() => onNavigate('vlans')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 font-medium text-xs sm:text-sm border border-white/[0.08] transition-all duration-150 active:scale-[0.97]"
            >
              <Network className="w-4 h-4 text-cyan-400" />
              Topología TO-BE
            </button>
          </div>
        </div>
      </div>

      {/* Primary KPI Cards with Apple/Emil Micro-Interactions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Activos Totales */}
        <div
          onClick={() => onNavigate('dispositivos')}
          className="group cursor-pointer bg-slate-900/70 hover:bg-slate-850/90 p-5 rounded-2xl border border-white/[0.08] hover:border-blue-500/50 transition-all duration-150 shadow-lg shadow-black/20 active:scale-[0.98]"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Activos de Red
            </span>
            <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400 group-hover:bg-blue-600 group-hover:text-white transition-all duration-200">
              <Server className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white tracking-[-0.02em] tabular-nums">
              {dispositivos.length}
            </span>
            <span className="text-xs text-emerald-400 font-semibold tabular-nums">100% Catálogo</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            {servidores.length} Servidores · {enrutadores.length} Ruteo/FW · {switches.length} Switches
          </p>
        </div>

        {/* Card 2: Segmentación VLAN */}
        <div
          onClick={() => onNavigate('vlans')}
          className="group cursor-pointer bg-slate-900/70 hover:bg-slate-850/90 p-5 rounded-2xl border border-white/[0.08] hover:border-cyan-500/50 transition-all duration-150 shadow-lg shadow-black/20 active:scale-[0.98]"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              VLANs Propuestas
            </span>
            <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 group-hover:bg-cyan-600 group-hover:text-white transition-all duration-200">
              <Layers className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white tracking-[-0.02em] tabular-nums">
              {vlans.length}
            </span>
            <span className="text-xs text-cyan-400 font-semibold">IEEE 802.1Q</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            VLAN 10, 20, 30, 40, 50 y 99 (Gestión aislada)
          </p>
        </div>

        {/* Card 3: Seguridad y ACLs */}
        <div
          onClick={() => onNavigate('acls')}
          className="group cursor-pointer bg-slate-900/70 hover:bg-slate-850/90 p-5 rounded-2xl border border-white/[0.08] hover:border-emerald-500/50 transition-all duration-150 shadow-lg shadow-black/20 active:scale-[0.98]"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Políticas de Seguridad
            </span>
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-600 group-hover:text-white transition-all duration-200">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white tracking-[-0.02em] tabular-nums">
              18
            </span>
            <span className="text-xs text-emerald-400 font-semibold tabular-nums">100% Pasaron</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Deny-by-default · Inspección Stateful FortiGate
          </p>
        </div>

        {/* Card 4: Mantenimientos */}
        <div
          onClick={() => onNavigate('mantenimiento')}
          className="group cursor-pointer bg-slate-900/70 hover:bg-slate-850/90 p-5 rounded-2xl border border-white/[0.08] hover:border-amber-500/50 transition-all duration-150 shadow-lg shadow-black/20 active:scale-[0.98]"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Mantenimientos
            </span>
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 group-hover:bg-amber-600 group-hover:text-white transition-all duration-200">
              <Wrench className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white tracking-[-0.02em] tabular-nums">
              {mantPendientes.length}
            </span>
            <span className="text-xs text-amber-400 font-semibold tabular-nums">Pendientes</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Algoritmo dinámico por meses de ciclo preventivo
          </p>
        </div>
      </div>

      {/* Network Links & Real-Time Telemetry Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Enlaces Críticos */}
        <div className="lg:col-span-2 bg-slate-900/70 rounded-2xl border border-slate-800 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-blue-400" />
              Estado Operativo de Enlaces y Conectividad MDASA
            </h3>
            <span className="text-xs text-slate-400">Monitoreo SNMP & Link-Status</span>
          </div>

          <div className="space-y-3">
            {/* Link 1: Troncal Fibra Misticom */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400 border border-blue-500/20">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-200">
                    Troncal Fibra Óptica (ISP Misticom)
                  </h4>
                  <p className="text-xs text-slate-400">
                    Phyhome EPON ONU → FortiGate 90G (G0/0) · 200 Mbps Simétrico
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Online (Latencia 4ms)
                </span>
              </div>
            </div>

            {/* Link 2: Radioenlace Ubiquiti Sede Roosevelt */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400 border border-indigo-500/20">
                  <Wifi className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-200">
                    Radioenlace PtP 5GHz Sede Roosevelt
                  </h4>
                  <p className="text-xs text-slate-400">
                    Ubiquiti PowerBeam 5AC Gen2 · Subred 10.0.2.0/24 · RSSI -58 dBm
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Conectado (150 Mbps)
                </span>
              </div>
            </div>

            {/* Link 3: Serenazgo / Seguridad Ciudadana */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-cyan-500/10 flex items-center justify-center text-cyan-400 border border-cyan-500/20">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-200">
                    Enlace UTP Seguridad Ciudadana (Serenazgo)
                  </h4>
                  <p className="text-xs text-slate-400">
                    Cable UTP Cat6 Blindado · Monitoreo de Cámaras y Radiocomunicación
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Gigabit Activo
                </span>
              </div>
            </div>

            {/* Link 4: Respaldo Energético Data Center */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400 border border-amber-500/20">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-200">
                    Sistema UPS On-Line APC SRV1KRI (Rack Piso 4)
                  </h4>
                  <p className="text-xs text-slate-400">
                    1000 VA / 800 W · Carga actual: 62% · Autonomía estimada: 42 min
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                  AC Normal (100% Bat)
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Diagnóstico AS-IS vs TO-BE */}
        <div className="bg-slate-900/70 rounded-2xl border border-slate-800 p-5 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                Transición Arquitectónica
              </h3>
              <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800">
                AS-IS ➔ TO-BE
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Rediseño para mitigar dominios de colisión y cumplir con estándares gubernamentales de seguridad.
            </p>

            <div className="mt-4 space-y-3">
              <div className="p-3 rounded-lg bg-red-950/30 border border-red-900/40 text-xs space-y-1">
                <div className="font-semibold text-red-300 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                  Arquitectura Actual (AS-IS):
                </div>
                <p className="text-slate-300">
                  Topología plana (10.0.0.0/24). Broadcasts globales descontrolados, sin aislamiento
                  entre usuarios e impresoras y servidores críticos del SIAF expuestos directamente.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-900/40 text-xs space-y-1">
                <div className="font-semibold text-emerald-300 flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                  Arquitectura Propuesta (TO-BE):
                </div>
                <p className="text-slate-300">
                  Segmentación 802.1Q en 6 VLANs independientes. Filtrado estatal estricto (ACLs),
                  aislamiento de puertos y VLAN 99 Out-of-Band con SSH/SNMPv3.
                </p>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('documentacion')}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
          >
            Ver Dictamen Técnico del Proyecto
            <ArrowUpRight className="w-3.5 h-3.5 text-cyan-400" />
          </button>
        </div>
      </div>

      {/* Architecture Graphic Preview & Servidores Críticos */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Diagram Card */}
        <div className="lg:col-span-2 bg-slate-900/70 rounded-2xl border border-slate-800 p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Network className="w-4 h-4 text-blue-400" />
                Diagrama Topológico de Red (Packet Tracer / Cisco)
              </h3>
              <p className="text-xs text-slate-400">
                Distribución física de los 4 pisos de la Municipalidad, Data Center, Roosevelt y Serenazgo
              </p>
            </div>
            <button
              onClick={() => onNavigate('vlans')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1"
            >
              Explorar Topología ➔
            </button>
          </div>

          <div className="relative overflow-hidden rounded-xl bg-slate-950 border border-slate-800 group">
            <img
              src="/assets/arquitectura.png"
              alt="Arquitectura de Red MDASA"
              className="w-full h-64 object-contain bg-slate-950/90 group-hover:scale-[1.02] transition duration-300"
              onError={(e) => {
                // Fallback if image path differs
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
            <div className="p-3 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <span className="font-mono text-cyan-400">Diagrama Oficial MDASA - Computación en Red II</span>
              <span>FortiGate 90G · MikroTik L009 · TP-Link Omada PoE · Switches Huawei</span>
            </div>
          </div>
        </div>

        {/* Servidores del Estado MDASA */}
        <div className="bg-slate-900/70 rounded-2xl border border-slate-800 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Server className="w-4 h-4 text-cyan-400" />
              Servidores Centrales
            </h3>
            <span className="text-xs text-slate-400">VLAN 10</span>
          </div>

          <div className="space-y-2.5">
            {servidores.map((srv) => (
              <div
                key={srv.id_dispositivo}
                className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 hover:border-slate-700 transition"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-blue-400">{srv.nombre}</span>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    {srv.estado}
                  </span>
                </div>
                <div className="text-xs text-slate-300 mt-1">{srv.modelo}</div>
                <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">{srv.observaciones}</p>
                {srv.interfaces && srv.interfaces[0] && (
                  <div className="mt-2 pt-1.5 border-t border-slate-800/60 flex items-center justify-between text-[11px] font-mono text-slate-400">
                    <span>IP: {srv.interfaces[0].ip}</span>
                    <span className="text-cyan-400">{srv.interfaces[0].nombre}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
