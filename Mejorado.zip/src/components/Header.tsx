import React from 'react';
import {
  Shield,
  Server,
  Activity,
  Layers,
  Terminal,
  FileText,
  Users,
  Wrench,
  Github,
  CheckCircle2,
  Lock,
  Zap,
  Mountain,
} from 'lucide-react';
import { RolUsuario } from '../types/network';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  rolActual: RolUsuario;
  setRolActual: (rol: RolUsuario) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  rolActual,
  setRolActual,
}) => {
  const tabs = [
    { id: 'landing', label: 'Inicio (MNTN)', icon: Mountain },
    { id: 'dashboard', label: 'Dashboard', icon: Activity },
    { id: 'dispositivos', label: 'Inventario', icon: Server },
    { id: 'acls', label: 'Seguridad ACL', icon: Shield },
    { id: 'rendimiento', label: 'Rendimiento', icon: Zap },
    { id: 'vlans', label: 'VLANs', icon: Layers },
    { id: 'mantenimiento', label: 'Mantenimientos', icon: Wrench },
    { id: 'terminal', label: 'PowerShell RedCli', icon: Terminal },
    { id: 'documentacion', label: 'Documentos', icon: FileText },
    { id: 'usuarios', label: 'Usuarios', icon: Users },
  ];

  return (
    <header className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-xl border-b border-white/[0.08] shadow-[0_4px_24px_rgba(0,0,0,0.4)]">
      {/* Top Banner with MDASA Official Coat of Arms & Role Selector */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between py-2.5 gap-3 border-b border-white/[0.06]">
          <div className="flex items-center gap-3.5">
            {/* Official MDASA Coat of Arms as Application Logo */}
            <div className="relative group shrink-0">
              <div className="w-12 h-14 rounded-xl bg-gradient-to-b from-white/95 via-white/90 to-slate-100 p-1 shadow-lg shadow-emerald-950/40 ring-1 ring-white/20 flex items-center justify-center overflow-hidden transition-transform duration-200 group-hover:scale-105">
                <img
                  src="/assets/aistudio/escudo_municidad_af859de9.jpg"
                  alt="Escudo Oficial Municipalidad Distrital de Alto Selva Alegre"
                  className="w-full h-full object-contain shrink-0"
                />
              </div>
              <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 ring-2 ring-slate-950 flex items-center justify-center">
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></span>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-base sm:text-lg font-extrabold text-white tracking-[-0.02em] flex items-center gap-2">
                  Municipalidad Distrital de Alto Selva Alegre
                </h1>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 tabular-nums">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  MDASA · 1992
                </span>
              </div>
              <p className="text-xs text-slate-400 max-w-[65ch] leading-relaxed">
                Sistema de Inventario, Gestión de Red y Telecomunicaciones y Simulación de Seguridad ACL
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* GitHub Repository Reference */}
            <a
              href="https://github.com/KellySota18/-Red-Municipalidad-Distrital-de-Alto-Selva-Alegre"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white border border-white/[0.08] text-xs font-medium transition-all duration-150 active:scale-[0.97]"
              title="Ver repositorio original en GitHub"
            >
              <Github className="w-3.5 h-3.5 text-slate-200" />
              <span>KellySota18 / MDASA</span>
            </a>

            {/* Role Switcher for RBAC Testing */}
            <div className="flex items-center bg-slate-900/90 p-1 rounded-xl border border-white/[0.08] shadow-inner">
              <span className="text-[11px] font-semibold text-slate-400 px-2 flex items-center gap-1">
                <Lock className="w-3 h-3 text-amber-400" /> Rol:
              </span>
              {(['administrador', 'tecnico', 'consulta'] as RolUsuario[]).map((rol) => (
                <button
                  key={rol}
                  onClick={() => setRolActual(rol)}
                  className={`text-xs px-2.5 py-1 rounded-lg font-medium capitalize transition-all duration-150 active:scale-[0.97] ${
                    rolActual === rol
                      ? rol === 'administrador'
                        ? 'bg-red-600 text-white shadow-md shadow-red-900/40 font-semibold'
                        : rol === 'tecnico'
                        ? 'bg-blue-600 text-white shadow-md shadow-blue-900/40 font-semibold'
                        : 'bg-emerald-600 text-white shadow-md shadow-emerald-900/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.04]'
                  }`}
                >
                  {rol}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Navigation Tabs with Apple/Emil Micro-Interactions */}
        <nav className="flex space-x-1.5 overflow-x-auto py-2.5 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-medium rounded-xl whitespace-nowrap transition-all duration-150 active:scale-[0.97] ${
                  isActive
                    ? 'bg-[#FBD784] text-[#0B1D26] shadow-lg shadow-[#FBD784]/25 font-bold ring-1 ring-[#FBD784]/50'
                    : 'text-slate-300 hover:text-white hover:bg-white/[0.06]'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-[#0B1D26]' : 'text-[#FBD784]/80'}`} />
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
