import React, { useState } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ArrowRight,
  Radio,
  Sliders,
  Check,
  Flame,
  AlertTriangle,
  Lock,
} from 'lucide-react';
import {
  simularPaqueteAcl,
  ZonaId,
  DestinoId,
  ServicioId,
  SERVICIOS_LISTA,
  SimulacionResultado,
  FLUJOS_DEFINIDOS,
} from '../services/aclSimulator';
import { INITIAL_PACKET_TRACER_PRUEBAS } from '../data/mockData';
import { PruebaPacketTracer } from '../types/network';

export const AclSimulatorView: React.FC = () => {
  const [origenZona, setOrigenZona] = useState<ZonaId>('X');
  const [destinoId, setDestinoId] = useState<DestinoId>('SERVERS');
  const [servicioId, setServicioId] = useState<ServicioId>('tcp443');
  const [resultado, setResultado] = useState<SimulacionResultado | null>(null);
  const [animando, setAnimando] = useState(false);

  // Suite de pruebas
  const [pruebas, setPruebas] = useState<PruebaPacketTracer[]>(INITIAL_PACKET_TRACER_PRUEBAS);
  const [suiteEjecutada, setSuiteEjecutada] = useState(false);
  const [tabInterno, setTabInterno] = useState<'simulador' | 'suite' | 'politicas'>('simulador');

  const ejecutarSimulacion = () => {
    setAnimando(true);
    setTimeout(() => {
      const res = simularPaqueteAcl(origenZona, destinoId, servicioId);
      setResultado(res);
      setAnimando(false);
    }, 300);
  };

  const ejecutarSuiteCompleta = () => {
    const actualizadas = pruebas.map((p) => {
      // Map Packet Tracer host to zone
      let oz: ZonaId = 'X';
      if (p.desde.includes('PC1')) oz = 'X';
      else if (p.desde.includes('PC7')) oz = 'Y';
      else if (p.desde.includes('ADMIN')) oz = 'MGMT';

      // Map destination
      let dz: DestinoId = 'SERVERS';
      if (p.ipDestino.includes('10.10.10.')) dz = 'SERVERS';
      else if (p.ipDestino.includes('10.10.20.')) dz = 'PRINTERS';
      else if (p.ipDestino.includes('10.10.40.')) dz = 'Y';
      else if (p.ipDestino.includes('10.10.30.')) dz = 'X';
      else if (p.ipDestino === '10.0.1.2') dz = 'R1B';
      else if (p.ipDestino === '10.10.99.1') dz = 'MGMT_GW';
      else if (p.ipDestino === '10.10.99.10') dz = 'MGMT_HOST';
      else if (p.ipDestino.includes('203.0.113.')) dz = 'INTERNET';

      const res = simularPaqueteAcl(oz, dz, p.servicio as ServicioId);
      return {
        ...p,
        resultado: res.permitido ? ('permitido' as const) : ('bloqueado' as const),
      };
    });

    setPruebas(actualizadas);
    setSuiteEjecutada(true);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner with MNTN Style Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-3 text-[#FBD784] text-xs font-bold uppercase tracking-[0.2em]">
            <span className="w-10 h-0.5 bg-[#FBD784]" />
            <span>SECCIÓN 02 / POLÍTICAS DE ACCESO & HARDENING</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-[-0.02em] flex items-center gap-3">
            <ShieldCheck className="w-6 h-6 text-emerald-400" />
            Simulador de Tráfico y Auditoría de Reglas ACL
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-[65ch] leading-relaxed">
            Motor de validación de paquetes conforme al esquema seguro de Cisco IOS y FortiOS implementado para MDASA.
          </p>
        </div>

        {/* Sub-tabs with MNTN Gold Active State */}
        <div className="flex items-center p-1 rounded-2xl bg-[#0B1D26]/90 border border-white/[0.08] shadow-inner">
          <button
            onClick={() => setTabInterno('simulador')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all duration-150 active:scale-[0.97] ${
              tabInterno === 'simulador'
                ? 'bg-[#FBD784] text-[#0B1D26] shadow-md shadow-[#FBD784]/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Simulador Interactivo
          </button>
          <button
            onClick={() => setTabInterno('suite')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all duration-150 active:scale-[0.97] ${
              tabInterno === 'suite'
                ? 'bg-[#FBD784] text-[#0B1D26] shadow-md shadow-[#FBD784]/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Suite Packet Tracer (18)
          </button>
          <button
            onClick={() => setTabInterno('politicas')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all duration-150 active:scale-[0.97] ${
              tabInterno === 'politicas'
                ? 'bg-[#FBD784] text-[#0B1D26] shadow-md shadow-[#FBD784]/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Matriz Institucional
          </button>
        </div>
      </div>

      {tabInterno === 'simulador' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls Form: 5 cols with MNTN Glass Material */}
          <div className="lg:col-span-5 bg-[#0B1D26]/85 backdrop-blur-xl rounded-3xl border border-white/[0.08] p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-[#FBD784]" />
                Parámetros del Paquete de Red
              </h3>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-[#FBD784]/15 text-[#FBD784] border border-[#FBD784]/30">
                L3 / L4 / L7
              </span>
            </div>

            {/* Selector de Origen */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                1. Zona / Host de Origen:
              </label>
              <select
                value={origenZona}
                onChange={(e) => setOrigenZona(e.target.value as ZonaId)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
              >
                <option value="X">PC1 · VLAN 30 AREA_X (Pisos 1 y 3) [10.10.30.10]</option>
                <option value="Y">PC7 · VLAN 40 AREA_Y (Pisos 2 y 4) [10.10.40.11]</option>
                <option value="MGMT">ADMIN · VLAN 99 MGMT (Gestión) [10.10.99.10]</option>
                <option value="SERVERS">Server3 · VLAN 10 SERVERS [10.10.10.20]</option>
                <option value="PRINTERS">Printer6 · VLAN 20 PRINTERS [10.10.20.20]</option>
                <option value="INTERNET">Internet WAN (Misticom) [203.0.113.10]</option>
              </select>
            </div>

            {/* Selector de Destino */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                2. Destino del Paquete:
              </label>
              <select
                value={destinoId}
                onChange={(e) => setDestinoId(e.target.value as DestinoId)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
              >
                <option value="SERVERS">VLAN 10 SERVERS (10.10.10.0/24 - SIAF/BD)</option>
                <option value="PRINTERS">VLAN 20 PRINTERS (10.10.20.0/24)</option>
                <option value="X">VLAN 30 AREA_X (10.10.30.0/24)</option>
                <option value="Y">VLAN 40 AREA_Y (10.10.40.0/24)</option>
                <option value="R1B">Router MikroTik R1B (10.0.1.2)</option>
                <option value="MGMT_GW">Gateway Virtual FortiGate (10.10.99.1)</option>
                <option value="MGMT_HOST">Estación Admin MGMT (10.10.99.10)</option>
                <option value="INTERNET">Internet Pública (any)</option>
              </select>
            </div>

            {/* Selector de Servicio */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                3. Servicio / Protocolo y Puerto:
              </label>
              <select
                value={servicioId}
                onChange={(e) => setServicioId(e.target.value as ServicioId)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
              >
                {SERVICIOS_LISTA.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.nombre} - {s.descripcion}
                  </option>
                ))}
              </select>
            </div>

            {/* Quick Test Presets */}
            <div className="space-y-1.5 pt-2">
              <span className="text-[11px] font-semibold text-slate-400">
                Casos Críticos de Seguridad Municipal:
              </span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setOrigenZona('X');
                    setDestinoId('SERVERS');
                    setServicioId('tcp443');
                  }}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-left text-[11px] text-slate-300 hover:text-white transition-all duration-150 active:scale-[0.97]"
                >
                  <span className="text-emerald-400 font-bold block">✓ Acceso SIAF Seguro</span>
                  Área X ➔ Servers : 443
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setOrigenZona('X');
                    setDestinoId('SERVERS');
                    setServicioId('tcp80');
                  }}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-left text-[11px] text-slate-300 hover:text-white transition-all duration-150 active:scale-[0.97]"
                >
                  <span className="text-red-400 font-bold block">✕ Intento HTTP Inseguro</span>
                  Área X ➔ Servers : 80
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setOrigenZona('X');
                    setDestinoId('R1B');
                    setServicioId('tcp23');
                  }}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-left text-[11px] text-slate-300 hover:text-white transition-all duration-150 active:scale-[0.97]"
                >
                  <span className="text-red-400 font-bold block">✕ Intento Telnet R1B</span>
                  Área X ➔ R1B : 23
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setOrigenZona('MGMT');
                    setDestinoId('R1B');
                    setServicioId('tcp22');
                  }}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-left text-[11px] text-slate-300 hover:text-white transition-all duration-150 active:scale-[0.97]"
                >
                  <span className="text-emerald-400 font-bold block">✓ SSH Autorizado</span>
                  MGMT ➔ R1B : 22
                </button>
              </div>
            </div>

            <button
              onClick={ejecutarSimulacion}
              disabled={animando}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-[#FBD784] hover:bg-[#ffe39d] text-[#0B1D26] font-bold text-xs uppercase tracking-wider shadow-xl shadow-[#FBD784]/20 transition-all duration-150 active:scale-[0.97] disabled:opacity-50"
            >
              <Play className="w-4 h-4 fill-[#0B1D26]" />
              {animando ? 'Analizando en FortiGate...' : 'Inyectar Paquete y Auditar Regla'}
            </button>
          </div>

          {/* Results Visualizer: 7 cols with MNTN Glass Styling */}
          <div className="lg:col-span-7 bg-[#0B1D26]/85 backdrop-blur-xl rounded-3xl border border-white/[0.08] p-6 shadow-2xl flex flex-col justify-between space-y-5">
            <div>
              <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-[#FBD784]" />
                  Dictamen de la Regla ACL & Inspección Stateful
                </h3>
                {resultado && (
                  <span className="text-[11px] font-mono text-[#FBD784] tabular-nums">
                    Latencia: {resultado.tiempoProcesamientoMs} ms
                  </span>
                )}
              </div>

              {resultado ? (
                <div className="mt-4 space-y-4">
                  {/* Verdict Banner */}
                  <div
                    className={`p-4 rounded-xl border flex items-center justify-between ${
                      resultado.permitido
                        ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300 shadow-lg shadow-emerald-950/50'
                        : 'bg-red-950/40 border-red-500/50 text-red-300 shadow-lg shadow-red-950/50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`p-2.5 rounded-full ${
                          resultado.permitido
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : 'bg-red-500/20 text-red-400'
                        }`}
                      >
                        {resultado.permitido ? (
                          <CheckCircle2 className="w-7 h-7" />
                        ) : (
                          <XCircle className="w-7 h-7" />
                        )}
                      </div>
                      <div>
                        <div className="text-xs uppercase font-semibold tracking-wider opacity-80">
                          Resultado de la Inspección
                        </div>
                        <div className="text-xl font-black tracking-tight">
                          {resultado.estado}
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-mono font-bold block">
                        {resultado.aclAplicada}
                      </span>
                      <span className="text-[10px] opacity-75">Regla de Filtrado</span>
                    </div>
                  </div>

                  {/* Justificación de Seguridad */}
                  <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                      Fundamento de la Política Institucional:
                    </span>
                    <p className="text-xs text-slate-200 leading-relaxed font-sans">
                      {resultado.motivo}
                    </p>
                  </div>

                  {/* Ruta de Saltos / Traza de Paquete */}
                  <div className="space-y-2">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                      Traza de Tráfico (Packet Path):
                    </span>
                    <div className="flex flex-wrap items-center gap-2">
                      {resultado.saltoRuta.map((salto, idx) => {
                        const esUltimo = idx === resultado.saltoRuta.length - 1;
                        const esDrop = salto.includes('DROP') || salto.includes('DESCARTADO');
                        return (
                          <React.Fragment key={idx}>
                            <div
                              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium flex items-center gap-1.5 border ${
                                esDrop
                                  ? 'bg-red-950/60 border-red-800 text-red-300 font-bold'
                                  : esUltimo && resultado.permitido
                                  ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300 font-bold'
                                  : 'bg-slate-950 border-slate-800 text-slate-300'
                              }`}
                            >
                              <span>{salto}</span>
                            </div>
                            {!esUltimo && <ArrowRight className="w-3.5 h-3.5 text-slate-600" />}
                          </React.Fragment>
                        );
                      })}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="py-16 text-center space-y-3">
                  <div className="w-12 h-12 mx-auto rounded-full bg-slate-800 flex items-center justify-center text-slate-400">
                    <HelpCircle className="w-6 h-6" />
                  </div>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto">
                    Selecciona un origen, destino y protocolo en el panel izquierdo y presiona{' '}
                    <strong className="text-white">"Inyectar Paquete"</strong> para auditar la regla ACL.
                  </p>
                </div>
              )}
            </div>

            {/* Bottom info */}
            <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
              <span>Principio: <strong>Deny-by-Default</strong> (Todo lo no explícitamente permitido se descarta)</span>
              <span>FortiOS 7.x / Cisco Extended ACL</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab Suite Packet Tracer (18) */}
      {tabInterno === 'suite' && (
        <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                Plan Oficial de Pruebas de Red y ACLs (Cisco Packet Tracer)
              </h3>
              <p className="text-xs text-slate-400">
                18 pruebas sintéticas estandarizadas según la Tabla 16 y el documento de ingeniería de la MDASA.
              </p>
            </div>

            <button
              onClick={ejecutarSuiteCompleta}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-md shadow-emerald-600/30 transition"
            >
              <Play className="w-3.5 h-3.5 fill-white" />
              Ejecutar las 18 Pruebas
            </button>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-800">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider">
                  <th className="py-2.5 px-3">#</th>
                  <th className="py-2.5 px-3">Origen</th>
                  <th className="py-2.5 px-3">Comando Packet Tracer</th>
                  <th className="py-2.5 px-3">v1 (Informe)</th>
                  <th className="py-2.5 px-3">v2 (Por Defecto)</th>
                  <th className="py-2.5 px-3">Resultado Obtenido</th>
                  <th className="py-2.5 px-3">Motivo / Política</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {pruebas.map((p) => {
                  const pass = p.resultado === p.v2Esperado;
                  return (
                    <tr key={p.id} className="hover:bg-slate-800/30 transition">
                      <td className="py-2.5 px-3 text-slate-500 font-bold">{p.id}</td>
                      <td className="py-2.5 px-3 font-semibold text-blue-300">{p.desde}</td>
                      <td className="py-2.5 px-3 text-cyan-300">{p.comando}</td>
                      <td className="py-2.5 px-3 text-slate-400">{p.v1Esperado}</td>
                      <td className="py-2.5 px-3 text-slate-300">{p.v2Esperado}</td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            p.resultado === 'permitido'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                              : 'bg-red-500/20 text-red-400 border border-red-500/40'
                          }`}
                        >
                          {p.resultado?.toUpperCase() || 'PENDIENTE'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-400 font-sans text-[11px]">
                        {p.motivo}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab Matriz de Políticas P1 - P8 */}
      {tabInterno === 'politicas' && (
        <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 space-y-4">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Lock className="w-5 h-5 text-cyan-400" />
              Matriz de Políticas Institucionales de Seguridad de Red (MDASA)
            </h3>
            <p className="text-xs text-slate-400">
              Definición formal de los 8 principios de filtrado y control de acceso aplicados en el firewall perimetral.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono font-bold text-cyan-400 text-xs">POLÍTICA P1</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-blue-500/10 text-blue-300">Segmentación</span>
              </div>
              <h4 className="text-sm font-semibold text-white">Aislamiento Inter-VLAN Estricto</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                El tráfico directo entre VLANs de usuarios (VLAN 30 Área X y VLAN 40 Área Y) queda totalmente denegado en capa 3 para evitar propagación de amenazas y movimiento lateral.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono font-bold text-cyan-400 text-xs">POLÍTICA P3</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300">Periféricos</span>
              </div>
              <h4 className="text-sm font-semibold text-white">Acceso a Impresoras Institucionales</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Únicamente el personal autorizado del Área X (Pisos 1 y 3) y la administración pueden imprimir vía RAW (9100), IPP (631) y LPR (515) hacia la VLAN 20.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono font-bold text-cyan-400 text-xs">POLÍTICA P5</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-300">Servidores SIAF</span>
              </div>
              <h4 className="text-sm font-semibold text-white">Cifrado Obligatorio HTTPS (443)</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Se prohíbe el protocolo HTTP no cifrado (puerto 80) hacia la VLAN 10 SERVERS. Todo acceso a SIAF, rentas y base de datos requiere TLS para impedir la interceptación de contraseñas.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono font-bold text-cyan-400 text-xs">POLÍTICA P8</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-red-500/10 text-red-300">Hardening</span>
              </div>
              <h4 className="text-sm font-semibold text-white">Prohibición Absoluta de Telnet (23)</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Telnet queda clausurado en todos los equipos de la red municipal por enviar credenciales en texto plano. La gestión de enrutadores exige SSHv2 exclusivo desde la VLAN 99 MGMT.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
