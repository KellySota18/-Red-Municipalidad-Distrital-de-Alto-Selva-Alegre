import React, { useState } from 'react';
import {
  Layers,
  Network,
  Server,
  Printer,
  Users,
  Shield,
  Radio,
  Globe,
  ArrowRight,
  Info,
  CheckCircle,
  AlertTriangle,
} from 'lucide-react';
import { Vlan, Subred } from '../types/network';

interface VlanTopologyViewProps {
  vlans: Vlan[];
  subredes: Subred[];
}

export const VlanTopologyView: React.FC<VlanTopologyViewProps> = ({ vlans, subredes }) => {
  const [vlanSeleccionada, setVlanSeleccionada] = useState<Vlan | null>(vlans[0] || null);
  const [modoDiseno, setModoDiseno] = useState<'propuesto' | 'actual'>('propuesto');

  const subredesActuales = subredes.filter((s) => s.estado_diseno === 'actual');
  const subredesPropuestas = subredes.filter((s) => s.estado_diseno === 'propuesto');

  const getVlanIcon = (nombre: string) => {
    switch (nombre) {
      case 'SERVERS':
        return <Server className="w-5 h-5 text-cyan-400" />;
      case 'PRINTERS':
        return <Printer className="w-5 h-5 text-emerald-400" />;
      case 'AREA_X':
      case 'AREA_Y':
        return <Users className="w-5 h-5 text-blue-400" />;
      case 'SEGURIDAD':
        return <Shield className="w-5 h-5 text-purple-400" />;
      case 'MGMT':
        return <Radio className="w-5 h-5 text-amber-400" />;
      default:
        return <Layers className="w-5 h-5 text-slate-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header with MNTN Style Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-3 text-[#FBD784] text-xs font-bold uppercase tracking-[0.2em]">
            <span className="w-10 h-0.5 bg-[#FBD784]" />
            <span>DISEÑO ESTRUCTURAL / IEEE 802.1Q</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-[-0.02em] flex items-center gap-3">
            <Layers className="w-6 h-6 text-[#FBD784]" />
            Topología Lógica de Red y Segmentación de VLANs
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-[65ch] leading-relaxed">
            Diseño arquitectural 802.1Q implementado para erradicar las vulnerabilidades de la red plana de la MDASA.
          </p>
        </div>

        {/* Toggle AS-IS vs TO-BE with MNTN Styling */}
        <div className="flex items-center p-1 rounded-2xl bg-[#0B1D26]/90 border border-white/[0.08] shadow-inner">
          <button
            onClick={() => setModoDiseno('propuesto')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all duration-150 active:scale-[0.97] ${
              modoDiseno === 'propuesto'
                ? 'bg-[#FBD784] text-[#0B1D26] shadow-md shadow-[#FBD784]/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
            Propuesto (TO-BE Segmentada)
          </button>
          <button
            onClick={() => setModoDiseno('actual')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all duration-150 active:scale-[0.97] ${
              modoDiseno === 'actual'
                ? 'bg-amber-600 text-white shadow-md shadow-amber-900/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-300" />
            Actual (AS-IS Red Plana)
          </button>
        </div>
      </div>

      {/* Visual Interactive Map */}
      <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Network className="w-4 h-4 text-blue-400" />
            Mapa Interactivo de Zonas y Conexiones Lógicas
          </h3>
          <span className="text-xs text-slate-400">
            {modoDiseno === 'propuesto'
              ? '6 VLANs IEEE 802.1Q con Router-on-a-Stick y FortiGate 90G'
              : '3 Subredes Planas sin Aislamiento de Broadcast'}
          </span>
        </div>

        {modoDiseno === 'propuesto' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {vlans.map((v) => {
              const isSelected = vlanSeleccionada?.id_vlan === v.id_vlan;
              return (
                <div
                  key={v.id_vlan}
                  onClick={() => setVlanSeleccionada(v)}
                  className={`p-4 rounded-xl border transition cursor-pointer flex flex-col justify-between space-y-3 ${
                    isSelected
                      ? 'bg-blue-950/40 border-blue-500 shadow-lg shadow-blue-950/60'
                      : 'bg-slate-950/70 border-slate-800/90 hover:border-slate-700 hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                        {getVlanIcon(v.nombre)}
                      </div>
                      <div>
                        <h4 className="font-mono font-bold text-sm text-white">
                          VLAN {v.numero} · {v.nombre}
                        </h4>
                        <span className="text-[10px] text-cyan-400 font-mono">
                          Gateway: {v.gateway}
                        </span>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-300 border border-blue-500/20">
                      /24
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed font-sans">{v.funcion}</p>

                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                    <span className="font-mono text-slate-400">{v.rango_ip}</span>
                    <span className="font-medium text-emerald-400">
                      {v.num_equipos ? `${v.num_equipos} Hosts aprox.` : 'Activo'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          /* AS-IS Flat Architecture */
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-900/40 text-xs text-amber-200 leading-relaxed">
              <strong>Diagnóstico de la Red Actual (AS-IS):</strong> La Municipalidad opera con una
              estructura plana dividida únicamente por tres subredes IP sin etiquetado 802.1Q. Cualquier
              infección de ransomware o tormenta de broadcast en las computadoras de atención al público
              se difunde directamente hacia los servidores de recaudación y bases de datos.
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {subredesActuales.map((sub) => (
                <div
                  key={sub.id_subred}
                  className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2"
                >
                  <span className="text-xs font-mono font-bold text-amber-400">{sub.red}</span>
                  <p className="text-xs text-white font-medium">{sub.funcion}</p>
                  <div className="text-[11px] font-mono text-slate-500">
                    Gateway: {sub.gateway}
                  </div>
                  <span className="inline-block px-2 py-0.5 rounded text-[10px] bg-red-500/10 text-red-400 border border-red-500/20">
                    Sin segmentación VLAN
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Selected VLAN Deep Dive Panel */}
      {vlanSeleccionada && modoDiseno === 'propuesto' && (
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20">
                {getVlanIcon(vlanSeleccionada.nombre)}
              </div>
              <div>
                <h3 className="text-base font-bold text-white">
                  Detalle Técnico: VLAN {vlanSeleccionada.numero} ({vlanSeleccionada.nombre})
                </h3>
                <p className="text-xs text-slate-400">
                  Subinterfaz FortiGate: G0/2.{vlanSeleccionada.numero} · Enlace Troncal IEEE 802.1Q
                </p>
              </div>
            </div>
            <span className="text-xs font-mono text-cyan-400 bg-slate-950 px-3 py-1 rounded-lg border border-slate-800">
              ID: {vlanSeleccionada.id_vlan}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <span className="text-slate-500 block">Rango de Direccionamiento</span>
              <span className="font-mono font-bold text-slate-200">{vlanSeleccionada.rango_ip}</span>
            </div>
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <span className="text-slate-500 block">Default Gateway (Puerta de Enlace)</span>
              <span className="font-mono font-bold text-cyan-400">{vlanSeleccionada.gateway}</span>
            </div>
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <span className="text-slate-500 block">Nombre de Lista ACL Asociada</span>
              <span className="font-mono font-bold text-emerald-400">
                FW_IN_VLAN{vlanSeleccionada.numero}_{vlanSeleccionada.nombre}
              </span>
            </div>
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <span className="text-slate-500 block">Máscara Subred / Wildcard</span>
              <span className="font-mono font-bold text-slate-300">255.255.255.0 (0.0.0.255)</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-1">
            <span className="text-slate-400 font-semibold block">Propósito Operativo en la Municipalidad:</span>
            <p className="leading-relaxed">{vlanSeleccionada.funcion}</p>
          </div>
        </div>
      )}

      {/* Full Subnets Matrix Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 space-y-3">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Globe className="w-4 h-4 text-blue-400" />
          Tabla Maestra de Subredes y Direccionamiento IP (DDL/DML PostgreSQL)
        </h3>

        <div className="overflow-x-auto rounded-xl border border-slate-800">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider">
                <th className="py-2.5 px-3">Red (CIDR)</th>
                <th className="py-2.5 px-3">VLAN</th>
                <th className="py-2.5 px-3">Gateway</th>
                <th className="py-2.5 px-3">Estado de Diseño</th>
                <th className="py-2.5 px-3">Función Asignada</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {subredes.map((sub) => (
                <tr key={sub.id_subred} className="hover:bg-slate-800/30 transition">
                  <td className="py-2.5 px-3 font-bold text-cyan-300">{sub.red}</td>
                  <td className="py-2.5 px-3 text-slate-300 font-sans">
                    {sub.id_vlan
                      ? vlans.find((v) => v.id_vlan === sub.id_vlan)?.nombre || 'VLAN'
                      : '— (Física)'}
                  </td>
                  <td className="py-2.5 px-3 text-blue-400">{sub.gateway}</td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        sub.estado_diseno === 'propuesto'
                          ? 'bg-blue-500/15 text-blue-400 border border-blue-500/30'
                          : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      }`}
                    >
                      {sub.estado_diseno}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-300 font-sans text-[11px]">
                    {sub.funcion}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
