import React, { useState } from 'react';
import {
  Server,
  Search,
  Filter,
  Plus,
  Edit2,
  Trash2,
  Download,
  Cpu,
  Layers,
  MapPin,
  Calendar,
  AlertCircle,
  CheckCircle,
  ExternalLink,
  Shield,
  Wifi,
  Zap,
} from 'lucide-react';
import { Dispositivo, TipoDispositivo, EstadoDispositivo, RolUsuario, Ubicacion } from '../types/network';

interface DeviceInventoryProps {
  dispositivos: Dispositivo[];
  ubicaciones: Ubicacion[];
  rolActual: RolUsuario;
  onAddDispositivo: (disp: Dispositivo) => void;
  onUpdateDispositivo: (disp: Dispositivo) => void;
}

export const DeviceInventory: React.FC<DeviceInventoryProps> = ({
  dispositivos,
  ubicaciones,
  rolActual,
  onAddDispositivo,
  onUpdateDispositivo,
}) => {
  const [busqueda, setBusqueda] = useState('');
  const [tipoFiltro, setTipoFiltro] = useState<string>('todos');
  const [estadoFiltro, setEstadoFiltro] = useState<string>('todos');
  const [vista, setVista] = useState<'tabla' | 'tarjetas'>('tabla');
  const [dispositivoSeleccionado, setDispositivoSeleccionado] = useState<Dispositivo | null>(null);
  const [mostrarModalNuevo, setMostrarModalNuevo] = useState(false);

  // Rendimiento y Paginación (Mejora: límite 20 por defecto, headers X-Pagina, X-Limite, X-Hay-Mas)
  const [pagina, setPagina] = useState<number>(1);
  const [limite, setLimite] = useState<number>(20);
  const [verTodos, setVerTodos] = useState<boolean>(false);

  // Form states
  const [nuevoNombre, setNuevoNombre] = useState('');
  const [nuevoTipo, setNuevoTipo] = useState<TipoDispositivo>('switch');
  const [nuevaMarca, setNuevaMarca] = useState('');
  const [nuevoModelo, setNuevoModelo] = useState('');
  const [nuevoSerial, setNuevoSerial] = useState('');
  const [nuevaUbicacion, setNuevaUbicacion] = useState(ubicaciones[0]?.id_ubicacion || '');
  const [nuevoMantMeses, setNuevoMantMeses] = useState(6);
  const [nuevasObs, setNuevasObs] = useState('');
  const [nuevaIp, setNuevaIp] = useState('');
  const [nuevaMac, setNuevaMac] = useState('');

  // Filtrado
  const dispositivosFiltrados = dispositivos.filter((d) => {
    const matchBusqueda =
      d.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
      d.marca.toLowerCase().includes(busqueda.toLowerCase()) ||
      d.modelo.toLowerCase().includes(busqueda.toLowerCase()) ||
      (d.interfaces &&
        d.interfaces.some(
          (i) =>
            i.ip.toLowerCase().includes(busqueda.toLowerCase()) ||
            i.mac.toLowerCase().includes(busqueda.toLowerCase())
        ));
    const matchTipo = tipoFiltro === 'todos' || d.tipo === tipoFiltro;
    const matchEstado = estadoFiltro === 'todos' || d.estado === estadoFiltro;
    return matchBusqueda && matchTipo && matchEstado;
  });

  // Paginación lógica equivalente a LIMIT + OFFSET en backend
  const totalRegistros = dispositivosFiltrados.length;
  const totalPaginas = Math.max(1, Math.ceil(totalRegistros / limite));
  const offset = (pagina - 1) * limite;
  const hayMas = !verTodos && offset + limite < totalRegistros;
  const itemsAMostrar = verTodos
    ? dispositivosFiltrados
    : dispositivosFiltrados.slice(offset, offset + limite);

  const handleCrear = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nuevoNombre || !nuevaMarca || !nuevoModelo) return;

    const nuevo: Dispositivo = {
      id_dispositivo: 'd-' + Date.now(),
      nombre: nuevoNombre.trim().toUpperCase(),
      tipo: nuevoTipo,
      marca: nuevaMarca.trim(),
      modelo: nuevoModelo.trim(),
      numero_serie: nuevoSerial.trim(),
      id_ubicacion: nuevaUbicacion,
      estado: 'operativo',
      fecha_instalacion: new Date().toISOString().split('T')[0],
      mantenimiento_cada_meses: nuevoMantMeses,
      observaciones: nuevasObs.trim(),
      interfaces: nuevaIp
        ? [
            {
              id_interfaz: 'if-' + Date.now(),
              id_dispositivo: 'd-' + Date.now(),
              nombre: 'Eth0',
              ip: nuevaIp.trim(),
              mac: nuevaMac.trim() || '00:aa:bb:cc:dd:ee',
              asignacion: 'estatica',
            },
          ]
        : [],
    };

    onAddDispositivo(nuevo);
    setMostrarModalNuevo(false);
    // Reset form
    setNuevoNombre('');
    setNuevaMarca('');
    setNuevoModelo('');
    setNuevoSerial('');
    setNuevasObs('');
    setNuevaIp('');
    setNuevaMac('');
  };

  const exportarCSV = () => {
    const headers = 'ID,Nombre,Tipo,Marca,Modelo,Serie,Estado,Piso,IP_Principal,Mantenimiento_Meses\n';
    const rows = dispositivosFiltrados
      .map((d) => {
        const u = ubicaciones.find((ub) => ub.id_ubicacion === d.id_ubicacion);
        const ip = d.interfaces?.[0]?.ip || 'N/A';
        return `"${d.id_dispositivo}","${d.nombre}","${d.tipo}","${d.marca}","${d.modelo}","${d.numero_serie || ''}","${d.estado}","${u?.piso ?? 'N/A'}","${ip}","${d.mantenimiento_cada_meses || ''}"`;
      })
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `inventario_red_mdasa_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getTipoIcon = (tipo: TipoDispositivo) => {
    switch (tipo) {
      case 'firewall':
        return <Shield className="w-4 h-4 text-red-400" />;
      case 'router':
        return <Cpu className="w-4 h-4 text-purple-400" />;
      case 'switch':
        return <Layers className="w-4 h-4 text-blue-400" />;
      case 'servidor':
        return <Server className="w-4 h-4 text-cyan-400" />;
      case 'onu':
        return <Zap className="w-4 h-4 text-amber-400" />;
      case 'radioenlace':
        return <Wifi className="w-4 h-4 text-indigo-400" />;
      case 'ups':
        return <Zap className="w-4 h-4 text-emerald-400" />;
      default:
        return <Server className="w-4 h-4 text-slate-400" />;
    }
  };

  const getEstadoBadge = (estado: EstadoDispositivo) => {
    switch (estado) {
      case 'operativo':
        return (
          <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            Operativo
          </span>
        );
      case 'en_mantenimiento':
        return (
          <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/30">
            En Mantenimiento
          </span>
        );
      case 'averiado':
        return (
          <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-red-500/15 text-red-400 border border-red-500/30">
            Averiado
          </span>
        );
      case 'propuesto':
        return (
          <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-cyan-500/15 text-cyan-400 border border-cyan-500/30">
            Propuesto
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-slate-500/15 text-slate-400 border border-slate-500/30">
            {estado}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Search Tools with MNTN Editorial Heading */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-3 text-[#FBD784] text-xs font-bold uppercase tracking-[0.2em]">
            <span className="w-10 h-0.5 bg-[#FBD784]" />
            <span>SECCIÓN 01 / ACTIVOS DE TELECOMUNICACIONES</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-[-0.02em] flex items-center gap-3">
            <Server className="w-6 h-6 text-[#FBD784]" />
            Catálogo de Activos Físicos y Lógicos de Red
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-[65ch] leading-relaxed">
            Inventario unificado de telecomunicaciones de la Municipalidad Distrital de Alto Selva Alegre.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={exportarCSV}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#0B1D26]/90 hover:bg-slate-800 text-slate-200 text-xs font-semibold border border-white/[0.08] transition-all duration-150 active:scale-[0.97]"
          >
            <Download className="w-3.5 h-3.5 text-[#FBD784]" />
            Exportar CSV
          </button>

          {rolActual === 'administrador' && (
            <button
              onClick={() => setMostrarModalNuevo(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#FBD784] hover:bg-[#ffe39d] text-[#0B1D26] text-xs font-bold uppercase tracking-wider shadow-lg shadow-[#FBD784]/20 transition-all duration-150 active:scale-[0.97]"
            >
              <Plus className="w-4 h-4 text-[#0B1D26]" />
              Nuevo Dispositivo
            </button>
          )}
        </div>
      </div>

      {/* Filter Bar with MNTN Glass Styling */}
      <div className="p-5 rounded-3xl bg-[#0B1D26]/85 backdrop-blur-xl border border-white/[0.08] shadow-xl space-y-3.5">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {/* Search Box with Trigram GIN indexing support */}
          <div className="md:col-span-2 relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#FBD784]" />
            <input
              type="text"
              value={busqueda}
              onChange={(e) => {
                setBusqueda(e.target.value);
                setPagina(1);
              }}
              placeholder="Buscar por nombre, modelo, marca, IP o MAC (Índice GIN)..."
              className="w-full pl-10 pr-4 py-2.5 bg-[#0B1D26] border border-white/[0.1] rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#FBD784] transition-colors"
            />
          </div>

          {/* Tipo Filter */}
          <div>
            <select
              value={tipoFiltro}
              onChange={(e) => setTipoFiltro(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950/80 border border-slate-700/80 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
            >
              <option value="todos">Todos los tipos ({dispositivos.length})</option>
              <option value="firewall">Firewall / Seguridad</option>
              <option value="router">Enrutadores (MikroTik)</option>
              <option value="switch">Switches (TP-Link / Huawei)</option>
              <option value="servidor">Servidores (SIAF / Intranet / BD)</option>
              <option value="onu">ONU Fibra Óptica</option>
              <option value="radioenlace">Radioenlace (Roosevelt)</option>
              <option value="ups">UPS Eléctrico</option>
            </select>
          </div>

          {/* Estado Filter */}
          <div>
            <select
              value={estadoFiltro}
              onChange={(e) => setEstadoFiltro(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950/80 border border-slate-700/80 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
            >
              <option value="todos">Todos los estados</option>
              <option value="operativo">Solo Operativos</option>
              <option value="en_mantenimiento">En Mantenimiento</option>
              <option value="averiado">Averiados</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-slate-400 pt-1 border-t border-slate-800/80">
          <span>
            Mostrando <strong className="text-white">{dispositivosFiltrados.length}</strong> de{' '}
            {dispositivos.length} equipos registrados
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setVista('tabla')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition ${
                vista === 'tabla' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Tabla
            </button>
            <button
              onClick={() => setVista('tarjetas')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition ${
                vista === 'tarjetas' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Tarjetas
            </button>
          </div>
        </div>
      </div>

      {/* Main Table View with MNTN Editorial Theme */}
      {vista === 'tabla' ? (
        <div className="overflow-x-auto rounded-3xl border border-white/[0.08] bg-[#0B1D26]/75 backdrop-blur-xl shadow-2xl">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-white/[0.08] bg-[#0B1D26] text-[#FBD784] font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3.5 px-4">Equipo / Hostname</th>
                <th className="py-3.5 px-4">Tipo</th>
                <th className="py-3.5 px-4">Marca & Modelo</th>
                <th className="py-3.5 px-4">Ubicación / Piso</th>
                <th className="py-3.5 px-4">Dirección IP</th>
                <th className="py-3.5 px-4">Estado</th>
                <th className="py-3.5 px-4 text-center">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.04]">
              {itemsAMostrar.map((d) => {
                const u = ubicaciones.find((ub) => ub.id_ubicacion === d.id_ubicacion);
                const ipP = d.interfaces?.[0]?.ip || '—';
                return (
                  <tr
                    key={d.id_dispositivo}
                    className="hover:bg-white/[0.03] transition-colors cursor-pointer group"
                    onClick={() => setDispositivoSeleccionado(d)}
                  >
                    <td className="py-3.5 px-4 font-mono font-bold text-[#FBD784] flex items-center gap-2 group-hover:text-white transition-colors">
                      {getTipoIcon(d.tipo)}
                      <span>{d.nombre}</span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-300 capitalize">{d.tipo}</td>
                    <td className="py-3.5 px-4 text-slate-300">
                      <span className="font-semibold text-white">{d.marca}</span> · {d.modelo}
                    </td>
                    <td className="py-3.5 px-4 text-slate-300">
                      {u ? (
                        <span>
                          {u.piso !== null ? `Piso ${u.piso}` : 'Sede Remota'}
                          <span className="text-[10px] text-slate-400 block truncate max-w-[180px]">
                            {u.ambiente}
                          </span>
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-cyan-400 tabular-nums">{ipP}</td>
                    <td className="py-3.5 px-4">{getEstadoBadge(d.estado)}</td>
                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setDispositivoSeleccionado(d);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-white/[0.06] hover:bg-[#FBD784] hover:text-[#0B1D26] text-slate-300 text-[11px] font-semibold border border-white/[0.08] transition-all duration-150 active:scale-[0.97]"
                      >
                        Ver Detalle
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        /* Grid Cards View */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {itemsAMostrar.map((d) => {
            const u = ubicaciones.find((ub) => ub.id_ubicacion === d.id_ubicacion);
            return (
              <div
                key={d.id_dispositivo}
                onClick={() => setDispositivoSeleccionado(d)}
                className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 hover:border-blue-500/50 hover:bg-slate-850 transition cursor-pointer space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {getTipoIcon(d.tipo)}
                    <h3 className="font-mono font-bold text-sm text-blue-300">{d.nombre}</h3>
                  </div>
                  {getEstadoBadge(d.estado)}
                </div>

                <div className="text-xs text-slate-300">
                  <p className="font-semibold text-white">{d.marca}</p>
                  <p className="text-slate-400">{d.modelo}</p>
                </div>

                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center gap-1 truncate">
                    <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    <span>{u ? `Piso ${u.piso ?? 'Remoto'}` : 'Sede'}</span>
                  </div>
                  <div className="font-mono text-cyan-400">
                    {d.interfaces?.[0]?.ip || 'Sin IP'}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Paginación Segura y Headers de la API (Mejora Rendimiento) */}
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-2 text-slate-400">
          <span>Cabeceras API:</span>
          <span className="font-mono px-2 py-0.5 rounded bg-slate-950 text-cyan-400 border border-slate-800">
            X-Pagina: {pagina}
          </span>
          <span className="font-mono px-2 py-0.5 rounded bg-slate-950 text-cyan-400 border border-slate-800">
            X-Limite: {verTodos ? 'all' : limite}
          </span>
          <span className="font-mono px-2 py-0.5 rounded bg-slate-950 text-emerald-400 border border-slate-800">
            X-Hay-Mas: {hayMas ? 'true' : 'false'}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-slate-400">
            <span>Por página:</span>
            <select
              value={verTodos ? 'todos' : limite}
              onChange={(e) => {
                if (e.target.value === 'todos') {
                  setVerTodos(true);
                } else {
                  setVerTodos(false);
                  setLimite(Number(e.target.value));
                  setPagina(1);
                }
              }}
              className="px-2 py-1 bg-slate-950 border border-slate-700 rounded text-white text-xs focus:outline-none"
            >
              <option value="10">10</option>
              <option value="20">20 (Por defecto)</option>
              <option value="50">50</option>
              <option value="100">100</option>
              <option value="todos">Todos ({totalRegistros})</option>
            </select>
          </div>

          {!verTodos && totalPaginas > 1 && (
            <div className="flex items-center gap-1">
              <button
                disabled={pagina <= 1}
                onClick={() => setPagina((p) => Math.max(1, p - 1))}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 disabled:opacity-40 disabled:cursor-not-allowed border border-slate-700"
              >
                ◀ Anterior
              </button>
              <span className="px-3 py-1 font-mono text-white">
                {pagina} / {totalPaginas}
              </span>
              <button
                disabled={!hayMas}
                onClick={() => setPagina((p) => p + 1)}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 disabled:opacity-40 disabled:cursor-not-allowed border border-slate-700"
              >
                Siguiente ▶
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Modal Detalle Dispositivo */}
      {dispositivoSeleccionado && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-5 animate-in fade-in duration-150">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20">
                  {getTipoIcon(dispositivoSeleccionado.tipo)}
                </div>
                <div>
                  <h3 className="text-lg font-mono font-bold text-white">
                    {dispositivoSeleccionado.nombre}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Ficha Técnica de Infraestructura MDASA
                  </p>
                </div>
              </div>
              <button
                onClick={() => setDispositivoSeleccionado(null)}
                className="text-slate-400 hover:text-white text-lg font-bold px-2 py-1"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
                <span className="text-slate-500 block">Tipo de Dispositivo</span>
                <span className="font-semibold text-slate-200 capitalize">
                  {dispositivoSeleccionado.tipo}
                </span>
              </div>
              <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
                <span className="text-slate-500 block">Estado Operativo</span>
                <span className="mt-1 block">{getEstadoBadge(dispositivoSeleccionado.estado)}</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
                <span className="text-slate-500 block">Marca / Fabricante</span>
                <span className="font-semibold text-slate-200">{dispositivoSeleccionado.marca}</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
                <span className="text-slate-500 block">Modelo Oficial</span>
                <span className="font-semibold text-slate-200">{dispositivoSeleccionado.modelo}</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
                <span className="text-slate-500 block">Número de Serie</span>
                <span className="font-mono text-slate-300">
                  {dispositivoSeleccionado.numero_serie || 'No registrado'}
                </span>
              </div>
              <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
                <span className="text-slate-500 block">Ciclo Preventivo</span>
                <span className="font-semibold text-amber-400">
                  Cada {dispositivoSeleccionado.mantenimiento_cada_meses || 12} meses
                </span>
              </div>
            </div>

            {/* Interfaces de Red */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Interfaces Físicas y Lógicas
              </h4>
              <div className="space-y-2">
                {dispositivoSeleccionado.interfaces && dispositivoSeleccionado.interfaces.length > 0 ? (
                  dispositivoSeleccionado.interfaces.map((iface) => (
                    <div
                      key={iface.id_interfaz}
                      className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between text-xs font-mono"
                    >
                      <div>
                        <span className="text-blue-400 font-bold block">{iface.nombre}</span>
                        <span className="text-[11px] text-slate-500">MAC: {iface.mac}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-cyan-400 font-bold block">IP: {iface.ip}</span>
                        <span className="text-[10px] text-slate-400 uppercase">
                          {iface.asignacion}
                        </span>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-slate-500 italic">No registra interfaces de red.</p>
                )}
              </div>
            </div>

            {/* Observaciones del Informe */}
            <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800 text-xs text-slate-300 space-y-1">
              <span className="text-slate-500 font-semibold block">
                Notas y Dictamen del Informe Técnico:
              </span>
              <p className="leading-relaxed">
                {dispositivoSeleccionado.observaciones ||
                  'Activo validado en el relevamiento de campo de Computación en Red II de la MDASA.'}
              </p>
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-800">
              <button
                onClick={() => setDispositivoSeleccionado(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium transition"
              >
                Cerrar Ficha
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Crear Nuevo Dispositivo */}
      {mostrarModalNuevo && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleCrear}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 animate-in fade-in duration-150"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-blue-400" />
                Registrar Nuevo Activo de Red
              </h3>
              <button
                type="button"
                onClick={() => setMostrarModalNuevo(false)}
                className="text-slate-400 hover:text-white font-bold"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="col-span-2 space-y-1">
                <label className="text-slate-400">Nombre / Hostname (ej: SW-PISO1-01)</label>
                <input
                  required
                  type="text"
                  value={nuevoNombre}
                  onChange={(e) => setNuevoNombre(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-400">Tipo de Dispositivo</label>
                <select
                  value={nuevoTipo}
                  onChange={(e) => setNuevoTipo(e.target.value as TipoDispositivo)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="switch">Switch</option>
                  <option value="router">Router</option>
                  <option value="firewall">Firewall</option>
                  <option value="servidor">Servidor</option>
                  <option value="access_point">Access Point</option>
                  <option value="onu">ONU</option>
                  <option value="radioenlace">Radioenlace</option>
                  <option value="ups">UPS</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-400">Marca</label>
                <input
                  required
                  type="text"
                  placeholder="ej: Cisco, TP-Link"
                  value={nuevaMarca}
                  onChange={(e) => setNuevaMarca(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-400">Modelo</label>
                <input
                  required
                  type="text"
                  placeholder="ej: Catalyst 2960"
                  value={nuevoModelo}
                  onChange={(e) => setNuevoModelo(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-400">Número de Serie</label>
                <input
                  type="text"
                  placeholder="Opcional"
                  value={nuevoSerial}
                  onChange={(e) => setNuevoSerial(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-400">Ubicación</label>
                <select
                  value={nuevaUbicacion}
                  onChange={(e) => setNuevaUbicacion(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
                >
                  {ubicaciones.map((u) => (
                    <option key={u.id_ubicacion} value={u.id_ubicacion}>
                      {u.piso !== null ? `Piso ${u.piso}` : 'Remota'} - {u.ambiente.substring(0, 24)}...
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-400">Frecuencia Mantenimiento (meses)</label>
                <input
                  type="number"
                  min="1"
                  max="60"
                  value={nuevoMantMeses}
                  onChange={(e) => setNuevoMantMeses(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-400">IP Asignada (Opcional)</label>
                <input
                  type="text"
                  placeholder="10.10.30.25"
                  value={nuevaIp}
                  onChange={(e) => setNuevaIp(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-400">MAC Address (Opcional)</label>
                <input
                  type="text"
                  placeholder="00:11:22:33:44:55"
                  value={nuevaMac}
                  onChange={(e) => setNuevaMac(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="col-span-2 space-y-1">
                <label className="text-slate-400">Observaciones Técnicas</label>
                <textarea
                  rows={2}
                  value={nuevasObs}
                  onChange={(e) => setNuevasObs(e.target.value)}
                  placeholder="Detalles de instalación o notas..."
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setMostrarModalNuevo(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md shadow-blue-600/30 transition"
              >
                Guardar en BD
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
