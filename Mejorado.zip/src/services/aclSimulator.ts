export type ZonaId = 'SERVERS' | 'PRINTERS' | 'X' | 'Y' | 'MGMT' | 'INTERNET';

export type DestinoId =
  | 'SERVERS'
  | 'PRINTERS'
  | 'X'
  | 'Y'
  | 'MGMT_GW'
  | 'MGMT_HOST'
  | 'R1B'
  | 'INTERNET';

export type ServicioId =
  | 'icmp'
  | 'tcp22'
  | 'tcp23'
  | 'tcp80'
  | 'tcp443'
  | 'tcp515'
  | 'tcp631'
  | 'tcp3389'
  | 'tcp9100'
  | 'udp53'
  | 'udp161';

export interface ServicioDef {
  id: ServicioId;
  nombre: string;
  protocolo: 'icmp' | 'tcp' | 'udp';
  puerto?: number;
  descripcion: string;
}

export const SERVICIOS_LISTA: ServicioDef[] = [
  { id: 'icmp', nombre: 'ICMP (Ping)', protocolo: 'icmp', descripcion: 'Protocolo de mensajes de control para diagnóstico y latencia' },
  { id: 'tcp22', nombre: 'SSH (Puerto 22)', protocolo: 'tcp', puerto: 22, descripcion: 'Acceso y administración remota cifrada' },
  { id: 'tcp23', nombre: 'Telnet (Puerto 23)', protocolo: 'tcp', puerto: 23, descripcion: 'Protocolo obsoleto inseguro en texto plano (prohibido por P8)' },
  { id: 'tcp80', nombre: 'HTTP (Puerto 80)', protocolo: 'tcp', puerto: 80, descripcion: 'Tráfico web sin cifrar (bloqueado hacia servidores por P5)' },
  { id: 'tcp443', nombre: 'HTTPS (Puerto 443)', protocolo: 'tcp', puerto: 443, descripcion: 'Tráfico web seguro TLS/SSL (SIAF Web, Portal MDASA)' },
  { id: 'tcp515', nombre: 'LPR/LPD (Puerto 515)', protocolo: 'tcp', puerto: 515, descripcion: 'Line Printer Daemon protocol' },
  { id: 'tcp631', nombre: 'IPP (Puerto 631)', protocolo: 'tcp', puerto: 631, descripcion: 'Internet Printing Protocol' },
  { id: 'tcp9100', nombre: 'RAW JetDirect (Puerto 9100)', protocolo: 'tcp', puerto: 9100, descripcion: 'Impresión directa por socket TCP hacia impresoras' },
  { id: 'tcp3389', nombre: 'RDP (Puerto 3389)', protocolo: 'tcp', puerto: 3389, descripcion: 'Escritorio Remoto de Windows' },
  { id: 'udp53', nombre: 'DNS (Puerto 53)', protocolo: 'udp', puerto: 53, descripcion: 'Resolución de nombres de dominio institucional y público' },
  { id: 'udp161', nombre: 'SNMP (Puerto 161)', protocolo: 'udp', puerto: 161, descripcion: 'Monitoreo de red y telemetría de UPS/switches' },
];

export interface FlujoPolitica {
  origen: ZonaId;
  destino: DestinoId;
  servicios: ServicioId[];
  motivo: string;
  nombreAcl: string;
}

export const FLUJOS_DEFINIDOS: FlujoPolitica[] = [
  {
    origen: 'X',
    destino: 'SERVERS',
    servicios: ['icmp', 'udp53', 'tcp443'],
    motivo: 'P5: HTTP 80 no seguro prohibido; solo HTTPS 443, DNS y diagnóstico ICMP autorizados a servidores',
    nombreAcl: 'FW_IN_VLAN30_AREA_X',
  },
  {
    origen: 'X',
    destino: 'PRINTERS',
    servicios: ['icmp', 'tcp9100', 'tcp631', 'tcp515'],
    motivo: 'P3: Personal del Área X autorizado a enviar trabajos de impresión a VLAN 20',
    nombreAcl: 'FW_IN_VLAN30_AREA_X',
  },
  {
    origen: 'X',
    destino: 'R1B',
    servicios: ['icmp'],
    motivo: 'P8: Telnet 23 prohibido expresamente; únicamente se permite ICMP de control',
    nombreAcl: 'FW_IN_VLAN30_AREA_X',
  },
  {
    origen: 'X',
    destino: 'INTERNET',
    servicios: ['tcp80', 'tcp443', 'udp53'],
    motivo: 'Navegación web externa y consultas DNS para usuarios administrativos',
    nombreAcl: 'FW_IN_VLAN30_AREA_X',
  },
  {
    origen: 'Y',
    destino: 'MGMT_GW',
    servicios: ['icmp'],
    motivo: 'P6/P7: Solo se permite ICMP al gateway para validación de latencia de red',
    nombreAcl: 'FW_IN_VLAN40_AREA_Y',
  },
  {
    origen: 'Y',
    destino: 'INTERNET',
    servicios: ['tcp80', 'tcp443', 'udp53'],
    motivo: 'Navegación web autorizada para usuarios de atención ciudadana',
    nombreAcl: 'FW_IN_VLAN40_AREA_Y',
  },
  {
    origen: 'MGMT',
    destino: 'MGMT_GW',
    servicios: ['icmp', 'tcp22', 'tcp443'],
    motivo: 'Gestión administrativa out-of-band del router/firewall',
    nombreAcl: 'FW_IN_VLAN99_MGMT',
  },
  {
    origen: 'MGMT',
    destino: 'SERVERS',
    servicios: ['icmp', 'tcp22', 'tcp443', 'udp161'],
    motivo: 'Gestión y monitoreo de servidores por administradores de red',
    nombreAcl: 'FW_IN_VLAN99_MGMT',
  },
  {
    origen: 'MGMT',
    destino: 'PRINTERS',
    servicios: ['icmp', 'tcp443', 'udp161'],
    motivo: 'Administración de consumibles y configuración de impresoras de red',
    nombreAcl: 'FW_IN_VLAN99_MGMT',
  },
  {
    origen: 'MGMT',
    destino: 'R1B',
    servicios: ['icmp', 'tcp22', 'udp161'],
    motivo: 'Gestión segura SSH (sustituye a Telnet) y monitoreo SNMP de enrutador secundario',
    nombreAcl: 'FW_IN_VLAN99_MGMT',
  },
  {
    origen: 'MGMT',
    destino: 'X',
    servicios: ['icmp'],
    motivo: 'Diagnóstico de conectividad desde VLAN de gestión hacia Área X',
    nombreAcl: 'FW_IN_VLAN99_MGMT',
  },
  {
    origen: 'MGMT',
    destino: 'Y',
    servicios: ['icmp'],
    motivo: 'Diagnóstico de conectividad desde VLAN de gestión hacia Área Y',
    nombreAcl: 'FW_IN_VLAN99_MGMT',
  },
  {
    origen: 'MGMT',
    destino: 'INTERNET',
    servicios: ['tcp80', 'tcp443', 'udp53'],
    motivo: 'Descarga de parches y actualizaciones de seguridad de firmware',
    nombreAcl: 'FW_IN_VLAN99_MGMT',
  },
  {
    origen: 'SERVERS',
    destino: 'INTERNET',
    servicios: ['tcp80', 'tcp443', 'udp53'],
    motivo: 'Actualizaciones de seguridad de Windows Server y sincronización MEF',
    nombreAcl: 'FW_IN_VLAN10_SERVERS',
  },
];

export interface SimulacionResultado {
  permitido: boolean;
  estado: 'PERMITIDO' | 'DENEGADO';
  origenZona: ZonaId;
  destinoId: DestinoId;
  servicio: ServicioId;
  aclAplicada: string;
  motivo: string;
  tiempoProcesamientoMs: number;
  saltoRuta: string[];
}

export function simularPaqueteAcl(
  origen: ZonaId,
  destino: DestinoId,
  servicio: ServicioId
): SimulacionResultado {
  const t0 = performance.now();

  const flujoMatch = FLUJOS_DEFINIDOS.find(
    (f) =>
      f.origen === origen &&
      f.destino === destino &&
      f.servicios.includes(servicio)
  );

  const t1 = performance.now();
  const duracion = Math.max(1, Math.round((t1 - t0) * 100) / 100);

  // Ruteo y saltos
  const ruta: string[] = [];
  if (origen === 'X') ruta.push('Host PC1 (10.10.30.10)', 'SW-Huawei Piso 3', 'FortiGate 90G (G0/2.30)');
  else if (origen === 'Y') ruta.push('Host PC7 (10.10.40.11)', 'SW-Huawei Piso 2', 'FortiGate 90G (G0/2.40)');
  else if (origen === 'MGMT') ruta.push('Estación Admin (10.10.99.10)', 'SW-TP-Link Omada', 'FortiGate 90G (G0/2.99)');
  else if (origen === 'SERVERS') ruta.push('SRV-GOB-3 (10.10.10.20)', 'Rack Servidores', 'FortiGate 90G (G0/2.10)');
  else if (origen === 'PRINTERS') ruta.push('Impresora Red (10.10.20.20)', 'FortiGate 90G (G0/2.20)');
  else ruta.push('ISP Misticom WAN', 'Phyhome EPON ONU', 'FortiGate 90G (G0/0)');

  if (flujoMatch) {
    if (destino === 'SERVERS') ruta.push('FortiGate 90G (G0/2.10)', 'SRV-GOB-3 (10.10.10.20) [Entrega]');
    else if (destino === 'PRINTERS') ruta.push('FortiGate 90G (G0/2.20)', 'Printer (10.10.20.20) [Entrega]');
    else if (destino === 'R1B') ruta.push('FortiGate 90G (G0/1)', 'Router MikroTik L009 R1B (10.0.1.2) [Entrega]');
    else if (destino === 'INTERNET') ruta.push('FortiGate NAT/PAT', 'ONU Phyhome Fiber', 'Internet Gateway [Salida]');
    else if (destino === 'MGMT_GW') ruta.push('FortiGate 90G Interfaz Virtual 10.10.99.1 [Local Gateway]');
    else ruta.push(`Destino ${destino} [Entrega]`);

    return {
      permitido: true,
      estado: 'PERMITIDO',
      origenZona: origen,
      destinoId: destino,
      servicio,
      aclAplicada: flujoMatch.nombreAcl,
      motivo: flujoMatch.motivo,
      tiempoProcesamientoMs: duracion,
      saltoRuta: ruta,
    };
  }

  // Si no match: Denegado
  let aclNombre = 'FW_DEFAULT_DENY';
  if (origen === 'X') aclNombre = 'FW_IN_VLAN30_AREA_X (Regla final: deny ip any any)';
  else if (origen === 'Y') aclNombre = 'FW_IN_VLAN40_AREA_Y (Regla final: deny ip any any)';
  else if (origen === 'MGMT') aclNombre = 'FW_IN_VLAN99_MGMT (Regla final: deny ip any any)';
  else if (origen === 'SERVERS') aclNombre = 'FW_IN_VLAN10_SERVERS (Regla final: deny ip any any)';

  let razon = 'Denegación por defecto: El flujo no se encuentra contemplado en la Matriz de Políticas Seguras de MDASA.';
  if (servicio === 'tcp23') {
    razon = 'Bloqueo explícito de seguridad (P8): El protocolo Telnet (puerto 23) está PROHIBIDO por política institucional.';
  } else if (servicio === 'tcp80' && destino === 'SERVERS') {
    razon = 'Bloqueo explícito de seguridad (P5): El tráfico HTTP 80 en texto plano está bloqueado; use HTTPS 443.';
  } else if (origen === 'Y' && destino === 'SERVERS') {
    razon = 'Aislamiento de VLANs: La VLAN 40 (Área Y) no tiene privilegios de acceso directo a la zona de servidores.';
  } else if (origen === 'Y' && destino === 'PRINTERS') {
    razon = 'Política P3: Las impresoras de red están reservadas para usuarios autorizados de Área X.';
  } else if ((origen === 'X' || origen === 'Y') && (destino === 'MGMT_HOST' || (destino === 'MGMT_GW' && servicio !== 'icmp'))) {
    razon = 'Protección out-of-band: Solo personal autenticado desde VLAN 99 MGMT puede acceder a consolas de gestión.';
  }

  ruta.push('FortiGate 90G (Filtro ACL) [PAQUETE DESCARTADO / DROP]');

  return {
    permitido: false,
    estado: 'DENEGADO',
    origenZona: origen,
    destinoId: destino,
    servicio,
    aclAplicada: aclNombre,
    motivo: razon,
    tiempoProcesamientoMs: duracion,
    saltoRuta: ruta,
  };
}
