# Datos por completar antes de entregar

Reemplaza cada `[Completar...]` en `01_Manual_de_Usuario.html` (busca "Completar" con Ctrl+F). Contexto de cada uno:

- [ ] …a o solución Sistema de Inventario y Seguridad de Red Número de grupo [Completar: N.º de grupo]
- [ ] …Integrantes del equipo [Completar: nombre y apellidos de cada integrante]
- [ ] …Selva Alegre (Arequipa, Perú) Idioma Español Repositorio del proyecto [Completar: enlace al repositorio GitHub]
- [ ] …ipo N.º Apellidos y nombres Rol en el proyecto Correo institucional 1 [Completar]
- [ ] …[Completar] [Completar] 2 [Completar] [Completar] [Completar] 3 [Completar]
- [ ] …[Completar] [Completar] 4 [Completar] [Completar] [Completar] 5 [Completar]
- [ ] …[Completar] [Completar]
- [ ] …o no se encontraban en la carpeta del proyecto; se dejan marcados con [Completar]
- [ ] …del sistema Sistema de Inventario y Seguridad de Red Número de grupo [Completar]
- [ ] …tabla de la ficha del documento] Curso Computación en Red II Sección [Completar]
- [ ] …sta de verificación del manual de instalación Responsable del sistema [Completar: nombre y cargo]
- [ ] …Soporte [Completar: correo y anexo] Responsable de seguridad [Completar: nombre y cargo]
- [ ] …Contactos de soporte Necesidad Contacto Acceso, contraseña o permisos [Completar: administrador del sistema]
- [ ] …Incidente de seguridad [Completar: responsable de seguridad]
- [ ] …El sistema no responde [Completar: soporte técnico]
- [ ] …Copias de seguridad y restauración [Completar: DBA]

## Capturas que aún no existen (hay que tomarlas)
- [ ] 6.11 Get-RedYo (quién soy)
- [ ] 6.12 Set-RedContrasena (cambio de contraseña)
- [ ] 6.14 New-RedDispositivo (registrar equipo)
- [ ] 6.15 Pruebas de ACL (node probar_acls.js)
- [ ] 4.4 Inicio de sesión fallido (credenciales incorrectas)
- [ ] 4.2 Import-Module / Get-Command -Module RedCli

Verifica además: curso ("Computación en Red II") y fecha del manual (01/11/2026).