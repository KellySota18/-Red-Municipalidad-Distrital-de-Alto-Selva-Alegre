# Guía de seguridad — Red de la Municipalidad de Alto Selva Alegre (PostgreSQL + API)

Complementa a `infra_red_schema_seguro.sql`. Cada requisito de tu lista está mapeado a **dónde se implementa** y **cómo verificarlo**.

> **Qué se probó y qué no.** El script SQL, la API (`api_seguridad/server.js`) y el script de backup se ejecutaron y probaron contra PostgreSQL 16 y Node 22 (resultados en la sección 6). Los comandos de **sistema operativo** (Parte C) son los estándar de cada plataforma, pero no los pude ejecutar en tu equipo: pruébalos primero en una máquina de laboratorio.

---

## 0. Cómo ejecutar el script en pgAdmin 4

1. Clic derecho en *Databases* → *Create* → *Database…* → nombre `infra_red_db`.
2. Selecciona `infra_red_db` → menú *Tools* → **Query Tool**.
3. Abre `infra_red_schema_seguro.sql` (icono de carpeta) o pega su contenido → **F5**.
4. Debe terminar con `COMMIT` y sin errores. Es re-ejecutable.
5. Crea las cuentas de login (sección 11 del script) con contraseñas generadas por un gestor de secretos.

**Proyecto:** base de datos de apoyo al *Diario de Ingeniería* de la Municipalidad Distrital de Alto Selva Alegre (inventario de la red). Las tres tablas pedidas se adaptaron así:

| Pedido | Tabla | Qué guarda |
|---|---|---|
| Usuarios | `usuarios` | Personal autorizado: `administrador`, `tecnico`, `consulta` |
| Productos | `dispositivos` | Switches, routers, servidores, firewall, UPS, ONU, radioenlace |
| Pedidos | `mantenimientos` | Órdenes de mantenimiento por dispositivo (responsable, fecha, estado) |

Se añadieron `ubicaciones`, `vlans`, `subredes`, `interfaces` (IP/MAC) y `enlaces`, más `sesiones`, `rate_limit` y `auditoria`. Claves **UUID** (no enumerables). La contraseña se guarda como `contrasena_hash` (bcrypt). No hay registro público: las cuentas las crea un administrador.

Orden de ejecución: `infra_red_schema_seguro.sql` → `seed_datos_municipalidad.sql` (datos del Diario) → `infra_red_acl_extension.sql` → `seed_acl_informe.sql` → `seed_acl_reglas.sql` → `seed_pruebas_simulador.sql` (práctica de ACL; ver sección 9).

---

## 1. Mapa de requisitos

| # | Requisito | Dónde se resuelve | Capa |
|---|---|---|---|
| 1 | Validación de entradas / codificación de salidas | `CHECK` en tablas + zod en `server.js`; salida: JSON + CSP + `textContent` en el front | BD + API + Front |
| 2 | Prevención de inyección SQL y de comandos | Consultas parametrizadas (`$1`), funciones sin SQL dinámico, nunca `exec()` con datos del usuario | BD + API |
| 3 | Protección XSS y CSRF | CSP (helmet), cookies `HttpOnly`/`SameSite=Strict`, token CSRF + verificación de `Origin` | API |
| 4 | Autenticación y autorización | bcrypt, bloqueo, roles de mínimo privilegio, Row Level Security | BD + API |
| 5 | Sesiones, cookies y tokens | Tabla `sesiones` (solo hash SHA-256), expiración absoluta + inactividad, revocación | BD + API |
| 6 | CORS seguro | Lista blanca de orígenes, sin `*` | API |
| 7 | Limitación de solicitudes y abuso | `permitir_solicitud()` + `express-rate-limit` + bloqueo de cuenta | BD + API |
| 8 | Secretos y credenciales | Variables de entorno, sin secretos en el script, rotación | API + Operación |
| 9–15 | SO: parches, antivirus/EDR, cifrado, privilegios, hardening, USB | Parte C (Windows y Linux) | SO |
| 16 | Copias de seguridad y restauración | `backup_postgres.sh` (cifrado, verificado, con prueba de restauración) | Operación |

---

## Parte A — Aplicación

### 1. Validación de entradas y codificación de salidas

**Entrada: tres defensas en capas.**
- **API:** esquemas `zod` con `.strict()` (rechaza campos no previstos, evita *mass assignment* como enviar `"rol":"admin"`), longitudes máximas y `express.json({limit:'10kb'})`.
- **BD:** `CHECK` de email, nombre, precio ≥ 0, stock ≥ 0. Si la API falla, la BD sigue protegiendo.
- **Regla:** valida con **lista blanca** (qué sí se acepta), no con lista negra.

**Salida: codifica según el contexto donde se imprime.**

| Contexto | Qué hacer |
|---|---|
| HTML (texto) | `element.textContent = dato` (nunca `innerHTML`). React/Vue/Angular ya escapan por defecto |
| Atributo HTML | Usa `setAttribute`; nunca construyas HTML con `+` |
| URL | `encodeURIComponent()` |
| JSON | `res.json()` (ya envía `Content-Type: application/json` y `nosniff`) |
| JavaScript embebido | Evítalo; pasa datos como JSON en un atributo `data-*` |

Si **debes** mostrar HTML de usuarios (ej. reseñas con formato), sanitiza con DOMPurify.

### 2. Inyección SQL y de comandos

```js
// ❌ VULNERABLE
pool.query("SELECT * FROM infra.dispositivos WHERE tipo = '" + req.query.tipo + "'");

// ✅ SEGURO: el valor viaja separado de la consulta
pool.query('SELECT * FROM infra.dispositivos WHERE tipo::text = $1', [req.query.tipo]);
```

- Los **identificadores** (tabla/columna) no se pueden parametrizar: elige de una lista blanca fija (`const ORDEN = {precio:'precio', nombre:'nombre'}`).
- Las funciones SQL del script usan parámetros tipados y no ejecutan `EXECUTE` dinámico.
- El rol `app_backend` **no es dueño** de las tablas ni superusuario: aunque hubiera una inyección, no puede borrar tablas ni leer `usuarios`/`sesiones` (verificado en pruebas).
- **Comandos del SO:** evita `child_process.exec(\`...${dato}\`)`. Si es inevitable: `execFile('cmd', [arg1, arg2])` (sin shell) y valida el argumento contra lista blanca.

### 3. XSS y CSRF

**XSS**
- CSP restrictiva (ver `server.js`: `default-src 'none'`). Si sirves un front, usa `script-src 'self'` y **sin** `'unsafe-inline'`.
- Cookie de sesión `HttpOnly`: aunque exista un XSS, el script no puede leer el token.
- `X-Content-Type-Options: nosniff` (incluido en helmet).

**CSRF (tres capas)**
1. `SameSite=Strict` en las cookies.
2. Verificación del encabezado `Origin` contra la lista blanca.
3. Token de doble envío: la cookie `csrf` (legible por JS) debe coincidir con el encabezado `X-CSRF-Token` en todo `POST/PUT/DELETE`. Un sitio malicioso no puede leer tu cookie, así que no puede copiarla al encabezado.

Front: `fetch(url, {method:'POST', credentials:'include', headers:{'X-CSRF-Token': leerCookie('csrf'), 'Content-Type':'application/json'}, body})`.

### 4. Autenticación y autorización

**Autenticación (en la BD, `autenticar_usuario`)**
- bcrypt costo 12, contraseña mínima 12 caracteres con mayúscula, minúscula, número y símbolo.
- Máximo **72 bytes**: bcrypt ignora el resto, así que el script lo rechaza en vez de truncar en silencio.
- Mismo mensaje y mismo tiempo de CPU para "no existe" y "clave mala" (evita enumerar usuarios).
- 5 fallos → bloqueo de 15 min, registrado en auditoría.
- Para mayor seguridad en cuentas admin, añade **MFA** (TOTP, ej. librería `otplib`): es el control con mejor relación esfuerzo/beneficio que queda pendiente.

**Autorización (defensa en profundidad)**
1. **Rol de BD:** `rol_app` (la API) no puede leer `usuarios`, `sesiones` ni `auditoria`; `rol_lectura` solo consulta el inventario.
2. **Row Level Security por rol de aplicación** (la BD lee el rol desde la tabla `usuarios`, nunca desde el cliente):

   | Rol | Inventario | Mantenimientos | Usuarios |
   |---|---|---|---|
   | `consulta` | solo lectura | solo lectura | — |
   | `tecnico` | solo lectura | crea y edita **solo los suyos** | — |
   | `administrador` | lee y escribe | todo | crea, cambia rol, desactiva |

   Sin sesión válida, ni el inventario se ve: el mapa de IPs de una red municipal es información sensible. Límite honesto: RLS se apoya en la variable `app.user_id` que fija la API; protege contra errores de lógica y de permisos, pero **no** contra una inyección SQL completa (quien ejecuta SQL arbitrario con `app_backend` podría fijar esa variable). Por eso la defensa principal sigue siendo la consulta parametrizada y los permisos mínimos.
3. **API:** valida pertenencia/rol en cada endpoint; nunca confíes en un `id_usuario` enviado por el cliente (se toma de la sesión).

### 5. Sesiones, cookies y tokens

| Control | Valor en el proyecto |
|---|---|
| Token | 256 bits aleatorios (`gen_random_bytes(32)`) |
| En BD | Solo SHA-256 del token: una fuga de BD no permite suplantar sesiones |
| Expiración absoluta | 8 h (máx. 24 h) |
| Inactividad | 30 min |
| Revocación | `cerrar_sesion`, `revocar_sesiones_usuario`, y automática al cambiar contraseña |
| Cookie | `HttpOnly; Secure; SameSite=Strict; Path=/` y prefijo `__Host-` en producción |
| Datos en la cookie | Solo un identificador opaco; nada de datos del usuario |

Si usas **JWT** en lugar de sesiones: vida corta (5–15 min), algoritmo fijado en el servidor (nunca `none`), refresh token rotativo guardado hasheado, y `HttpOnly` en cookie (no en `localStorage`).

### 6. CORS seguro

- Lista blanca explícita por variable de entorno (`ALLOWED_ORIGINS`).
- **Nunca** `origin: '*'` junto con `credentials: true` ni reflejar cualquier `Origin`.
- Limita métodos y cabeceras a lo necesario; `maxAge` para reducir preflights.
- CORS **no** reemplaza a CSRF ni a la autenticación: es solo una política del navegador.

### 7. Limitación de solicitudes y abuso

| Capa | Mecanismo |
|---|---|
| Global por IP | `express-rate-limit`: 120/min |
| Login | BD `permitir_solicitud`: 20/min por IP **y** 10/15 min por email (hasheado) |
| Cuenta | Bloqueo tras 5 fallos |
| Tamaño | Cuerpo máx. 10 KB |
| Borde | Rate limit/WAF en Nginx, Cloudflare o ALB (recomendado antes de llegar a Node) |

La limitación en BD sirve para **varias instancias** de la API (la memoria no se comparte). Detrás de un proxy, define `TRUST_PROXY=1` o todas las peticiones parecerán venir de la misma IP.

### 8. Gestión de secretos y credenciales

- Ningún secreto en el código, en el script SQL ni en Git. Solo variables de entorno o un gestor (Azure Key Vault, AWS Secrets Manager, HashiCorp Vault, Doppler).
- `.env` en `.gitignore`; `chmod 600`. Para `psql`/`pg_dump` usa `~/.pgpass` (Windows: `%APPDATA%\postgresql\pgpass.conf`).
- Un secreto distinto por entorno (desarrollo ≠ producción) y por servicio.
- Rotación periódica y **inmediata** ante sospecha. Revoca también las sesiones activas.
- Detecta fugas antes de subir: `gitleaks` como *pre-commit hook* y en CI:
  ```bash
  gitleaks detect --source . --verbose
  ```
- Si un secreto ya llegó a Git: **rótalo**; borrarlo del historial no basta.
- Contraseñas generadas: `openssl rand -base64 32`.

### Configuración del servidor PostgreSQL

`postgresql.conf`
```conf
listen_addresses = 'localhost'          # o la IP privada; nunca '*' expuesto a internet
ssl = on
ssl_min_protocol_version = 'TLSv1.2'
password_encryption = scram-sha-256
log_connections = on
log_disconnections = on
log_statement = 'ddl'
log_min_duration_statement = 1000       # registra consultas lentas (ms)
```
`pg_hba.conf` (nada de `trust`)
```conf
hostssl  infra_red_db  app_backend  10.0.0.0/24  scram-sha-256
hostssl  infra_red_db  reportes     10.0.0.5/32  scram-sha-256
```
Firewall: abre el puerto 5432 solo desde el servidor de la API. En la API activa `PGSSL=1`.

---

## Parte C — Sistema operativo y endpoints

Aplica a la máquina donde corre PostgreSQL/la API y a los equipos de quienes administran. Comandos de **Windows (PowerShell como administrador)** y **Linux (Ubuntu/Debian)**.

### 9. Actualización de sistemas operativos y gestión de parches

**Principios:** usar solo versiones con soporte vigente (Windows 10 dejó de recibir parches de seguridad gratuitos en octubre de 2025), inventario de equipos, parchear según criticidad (críticos ≤ 7 días, resto ≤ 30), probar en un grupo piloto, y tener plan de reversión. Incluye PostgreSQL, Node y dependencias (`npm audit`, Dependabot).

| Windows | Linux |
|---|---|
| Windows Update for Business / Intune / WSUS (anillos: piloto → general) | `apt install unattended-upgrades` y `dpkg-reconfigure -plow unattended-upgrades` |
| `Get-HotFix \| Sort InstalledOn -Desc \| Select -First 5` | `apt list --upgradable` · `needrestart` |
| Windows 11 con *Secure Boot* + TPM 2.0 | Kernel con *livepatch* (Ubuntu Pro) si no puedes reiniciar |

PostgreSQL: aplica las versiones menores (ej. 16.x) apenas salgan; contienen correcciones de seguridad.

### 10. Antivirus y EDR

El antivirus detecta malware conocido; el **EDR** detecta comportamiento sospechoso, permite aislar el equipo y registra evidencia. Objetivo: EDR en todos los servidores y equipos administrativos, con alertas a una persona responsable.

**Windows**
```powershell
Get-MpComputerStatus | Select AMRunningMode, RealTimeProtectionEnabled, AntivirusSignatureLastUpdated
Set-MpPreference -PUAProtection Enabled -MAPSReporting Advanced -CloudBlockLevel High -EnableNetworkProtection Enabled
# Reglas ASR (reducción de superficie de ataque)
Add-MpPreference -AttackSurfaceReductionRules_Ids 9e6c4e1f-7d60-472f-ba1a-a39ef669e4b2 -AttackSurfaceReductionRules_Actions Enabled  # robo de credenciales de LSASS
Add-MpPreference -AttackSurfaceReductionRules_Ids be9ba2d9-53ea-4cdc-84e5-9b1eeee46550 -AttackSurfaceReductionRules_Actions Enabled  # ejecutables desde correo
Add-MpPreference -AttackSurfaceReductionRules_Ids d4f940ab-401b-4efc-aadc-ad5f3c50688a -AttackSurfaceReductionRules_Actions Enabled  # Office creando procesos
```
EDR: Microsoft Defender for Endpoint, CrowdStrike o SentinelOne.

**Linux:** `apt install clamav clamav-daemon` (antivirus) + **Wazuh** (open source, monitoreo de integridad, detección de intrusiones y respuesta) o un EDR comercial. Complementa con `auditd` (`apt install auditd`).

### 11. Cifrado de discos y archivos

| | Windows | Linux |
|---|---|---|
| **Disco completo** | BitLocker | LUKS2 (se elige al instalar) |
| Activar | `Enable-BitLocker -MountPoint "C:" -EncryptionMethod XtsAes256 -TpmProtector` y luego `Add-BitLockerKeyProtector -MountPoint "C:" -RecoveryPasswordProtector` | `cryptsetup luksDump /dev/sdX` para verificar |
| Verificar | `manage-bde -status` | `lsblk -f` (busca `crypto_LUKS`) |
| **Archivos / copias** | `gpg --encrypt` o 7-Zip AES-256 | `gpg --encrypt` o `age` |

- Guarda la **clave de recuperación** de BitLocker en Entra ID/AD o en una caja fuerte, **nunca** en el mismo equipo.
- Cifrado en tránsito: TLS 1.2+ (API ↔ cliente y API ↔ PostgreSQL).
- Datos muy sensibles en BD (documentos, teléfonos): cifrado a nivel de columna con `pgp_sym_encrypt` o desde la aplicación, con la clave **fuera** de la BD.

### 12. Restricción de privilegios administrativos

- Cuentas **estándar** para el trabajo diario; cuenta admin separada solo para tareas administrativas.
- Quita administradores locales innecesarios:
  - Windows: `Get-LocalGroupMember Administrators` y usa **Windows LAPS** para que cada equipo tenga una contraseña de administrador local distinta y rotativa.
  - Linux: `getent group sudo`; usa `sudo` con registro, no `root` directo.
- PostgreSQL: **nunca** uses el superusuario `postgres` desde la aplicación. Solo `app_backend` (mínimo privilegio) como ya está en el script.
- MFA para todo acceso administrativo, VPN/bastión para llegar a los servidores.

### 13. Configuración segura del sistema operativo

Base de referencia: **CIS Benchmarks** (nivel 1) y *Microsoft Security Baselines*.

**Windows**
```powershell
Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force      # desactivar SMBv1
Set-NetFirewallProfile -Profile Domain,Private,Public -Enabled True
Disable-LocalUser -Name "Guest"
```
RDP solo con NLA, por VPN y con MFA; mejor aún, desactivado en servidores.

**Linux**
```bash
ufw default deny incoming && ufw allow from 10.0.0.0/24 to any port 5432 proto tcp && ufw allow 22/tcp && ufw enable
# /etc/ssh/sshd_config
#   PermitRootLogin no
#   PasswordAuthentication no     (solo llaves SSH)
#   MaxAuthTries 3
apt install fail2ban lynis && lynis audit system     # informe con recomendaciones
```
En ambos: desinstala software y servicios que no uses, sincroniza la hora (NTP, necesario para logs fiables), registra eventos y envíalos a un servidor central.

### 14. Control de aplicaciones y dispositivos USB

**Control de aplicaciones** (solo se ejecuta lo autorizado)
- Windows: **WDAC** o **AppLocker** (empieza en modo *Audit*, revisa el registro y luego pasa a *Enforce*).
- Linux: **AppArmor** (`aa-status`), y montajes `noexec` en `/tmp` y `/var/tmp`.

**USB**
- Windows (GPO: *Administrative Templates → System → Removable Storage Access → Removable Disks: Deny write access*). Equivalente por registro:
  ```powershell
  $k = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices\{53f5630d-b6bf-11d0-94f2-00a0c91efb8b}"
  New-Item $k -Force | Out-Null; Set-ItemProperty $k -Name Deny_Write -Value 1 -Type DWord
  ```
  Para autorizar solo ciertos dispositivos, usa la restricción por ID de hardware en Intune o Defender for Endpoint (*Device Control*).
- Linux: **USBGuard**
  ```bash
  apt install usbguard
  usbguard generate-policy > /etc/usbguard/rules.conf     # permite lo conectado ahora
  systemctl enable --now usbguard
  usbguard list-devices                                    # nuevos dispositivos quedan bloqueados
  ```
- En servidores, desactiva también el *autorun* y los puertos USB no usados en la BIOS/UEFI con contraseña.

### 15. Copias de seguridad y restauración

**Regla 3-2-1-1-0:** 3 copias, en 2 soportes distintos, 1 fuera del sitio, 1 inmutable (o desconectada), 0 errores verificados en la restauración.

**Script `backup_postgres.sh`** (probado):
```bash
export GPG_DESTINATARIO=backups@tuempresa.com   # clave PÚBLICA; la privada va offline
export BD=infra_red_db DESTINO=/var/backups/postgres PGUSER=backup_ro
./backup_postgres.sh backup     # volcado -> cifrado -> checksum, sin pasar en claro por disco
./backup_postgres.sh prueba     # restaura la última copia en una BD temporal y cuenta filas
./backup_postgres.sh rotar      # borra copias de más de 30 días
```
Programación (Linux), diaria a las 02:00 y prueba semanal:
```cron
0 2 * * *  GPG_DESTINATARIO=backups@tuempresa.com /opt/scripts/backup_postgres.sh backup && /opt/scripts/backup_postgres.sh rotar
0 4 * * 0  /opt/scripts/backup_postgres.sh prueba     # en el equipo de recuperación (requiere la clave privada)
```
- **Windows:** ejecuta el script desde WSL/Git Bash con el *Programador de tareas*, o usa directamente `pg_dump -Fc -U postgres -f infra_red.dump infra_red_db` seguido de `gpg --encrypt`.
- **Usuario de backup** con permisos de solo lectura (`pg_read_all_data`) en lugar de `postgres`.
- **Recuperación a un punto en el tiempo (PITR):** si no puedes perder más de unos minutos de datos, usa **pgBackRest** o **WAL-G** con archivado de WAL.
- **Una copia que nunca restauraste no es una copia.** Haz la prueba de restauración completa al menos trimestralmente y documenta RTO/RPO (cuánto tarda y cuántos datos puedes perder).
- Copia inmutable: almacenamiento con *Object Lock* (S3/Azure Blob) o un disco rotado sin conexión; protege contra ransomware.
- Guarda la clave privada GPG y su passphrase en un lugar distinto al servidor y con acceso de al menos dos personas.

---

## 6. Resultados de las pruebas realizadas

**SQL (PostgreSQL 16.15):** el esquema y los datos se ejecutan sin errores, y una segunda ejecución también (idempotente).

| Prueba | Resultado |
|---|---|
| Hash en BD | `$2a$12$…` (bcrypt); nunca texto plano |
| Contraseña corta, login correcto/incorrecto | rechazada / uuid / `NULL` |
| `rol_app` **sin sesión** | 0 dispositivos; `permission denied` en `usuarios`, `sesiones`, `auditoria` y `registrar_usuario` |
| `consulta` | lee 13 dispositivos; INSERT rechazado por RLS; UPDATE/DELETE afectan 0 filas |
| `tecnico` | no crea inventario; crea su mantenimiento; **no** puede crear uno a nombre de otro ni reasignar el suyo |
| `administrador` | crea dispositivos y usuarios; no puede cambiarse el rol ni desactivarse a sí mismo |
| IP fuera de su subred / IP duplicada | rechazadas (trigger / `UNIQUE`) |
| Subred solapada, gateway fuera de red, VLAN 5000, nombre con `<script>` | rechazadas por `EXCLUDE` / `CHECK` |
| Auditoría | registra **quién** (usuario de la app); no contiene hashes; `DELETE` bloqueado |
| `rol_lectura` | lee inventario; no ve `usuarios`; no escribe |

**API (Express 4, Node 22), con los tres roles:** sin sesión → 401; consulta intentando crear dispositivo o mantenimiento → 403; admin crea dispositivo → 201; `POST` sin token CSRF → 403; campo extra (`id_dispositivo`) → 400; filtro con `' OR 1=1 --` → 400; PATCH al mantenimiento de otro → 404; técnico completa el suyo; `/admin/usuarios` → 403 para técnico y lista para admin; CORS bloqueado para `evil.com`; logout y cambio de contraseña invalidan la sesión; 10 logins fallidos y luego 429.

**Backup:** copia cifrada con GPG, checksum verificado, restauración en BD temporal, rotación y limpieza de la BD temporal. La prueba descubrió y corrigió un fallo en la limpieza.

---

## 7. Qué queda por hacer en tu entorno

1. Crear las cuentas de login con contraseñas generadas (sección 11 del script).
2. Activar TLS en PostgreSQL y en la API (certificado, p. ej. Let's Encrypt) y poner un proxy (Nginx/Caddy) delante.
3. Añadir **MFA** para administradores.
4. Programar `infra.limpieza_periodica()` (limpia sesiones y contadores caducados), por ejemplo con `pg_cron`: `SELECT cron.schedule('limpieza','0 3 * * *','SELECT infra.limpieza_periodica()');`
5. Aplicar la Parte C en el servidor y en los equipos administrativos, empezando por un equipo de prueba.
6. Confirmar con la municipalidad qué IP (10.0.0.10–15) corresponde a cada servidor y registrarlas en `interfaces` (hay un ejemplo comentado en el seed).
7. Revisar la tabla `auditoria` periódicamente y enviar sus eventos a un sistema de monitoreo.

## 8. Observaciones sobre el informe (detectadas al modelar los datos)

Son puntos que conviene corregir o aclarar antes de entregarlo; no modifiqué el documento.

| # | Dónde | Observación |
|---|---|---|
| 1 | 7.1.5 y 8.1 | Una red `10.0.0.0/24` admite **254** hosts, pero se declaran ~**500**. La vista `infra.v_uso_subredes` muestra esa capacidad. Aclarar si hay más subredes o si el /24 no alcanza |
| 2 | 14.3 | La **contraseña de VTP (`RedSegura123`)** está escrita en el informe. Un secreto no debe publicarse; cámbiala y quítala del documento (y considera desactivar VTP: un servidor VTP con revisión mayor puede borrar las VLANs de toda la red) |
| 3 | 14.4 vs. Tabla 6 | Se menciona la **VLAN 50** (Seguridad Ciudadana) que no está en la tabla de VLANs ni tiene gateway |
| 4 | Tabla 12 | El **MikroTik L009UiGS-RM** se describe como switch, pero es un router. La tabla dice **FortiGate 90G** y la Figura 47 parece mostrar otro modelo: verifica la etiqueta física |
| 5 | Tabla 12 | Dice que el firewall opera en capas 3 y 4, y la sección 11.1 dice de la 3 a la 7 |
| 6 | Tabla 4 | R2 `S0/0/0` figura como "Conectado hacia R2" (debería ser R3) |
| 7 | 8.2 | La topología de Packet Tracer lleva el pie «Figura 46», número ya usado por las memorias de los servidores, y el texto que la explica la cita como «figura 45» |
| 8 | Tabla 6 | No se indica la máscara de las VLANs propuestas; en el seed se supuso /24 |


## 9. ACL y perímetro con denegación por defecto (práctica de ACL y NAT)

La base guarda ahora las **políticas P1–P8**, las **ACL** (v1 = informe, v2 = propuesta), sus reglas, en qué interfaz y sentido se aplican y las **pruebas de conectividad**. `infra.v_acl_postura` marca qué ACL terminan en `permit any` y `infra.generar_config_acl(router, versión)` regenera el texto IOS desde la base (verificado: el texto regenerado reproduce las pruebas). Las herramientas están en `acl/` (ver `acl/LEEME_ACL.md`).

**Qué significa «por defecto».** Las 8 ACL del informe terminan en `permit any` / `permit ip any any`: prohíben lo escrito y permiten todo lo demás (lista negra). La v2 invierte el criterio: cada VLAN tiene una ACL de entrada que permite solo los flujos de la matriz `acl/politicas.js` y termina en `deny ip any any log`; el enlace al ISP (`G0/0`) solo admite respuestas a conexiones iniciadas desde dentro y descarta orígenes privados o de loopback entrantes (anti-suplantación). Se conservan las 8 ACL originales para la práctica; la v2 es una mejora propuesta.

**Resultados del simulador** (385 combinaciones origen × destino × servicio):

| | v1 (informe) | v2 (por defecto) |
|---|---|---|
| Tabla 16 (11 pruebas) | 11/11, cada una bloqueada por la ACL que el informe indica | 11/11 |
| Combinaciones permitidas | 282 (73,2 %) | 36 (9,4 %) = exactamente los flujos autorizados |
| Unidireccionales (llega la petición, se pierde la respuesta) | 44 | 0 |
| Suplantación / entrada desde el ISP (6 pruebas) | las 6 son permitidas (no hay ACL en el borde) | las 6 se bloquean |
| DHCP en las 5 VLAN | permitido | permitido (regla explícita) |

**Hallazgos sobre la configuración del informe** (verificados con el simulador; la Tabla 16 no los pregunta):

| # | Hallazgo | Detalle |
|---|---|---|
| 1 | **P2 solo se cumple en un sentido** | ACL 11 bloquea Área X → Área Y. En sentido Y → X la petición **llega** al host de X y solo se pierde la respuesta (ACL sin estado). Falta una regla simétrica |
| 2 | **P7 no cubre el gateway** | `EXT_USER_MGMT` está en *salida* de G0/2.99: el tráfico hacia el propio router (10.10.99.1) no se filtra. Desde el Área X se puede hacer ping y Telnet al gateway de administración. La sección 12 dice que ese acceso se controla con la ACL 111, pero esa ACL es de la VLAN 40 y solo bloquea TCP/443. Solución: poner la regla en entrada de G0/2.30 (fusionarla con la ACL 101) |
| 3 | **P5 y P6 son listas negras** | Solo se cierra HTTP (VLAN 30 → servidores) y HTTPS (VLAN 40 → VLAN 99). Siguen abiertos RDP, SSH, Telnet, etc., aunque P5 dice «solo se permiten los servicios necesarios» |
| 4 | **Efecto colateral en P7** | Al bloquear en salida todo lo que sale de la VLAN 30 hacia la VLAN 99, también se pierden las **respuestas**: un administrador no puede hacer ping a un equipo del Área X (unidireccional) |
| 5 | **P4 y la redundancia** | `STD_BLOCK_GUEST_R1B` bloquea en G0/1 todo el tráfico de la VLAN 40 que sale por R1B. Si R1B es el camino de respaldo a Internet (HSRP del Diario), al conmutar el Área Y quedaría sin salida. No se probó: es un riesgo de diseño a verificar |
| 6 | **P8 acotado** | Solo cubre Telnet de la VLAN 30 a `10.0.1.2`. Otras VLAN u otras IP de R1B no están cubiertas; lo correcto es `access-class` en las líneas vty y SSH |

**Observaciones sobre el texto del informe de ACL:** la referencia [5] cita «Alvarado Jula, N. et al.» con año 2026, pero el Diario lleva otros cuatro autores y fecha de julio de 2025. El texto entregado trae secciones repetidas (8.2 a 8.9 y 9 a 10 aparecen varias veces) y cuadros «[ Insertar captura de Cisco Packet Tracer ]» pendientes en las figuras 3 a 10.

**Límites.** El simulador valida la lógica de las ACL, no la sintaxis de tu versión de Packet Tracer ni NAT. Antes de entregar, repite las pruebas en PT con `acl/plan_pruebas_packet_tracer.md`. Las ACL sin estado (`established`) no reemplazan un firewall con estado: en la red real esa función es del FortiGate.
