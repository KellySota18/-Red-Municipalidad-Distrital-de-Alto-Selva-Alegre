'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { Router, Red } = require('./simulador');
const { ZONAS, FW_R1B_IP, R1B_IP } = require('./politicas');

/** Arma la red del informe y le carga las configuraciones indicadas (en orden). */
function construirRed(cfgFortinet = [], cfgR1B = []) {
  const ifaces = { 'G0/1': `${FW_R1B_IP}/30` };
  for (const z of Object.values(ZONAS)) ifaces[z.iface] = `${z.gw}/24`;
  const fw = new Router('Fortinet', ifaces, { defecto: 'G0/0' });
  const r1b = new Router('R1B', { 'G0/0': `${R1B_IP}/30` });
  for (const f of cfgFortinet) fw.config(fs.readFileSync(path.resolve(__dirname, f), 'utf8'));
  for (const f of cfgR1B) r1b.config(fs.readFileSync(path.resolve(__dirname, f), 'utf8'));
  return new Red().agregar(fw).agregar(r1b).unir('Fortinet', 'G0/1', 'R1B', 'G0/0');
}
module.exports = { construirRed };
