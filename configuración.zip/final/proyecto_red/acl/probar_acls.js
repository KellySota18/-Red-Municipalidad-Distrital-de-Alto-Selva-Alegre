'use strict';
/**
 * Pruebas de las ACL del informe (v1) y de la propuesta de perímetro con denegación por defecto (v2).
 * Uso:  node probar_acls.js [--md informe.md] [--sql resultados.sql]
 */
const fs = require('node:fs');
const { construirRed } = require('./topologia');
const { HOSTS, SERVICIOS, FLUJOS, permitidoPorMatriz } = require('./politicas');

const args = process.argv.slice(2);
const opt = n => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : null; };

const V1 = () => construirRed(['config/R1_v1_informe.cfg'], ['config/R1B_v1_informe.cfg']);
const V2 = () => construirRed(['config/R1_v1_informe.cfg', 'config/R1_v2_migracion.cfg'],
                              ['config/R1B_v1_informe.cfg', 'config/R1B_v2_migracion.cfg']);

const TABLA16 = [
  { n: 1,  o: 'PC1', d: 'Server3',  s: 'icmp',   esp: 'permitido', acl: '—' },
  { n: 2,  o: 'PC7', d: 'Server3',  s: 'icmp',   esp: 'bloqueado', acl: 'ACL 10' },
  { n: 3,  o: 'PC7', d: 'Printer6', s: 'icmp',   esp: 'bloqueado', acl: 'STD_GUEST_PRINTERS' },
  { n: 4,  o: 'PC1', d: 'PC7',      s: 'icmp',   esp: 'bloqueado', acl: 'ACL 11' },
  { n: 5,  o: 'PC7', d: 'R1B',      s: 'icmp',   esp: 'bloqueado', acl: 'STD_BLOCK_GUEST_R1B' },
  { n: 6,  o: 'PC1', d: 'R1B',      s: 'icmp',   esp: 'permitido', acl: '—' },
  { n: 7,  o: 'PC1', d: 'ADMIN',    s: 'icmp',   esp: 'bloqueado', acl: 'EXT_USER_MGMT' },
  { n: 8,  o: 'PC7', d: 'GW99',     s: 'icmp',   esp: 'permitido', acl: '—' },
  { n: 9,  o: 'PC1', d: 'Server3',  s: 'tcp80',  esp: 'bloqueado', acl: 'ACL 101' },
  { n: 10, o: 'PC7', d: 'ADMIN',    s: 'tcp443', esp: 'bloqueado', acl: 'ACL 111' },
  { n: 11, o: 'PC1', d: 'R1B',      s: 'tcp23',  esp: 'bloqueado', acl: 'EXT_BLOCK_TELNET_R1B' },
];

const corre = (red, o, d, s) => red.flujo(HOSTS[o], HOSTS[d], SERVICIOS[s]);
const donde = r => { const x = r.ida.entregado ? r.vuelta : r.ida; return x && x.acl ? `${x.acl} (${x.router} ${x.iface} ${x.sentido})` : ''; };
const etiqueta = (o, d, s) => `${o} → ${d} ${s}`;
const resultados = [];                                   // para --md / --sql
let fallos = 0;
const out = [];
const p = (...a) => { const t = a.join(' '); out.push(t); console.log(t); };
const marca = ok => (ok ? 'OK ' : 'FALLA');

function seccion(t) { p('\n' + '='.repeat(78)); p(t); p('='.repeat(78)); }

/* ============ A) Tabla 16 del informe contra la configuración del Anexo A ============ */
function pruebaTabla16(version, red, verificarAcl) {
  seccion(`A) Tabla 16 del informe - ${version}`);
  for (const t of TABLA16) {
    const r = corre(red, t.o, t.d, t.s);
    const okVer = r.veredicto === t.esp;
    const okAcl = !verificarAcl || t.esp === 'permitido' || (r.ida.acl && t.acl.replace('ACL ', '') === r.ida.acl);
    const ok = okVer && okAcl; if (!ok) fallos++;
    p(`${marca(ok)} #${String(t.n).padStart(2)} ${etiqueta(t.o, t.d, t.s).padEnd(26)} esperado=${t.esp.padEnd(10)} obtenido=${r.veredicto.padEnd(14)} ${donde(r)}`);
    resultados.push({ version, origen: t.o, destino: t.d, svc: t.s, esperado: t.esp, obtenido: r.veredicto, ok });
  }
}

/* ============ B) Hallazgos sobre v1 (preguntas que la Tabla 16 no hace) ============ */
const EXTRAS = [
  { o: 'PC7', d: 'PC1',     s: 'tcp443',  q: 'Área Y → Área X (P2 dice "no deben comunicarse entre sí")' },
  { o: 'PC1', d: 'GW99',    s: 'icmp',    q: 'Área X → gateway de administración 10.10.99.1 (P7: "ningún acceso")' },
  { o: 'PC1', d: 'GW99',    s: 'tcp23',   q: 'Área X → Telnet al router en 10.10.99.1 (P7)' },
  { o: 'PC7', d: 'ADMIN',   s: 'tcp22',   q: 'Área Y → SSH a un host de administración (P6 solo cierra el 443)' },
  { o: 'PC1', d: 'Server3', s: 'tcp3389', q: 'Área X → Escritorio remoto a servidores (P5 dice "solo servicios necesarios")' },
  { o: 'PC1', d: 'Server3', s: 'tcp443',  q: 'Área X → HTTPS a servidores (debería estar permitido)' },
];
function hallazgos(version, red) {
  seccion(`B) Hallazgos adicionales - ${version}`);
  for (const t of EXTRAS) {
    const r = corre(red, t.o, t.d, t.s);
    p(`${r.veredicto.padEnd(14)} ${etiqueta(t.o, t.d, t.s).padEnd(26)} ${t.q}`);
    resultados.push({ version, origen: t.o, destino: t.d, svc: t.s, esperado: null, obtenido: r.veredicto, ok: null });
  }
}

/* ============ C) Matriz completa: cada origen × destino × servicio contra la política ============ */
function matriz(version, red) {
  const origenes = ['PC1', 'PC7', 'Server3', 'Printer6', 'ADMIN'];
  const destinos = ['Server3', 'Printer6', 'PC1', 'PC7', 'ADMIN', 'GW99', 'R1B', 'INTERNET'];
  const svcs = Object.keys(SERVICIOS);
  let total = 0, perm = 0, deMas = [], deMenos = [], uni = [];
  for (const o of origenes) for (const d of destinos) {
    if (o === d || HOSTS[o].zona === HOSTS[d].zona) continue;
    for (const s of svcs) {
      total++;
      const r = corre(red, o, d, s);
      const esp = permitidoPorMatriz(HOSTS[o].zona, HOSTS[d].dest, s);
      if (r.veredicto === 'permitido') perm++;
      if (r.veredicto === 'unidireccional') uni.push(etiqueta(o, d, s));
      if (r.veredicto === 'permitido' && !esp) deMas.push([o, d, s]);
      if (r.veredicto !== 'permitido' && esp) deMenos.push([o, d, s, r.veredicto, donde(r)]);
    }
  }
  return { total, perm, deMas, deMenos, uni };
}
function resumenMatriz(version, red) {
  seccion(`C) Matriz origen × destino × servicio - ${version}`);
  const m = matriz(version, red);
  const esperados = FLUJOS.reduce((a, [, , s]) => a + s.length, 0);
  p(`Combinaciones probadas: ${m.total}`);
  p(`Permitidas por la configuración: ${m.perm}  (la matriz de políticas autoriza solo ${esperados} flujos)`);
  p(`Permitidas que la matriz NO autoriza (postura "permitir por defecto"): ${m.deMas.length}`);
  p(`Autorizadas por la matriz pero bloqueadas (rotas): ${m.deMenos.length}`);
  p(`Unidireccionales (llega la petición, se pierde la respuesta): ${m.uni.length}`);
  if (m.deMenos.length) m.deMenos.slice(0, 10).forEach(x => p('   rota: ' + x.join(' | ')));
  const porPar = {};
  for (const [o, d] of m.deMas) porPar[`${o}→${d}`] = (porPar[`${o}→${d}`] || 0) + 1;
  const top = Object.entries(porPar).sort((a, b) => b[1] - a[1]).slice(0, 8);
  if (top.length) { p('Pares con más servicios no autorizados por la matriz:'); top.forEach(([k, n]) => p(`   ${k.padEnd(20)} ${n} servicios`)); }
  if (m.uni.length) p('Ejemplos unidireccionales: ' + m.uni.slice(0, 4).join('; '));
  return m;
}

/* ============ D) Perímetro: suplantación, entrada desde Internet y servicios de infraestructura ============ */
function perimetro(version, red) {
  seccion(`D) Perímetro y servicios de infraestructura - ${version}`);
  const falsos = {
    SPOOF_X:     { ip: '10.10.30.5', attach: { router: 'Fortinet', iface: 'G0/0' } },
    SPOOF_ADMIN: { ip: '10.10.99.10', attach: { router: 'Fortinet', iface: 'G0/0' } },
    RFC1918_EXT: { ip: '192.168.5.5', attach: { router: 'Fortinet', iface: 'G0/0' } },
  };
  const casos = [
    ['INTERNET', 'Server3', 'tcp3389', 'bloqueado', 'Internet → RDP a servidor (conexión nueva)'],
    ['INTERNET', 'GW99',    'tcp22',   'bloqueado', 'Internet → SSH al gateway de administración'],
    ['INTERNET', 'PC1',     'tcp443',  'bloqueado', 'Internet → host interno (conexión nueva)'],
    ['SPOOF_X',     'Server3', 'tcp443', 'bloqueado', 'Suplantación: IP del Área X entrando por el ISP'],
    ['SPOOF_ADMIN', 'GW99',    'tcp22',  'bloqueado', 'Suplantación: IP de administración entrando por el ISP'],
    ['RFC1918_EXT', 'Server3', 'tcp443', 'bloqueado', 'Origen privado (RFC 1918) entrando por el ISP'],
  ];
  const hs = { ...HOSTS, ...falsos };
  for (const [o, d, s, esp, q] of casos) {
    const r = red.flujo(hs[o], hs[d], SERVICIOS[s]);
    const ok = r.veredicto === esp;
    p(`${version === 'v2' ? marca(ok) : '    '} ${r.veredicto.padEnd(14)} ${q}`);
    if (version === 'v2' && !ok) fallos++;
    resultados.push({ version, origen: o, destino: d, svc: s, esperado: esp, obtenido: r.veredicto, ok: version === 'v2' ? ok : null });
  }
  // DHCP: sin esto, los equipos no obtienen IP con denegación por defecto
  for (const z of ['X', 'Y', 'PRINTERS', 'SERVERS', 'MGMT']) {
    const host = Object.values(HOSTS).find(h => h.zona === z);
    const pkt = { proto: 'udp', src: '0.0.0.0', dst: '255.255.255.255', sport: 68, dport: 67, ack: false, icmp: null };
    const r = red.recorrer(pkt, host.attach.router, host.attach.iface);
    const ok = r.entregado; if (version === 'v2' && !ok) fallos++;
    p(`${marca(ok)} ${(ok ? 'permitido' : 'bloqueado').padEnd(14)} DHCP DISCOVER desde VLAN ${z}`);
    resultados.push({ version, origen: 'DHCP-' + z, destino: 'router', svc: 'udp67', esperado: 'permitido', obtenido: ok ? 'permitido' : 'bloqueado', ok });
  }
  const hsrp = { proto: 'udp', src: FW_R1B(), dst: '224.0.0.2', sport: 1985, dport: 1985, ack: false, icmp: null };
  const r = red.recorrer({ ...hsrp, src: '10.0.1.2' }, 'Fortinet', 'G0/1');
  p(`${marca(r.entregado)} ${(r.entregado ? 'permitido' : 'bloqueado').padEnd(14)} HSRP hello de R1B hacia Fortinet (si el diseño usa HSRP)`);
  if (version === 'v2' && !r.entregado) fallos++;
}
function FW_R1B() { return '10.0.1.1'; }

/* ============ Ejecución ============ */
const v1 = V1();
pruebaTabla16('v1 (informe, Anexo A)', v1, true);
hallazgos('v1', v1);
const m1 = resumenMatriz('v1', v1);
perimetro('v1', v1);

let m2 = null;
if (fs.existsSync(require('node:path').join(__dirname, 'config/R1_v2_migracion.cfg'))) {
  const v2 = V2();
  pruebaTabla16('v2 (denegación por defecto, tras la migración)', v2, false);
  hallazgos('v2', v2);
  m2 = resumenMatriz('v2', v2);
  perimetro('v2', v2);
  const r = [...m2.deMas, ...m2.deMenos]; if (r.length || m2.uni.length) fallos += r.length + m2.uni.length;
  seccion('COMPARACIÓN');
  p(`Combinaciones probadas ........ ${m1.total}`);
  p(`Permitidas con v1 (informe) .... ${m1.perm}  (${(100 * m1.perm / m1.total).toFixed(1)} %)`);
  p(`Permitidas con v2 (por defecto) ${m2.perm}  (${(100 * m2.perm / m2.total).toFixed(1)} %)  = flujos autorizados por la matriz`);
}
p(`\nRESULTADO: ${fallos === 0 ? 'TODAS LAS PRUEBAS ESPERADAS PASARON' : fallos + ' PRUEBA(S) FALLARON'}`);

if (opt('--md')) fs.writeFileSync(opt('--md'), '```\n' + out.join('\n') + '\n```\n');
if (opt('--sql')) {
  const q = s => (s === null || s === undefined ? 'NULL' : `'${String(s).replace(/'/g, "''")}'`);
  const filas = resultados.filter(r => r.esperado !== null).map(r =>
    `  (${q(r.version.startsWith('v1') ? 'v1_informe' : 'v2_default_deny')}, ${q(r.origen)}, ${q(r.destino)}, ${q(r.svc)}, ${q(r.esperado)}, ${q(r.obtenido)}, 'simulador')`);
  fs.writeFileSync(opt('--sql'), `-- Generado por probar_acls.js\nBEGIN;\nSET LOCAL search_path = infra, extensions;\n` +
    `DELETE FROM pruebas_conectividad WHERE fuente = 'simulador';   -- reemplaza resultados anteriores (idempotente)\nINSERT INTO pruebas_conectividad (version, origen, destino, servicio, resultado_esperado, resultado_obtenido, fuente) VALUES\n${filas.join(',\n')};\nCOMMIT;\n`);
}
process.exit(fallos === 0 ? 0 : 1);
