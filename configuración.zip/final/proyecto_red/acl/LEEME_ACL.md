# ACL y perímetro con denegación por defecto

Herramientas para **probar** las ACL de la práctica (ACL y NAT, Computación en Red II) y **proponer** una versión
con política de denegación por defecto, todo verificable sin abrir Packet Tracer. Requiere solo Node 20+ (sin `npm install`).

## Archivos
| Archivo | Para qué sirve |
|---|---|
| `politicas.js` | **Matriz de políticas**: qué flujos están permitidos (todo lo demás se deniega). Única fuente de verdad |
| `simulador.js` | Motor de ACL de Cisco IOS: primera coincidencia, deny implícito, estándar/extendida, in/out, `established`, ida y vuelta |
| `topologia.js` | Arma la red del informe (Fortinet R1 + R1B) y carga configuraciones |
| `config/R1_v1_informe.cfg`, `R1B_v1_informe.cfg` | Anexo A del informe, tal cual |
| `generar_config.js` | Genera `config/R1_v2_migracion.cfg` y `R1B_v2_migracion.cfg` desde la matriz |
| `probar_acls.js` | Ejecuta las pruebas (Tabla 16, hallazgos, matriz completa, perímetro) para v1 y v2 |
| `plan_pt.js` | Genera `plan_pruebas_packet_tracer.md` para repetir las pruebas a mano en Packet Tracer |
| `cfg_a_sql.js` | Convierte un `.cfg` en `INSERT` para las tablas `acls`, `acl_reglas`, `acl_aplicaciones` |
| `resultados_pruebas_acl.md` | Salida completa de la última ejecución |

## Comandos
```powershell
cd C:\proyecto_red\acl
node generar_config.js          # regenera la v2 si cambias politicas.js
node probar_acls.js             # debe terminar con: TODAS LAS PRUEBAS ESPERADAS PASARON
node plan_pt.js                 # plan de pruebas manuales para Packet Tracer
```

## Cargar las ACL en la base de datos (después del esquema y de seed_datos_municipalidad.sql)
```powershell
$env:Path += ";C:\Program Files\PostgreSQL\16\bin"; cd C:\proyecto_red\bd
psql -U postgres -d infra_red_db -v ON_ERROR_STOP=1 -f infra_red_acl_extension.sql
psql -U postgres -d infra_red_db -v ON_ERROR_STOP=1 -f seed_acl_informe.sql
psql -U postgres -d infra_red_db -v ON_ERROR_STOP=1 -f seed_acl_reglas.sql
psql -U postgres -d infra_red_db -v ON_ERROR_STOP=1 -f seed_pruebas_simulador.sql
psql -U postgres -d infra_red_db -c "SELECT router, version, acl, postura FROM infra.v_acl_postura ORDER BY 2,1,3;"
```
Para regenerar esos SQL tras cambiar una ACL: `node cfg_a_sql.js R1-FORTINET v2_default_deny config\R1_v2_migracion.cfg`.

## Qué modela y qué NO
- Modela: filtrado por ACL, enrutamiento entre subinterfaces, router-on-a-stick, tráfico hacia el propio router
  (no se filtra con ACL de salida) y respuestas (las ACL no tienen estado, por eso se prueba ida y vuelta).
- **No modela**: NAT/PAT, ARP, STP, estado real de TCP (solo el bit ACK para `established`), HSRP real, ICMP por tipo
  más allá de `echo`/`echo-reply`/`unreachable`/`time-exceeded`.
- La v2 usa `established`, `echo-reply` y `deny ... log`: son sintaxis estándar de IOS, pero **confirma en tu versión de
  Packet Tracer**. Una ACL con `established` no equivale a un firewall con estado (el FortiGate real sí lo tiene).

## Suposiciones que debes confirmar (el informe no las documenta)
1. Fortinet G0/1 = 10.0.1.1/30 hacia R1B. 2. Fortinet G0/0 = enlace al ISP. 3. PC1 recibe 10.10.30.10 por DHCP.
4. Servicios "necesarios": DNS (udp 53), HTTPS (443) a servidores, impresión (9100/631/515), gestión (SSH/HTTPS/SNMP) desde la VLAN 99,
   navegación (80/443) a Internet. 5. Si usan HSRP entre Fortinet y R1B, la regla de la v2 lo permite; si no, bórrala.

## Aplicar la v2 sin quedarte fuera del router
Hazlo desde la **consola**, no por Telnet/SSH. Guarda antes (`copy running-config startup-config` solo después de probar).
En equipos reales, `reload in 10` antes de aplicar y `reload cancel` al confirmar que todo funciona.
