```

==============================================================================
A) Tabla 16 del informe - v1 (informe, Anexo A)
==============================================================================
OK  # 1 PC1 → Server3 icmp         esperado=permitido  obtenido=permitido      
OK  # 2 PC7 → Server3 icmp         esperado=bloqueado  obtenido=bloqueado      10 (Fortinet G0/2.10 out)
OK  # 3 PC7 → Printer6 icmp        esperado=bloqueado  obtenido=bloqueado      STD_GUEST_PRINTERS (Fortinet G0/2.20 out)
OK  # 4 PC1 → PC7 icmp             esperado=bloqueado  obtenido=bloqueado      11 (Fortinet G0/2.40 out)
OK  # 5 PC7 → R1B icmp             esperado=bloqueado  obtenido=bloqueado      STD_BLOCK_GUEST_R1B (Fortinet G0/1 out)
OK  # 6 PC1 → R1B icmp             esperado=permitido  obtenido=permitido      
OK  # 7 PC1 → ADMIN icmp           esperado=bloqueado  obtenido=bloqueado      EXT_USER_MGMT (Fortinet G0/2.99 out)
OK  # 8 PC7 → GW99 icmp            esperado=permitido  obtenido=permitido      
OK  # 9 PC1 → Server3 tcp80        esperado=bloqueado  obtenido=bloqueado      101 (Fortinet G0/2.30 in)
OK  #10 PC7 → ADMIN tcp443         esperado=bloqueado  obtenido=bloqueado      111 (Fortinet G0/2.40 in)
OK  #11 PC1 → R1B tcp23            esperado=bloqueado  obtenido=bloqueado      EXT_BLOCK_TELNET_R1B (R1B G0/0 in)

==============================================================================
B) Hallazgos adicionales - v1
==============================================================================
unidireccional PC7 → PC1 tcp443           Área Y → Área X (P2 dice "no deben comunicarse entre sí")
permitido      PC1 → GW99 icmp            Área X → gateway de administración 10.10.99.1 (P7: "ningún acceso")
permitido      PC1 → GW99 tcp23           Área X → Telnet al router en 10.10.99.1 (P7)
permitido      PC7 → ADMIN tcp22          Área Y → SSH a un host de administración (P6 solo cierra el 443)
permitido      PC1 → Server3 tcp3389      Área X → Escritorio remoto a servidores (P5 dice "solo servicios necesarios")
permitido      PC1 → Server3 tcp443       Área X → HTTPS a servidores (debería estar permitido)

==============================================================================
C) Matriz origen × destino × servicio - v1
==============================================================================
Combinaciones probadas: 385
Permitidas por la configuración: 282  (la matriz de políticas autoriza solo 36 flujos)
Permitidas que la matriz NO autoriza (postura "permitir por defecto"): 247
Autorizadas por la matriz pero bloqueadas (rotas): 1
Unidireccionales (llega la petición, se pierde la respuesta): 44
   rota: ADMIN | PC1 | icmp | unidireccional | EXT_USER_MGMT (Fortinet G0/2.99 out)
Pares con más servicios no autorizados por la matriz:
   PC1→GW99             11 servicios
   Server3→Printer6     11 servicios
   Server3→PC1          11 servicios
   Server3→ADMIN        11 servicios
   Server3→GW99         11 servicios
   Server3→R1B          11 servicios
   Printer6→Server3     11 servicios
   Printer6→PC1         11 servicios
Ejemplos unidireccionales: PC7 → PC1 icmp; PC7 → PC1 tcp22; PC7 → PC1 tcp23; PC7 → PC1 tcp80

==============================================================================
D) Perímetro y servicios de infraestructura - v1
==============================================================================
     permitido      Internet → RDP a servidor (conexión nueva)
     permitido      Internet → SSH al gateway de administración
     permitido      Internet → host interno (conexión nueva)
     permitido      Suplantación: IP del Área X entrando por el ISP
     permitido      Suplantación: IP de administración entrando por el ISP
     permitido      Origen privado (RFC 1918) entrando por el ISP
OK  permitido      DHCP DISCOVER desde VLAN X
OK  permitido      DHCP DISCOVER desde VLAN Y
OK  permitido      DHCP DISCOVER desde VLAN PRINTERS
OK  permitido      DHCP DISCOVER desde VLAN SERVERS
OK  permitido      DHCP DISCOVER desde VLAN MGMT
OK  permitido      HSRP hello de R1B hacia Fortinet (si el diseño usa HSRP)

==============================================================================
A) Tabla 16 del informe - v2 (denegación por defecto, tras la migración)
==============================================================================
OK  # 1 PC1 → Server3 icmp         esperado=permitido  obtenido=permitido      
OK  # 2 PC7 → Server3 icmp         esperado=bloqueado  obtenido=bloqueado      FW_IN_VLAN40_AREA_Y (Fortinet G0/2.40 in)
OK  # 3 PC7 → Printer6 icmp        esperado=bloqueado  obtenido=bloqueado      FW_IN_VLAN40_AREA_Y (Fortinet G0/2.40 in)
OK  # 4 PC1 → PC7 icmp             esperado=bloqueado  obtenido=bloqueado      FW_IN_VLAN30_AREA_X (Fortinet G0/2.30 in)
OK  # 5 PC7 → R1B icmp             esperado=bloqueado  obtenido=bloqueado      FW_IN_VLAN40_AREA_Y (Fortinet G0/2.40 in)
OK  # 6 PC1 → R1B icmp             esperado=permitido  obtenido=permitido      
OK  # 7 PC1 → ADMIN icmp           esperado=bloqueado  obtenido=bloqueado      FW_IN_VLAN30_AREA_X (Fortinet G0/2.30 in)
OK  # 8 PC7 → GW99 icmp            esperado=permitido  obtenido=permitido      
OK  # 9 PC1 → Server3 tcp80        esperado=bloqueado  obtenido=bloqueado      FW_IN_VLAN30_AREA_X (Fortinet G0/2.30 in)
OK  #10 PC7 → ADMIN tcp443         esperado=bloqueado  obtenido=bloqueado      FW_IN_VLAN40_AREA_Y (Fortinet G0/2.40 in)
OK  #11 PC1 → R1B tcp23            esperado=bloqueado  obtenido=bloqueado      FW_IN_VLAN30_AREA_X (Fortinet G0/2.30 in)

==============================================================================
B) Hallazgos adicionales - v2
==============================================================================
bloqueado      PC7 → PC1 tcp443           Área Y → Área X (P2 dice "no deben comunicarse entre sí")
bloqueado      PC1 → GW99 icmp            Área X → gateway de administración 10.10.99.1 (P7: "ningún acceso")
bloqueado      PC1 → GW99 tcp23           Área X → Telnet al router en 10.10.99.1 (P7)
bloqueado      PC7 → ADMIN tcp22          Área Y → SSH a un host de administración (P6 solo cierra el 443)
bloqueado      PC1 → Server3 tcp3389      Área X → Escritorio remoto a servidores (P5 dice "solo servicios necesarios")
permitido      PC1 → Server3 tcp443       Área X → HTTPS a servidores (debería estar permitido)

==============================================================================
C) Matriz origen × destino × servicio - v2
==============================================================================
Combinaciones probadas: 385
Permitidas por la configuración: 36  (la matriz de políticas autoriza solo 36 flujos)
Permitidas que la matriz NO autoriza (postura "permitir por defecto"): 0
Autorizadas por la matriz pero bloqueadas (rotas): 0
Unidireccionales (llega la petición, se pierde la respuesta): 0

==============================================================================
D) Perímetro y servicios de infraestructura - v2
==============================================================================
OK  bloqueado      Internet → RDP a servidor (conexión nueva)
OK  bloqueado      Internet → SSH al gateway de administración
OK  bloqueado      Internet → host interno (conexión nueva)
OK  bloqueado      Suplantación: IP del Área X entrando por el ISP
OK  bloqueado      Suplantación: IP de administración entrando por el ISP
OK  bloqueado      Origen privado (RFC 1918) entrando por el ISP
OK  permitido      DHCP DISCOVER desde VLAN X
OK  permitido      DHCP DISCOVER desde VLAN Y
OK  permitido      DHCP DISCOVER desde VLAN PRINTERS
OK  permitido      DHCP DISCOVER desde VLAN SERVERS
OK  permitido      DHCP DISCOVER desde VLAN MGMT
OK  permitido      HSRP hello de R1B hacia Fortinet (si el diseño usa HSRP)

==============================================================================
COMPARACIÓN
==============================================================================
Combinaciones probadas ........ 385
Permitidas con v1 (informe) .... 282  (73.2 %)
Permitidas con v2 (por defecto) 36  (9.4 %)  = flujos autorizados por la matriz

RESULTADO: TODAS LAS PRUEBAS ESPERADAS PASARON
```
