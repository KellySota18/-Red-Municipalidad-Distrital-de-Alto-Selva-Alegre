'use strict';
// Genera el plan de pruebas para ejecutar a mano en Packet Tracer, con el resultado esperado según el simulador.
const { construirRed } = require('./topologia');
const { HOSTS, SERVICIOS } = require('./politicas');
const v1 = construirRed(['config/R1_v1_informe.cfg'], ['config/R1B_v1_informe.cfg']);
const v2 = construirRed(['config/R1_v1_informe.cfg', 'config/R1_v2_migracion.cfg'], ['config/R1B_v1_informe.cfg', 'config/R1B_v2_migracion.cfg']);
const IP = { PC1: '10.10.30.10', PC7: '10.10.40.11', Server3: '10.10.10.20', Printer6: '10.10.20.20', ADMIN: '10.10.99.10', GW99: '10.10.99.1', R1B: '10.0.1.2' };
const cmd = (s, d) => ({ icmp: `ping ${IP[d]}`, tcp80: `Web Browser: http://${IP[d]}`, tcp443: `Web Browser: https://${IP[d]}`,
  tcp23: `telnet ${IP[d]}`, tcp22: `ssh -l admin ${IP[d]}`, tcp3389: '(no se puede probar en PT)' }[s]);
const T = [
  ['PC1','Server3','icmp','Tabla 16 #1'], ['PC7','Server3','icmp','Tabla 16 #2'], ['PC7','Printer6','icmp','Tabla 16 #3'],
  ['PC1','PC7','icmp','Tabla 16 #4'], ['PC7','R1B','icmp','Tabla 16 #5'], ['PC1','R1B','icmp','Tabla 16 #6'],
  ['PC1','ADMIN','icmp','Tabla 16 #7'], ['PC7','GW99','icmp','Tabla 16 #8'], ['PC1','Server3','tcp80','Tabla 16 #9'],
  ['PC7','ADMIN','tcp443','Tabla 16 #10'], ['PC1','R1B','tcp23','Tabla 16 #11'],
  ['PC7','PC1','icmp','Hallazgo: P2 en sentido Y→X'], ['PC1','GW99','icmp','Hallazgo: P7 hacia el gateway'],
  ['PC1','GW99','tcp23','Hallazgo: P7 hacia el gateway'], ['PC7','ADMIN','tcp22','Hallazgo: P6 solo cierra 443'],
  ['PC1','Server3','tcp443','Servicio necesario'], ['ADMIN','R1B','tcp22','Gestión SSH'], ['ADMIN','PC1','icmp','Diagnóstico desde VLAN 99'],
];
const L = ['# Plan de pruebas en Packet Tracer', '',
 'Resultado esperado según el simulador (probar_acls.js). Ejecútalo en PT y anota "obtenido". En PT las IP de PC1 y PC7 pueden variar (DHCP): ajusta el destino.', '',
 '| # | Desde | Comando en PT | v1 (informe) | v2 (por defecto) | Motivo |', '|---|---|---|---|---|---|'];
T.forEach(([o, d, s, m], i) => {
  const a = v1.flujo(HOSTS[o], HOSTS[d], SERVICIOS[s]).veredicto, b = v2.flujo(HOSTS[o], HOSTS[d], SERVICIOS[s]).veredicto;
  L.push(`| ${i + 1} | ${o} | ${cmd(s, d)} | ${a} | ${b} | ${m} |`);
});
L.push('', '**Cómo leerlo:** "unidireccional" = la petición llega pero la respuesta se descarta (en PT el ping falla igual que si estuviera bloqueado; confírmalo con `show access-lists` mirando los contadores `matches`).',
 '', '**Antes de aplicar la v2 en PT:** `copy running-config startup-config` en R1 y R1B (respaldo), aplica desde la consola, prueba DHCP (`ipconfig /renew` en PC1 y PC7) y recién entonces las demás.');
require('node:fs').writeFileSync('plan_pruebas_packet_tracer.md', L.join('\n') + '\n');
console.log(L.slice(4).join('\n'));
