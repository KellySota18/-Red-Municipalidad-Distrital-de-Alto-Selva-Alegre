'use strict';
/**
 * MATRIZ DE POLÍTICAS: única fuente de verdad.
 * De aquí se GENERAN las ACL por defecto-denegar (generar_config.js) y contra ella se PRUEBAN (probar_acls.js).
 * Todo lo que no está en FLUJOS queda prohibido.
 *
 * SUPOSICIONES (el informe no las documenta; confírmalas):
 *  - Fortinet(R1) G0/1 = 10.0.1.1/30 hacia R1B (10.0.1.2). El informe solo da la IP de R1B.
 *  - Fortinet G0/0 = enlace al ISP (Router0). El informe no nombra esa interfaz.
 *  - PC1 recibe 10.10.30.10 por DHCP (el informe dice "DHCP en 10.10.30.0/24").
 *  - Servicios "necesarios": DNS (udp 53) y HTTPS (tcp 443) hacia servidores, impresión (9100/631/515),
 *    gestión SSH/HTTPS/SNMP desde la VLAN 99 y navegación (80/443) a Internet.
 */
const ZONAS = {
  SERVERS:  { nombre: 'VLAN 10 SERVERS',  iface: 'G0/2.10', red: '10.10.10.0', wild: '0.0.0.255', gw: '10.10.10.1', acl: 'FW_IN_VLAN10_SERVERS' },
  PRINTERS: { nombre: 'VLAN 20 PRINTERS', iface: 'G0/2.20', red: '10.10.20.0', wild: '0.0.0.255', gw: '10.10.20.1', acl: 'FW_IN_VLAN20_PRINTERS' },
  X:        { nombre: 'VLAN 30 AREA_X',   iface: 'G0/2.30', red: '10.10.30.0', wild: '0.0.0.255', gw: '10.10.30.1', acl: 'FW_IN_VLAN30_AREA_X' },
  Y:        { nombre: 'VLAN 40 AREA_Y',   iface: 'G0/2.40', red: '10.10.40.0', wild: '0.0.0.255', gw: '10.10.40.1', acl: 'FW_IN_VLAN40_AREA_Y' },
  MGMT:     { nombre: 'VLAN 99 MGMT',     iface: 'G0/2.99', red: '10.10.99.0', wild: '0.0.0.255', gw: '10.10.99.1', acl: 'FW_IN_VLAN99_MGMT' },
};
const FW_R1B_IP = '10.0.1.1';
const R1B_IP = '10.0.1.2';

/** Destinos nombrados (para escribir las reglas). */
const DESTINOS = {
  SERVERS:  { txt: '10.10.10.0 0.0.0.255' }, PRINTERS: { txt: '10.10.20.0 0.0.0.255' },
  X:        { txt: '10.10.30.0 0.0.0.255' }, Y:        { txt: '10.10.40.0 0.0.0.255' },
  MGMT_GW:  { txt: 'host 10.10.99.1' },      R1B:      { txt: `host ${R1B_IP}` },
  INTERNET: { txt: 'any' },
};

const SERVICIOS = {
  icmp: { proto: 'icmp' },
  tcp22: { proto: 'tcp', puerto: 22 },   tcp23: { proto: 'tcp', puerto: 23 },   tcp80: { proto: 'tcp', puerto: 80 },
  tcp443: { proto: 'tcp', puerto: 443 }, tcp515: { proto: 'tcp', puerto: 515 }, tcp631: { proto: 'tcp', puerto: 631 },
  tcp3389: { proto: 'tcp', puerto: 3389 }, tcp9100: { proto: 'tcp', puerto: 9100 },
  udp53: { proto: 'udp', puerto: 53 },   udp161: { proto: 'udp', puerto: 161 },
};

const WEB = ['tcp80', 'tcp443', 'udp53'];
/** [origen, destino, servicios, política que lo motiva] - TODO LO DEMÁS SE DENIEGA */
const FLUJOS = [
  ['X', 'SERVERS',  ['icmp', 'udp53', 'tcp443'], 'P5 (HTTP 80 prohibido; solo servicios necesarios)'],
  ['X', 'PRINTERS', ['icmp', 'tcp9100', 'tcp631', 'tcp515'], 'P3 (personal autorizado = Área X)'],
  ['X', 'R1B',      ['icmp'], 'P8 (Telnet prohibido; ICMP de control)'],
  ['X', 'INTERNET', WEB, 'navegación'],
  ['Y', 'MGMT_GW',  ['icmp'], 'P6/P7 (solo ICMP al gateway; prueba 8 del informe)'],
  ['Y', 'INTERNET', WEB, 'navegación'],
  ['MGMT', 'MGMT_GW',  ['icmp', 'tcp22', 'tcp443'], 'gestión del router'],
  ['MGMT', 'SERVERS',  ['icmp', 'tcp22', 'tcp443', 'udp161'], 'gestión'],
  ['MGMT', 'PRINTERS', ['icmp', 'tcp443', 'udp161'], 'gestión'],
  ['MGMT', 'R1B',      ['icmp', 'tcp22', 'udp161'], 'gestión SSH (reemplaza Telnet)'],
  ['MGMT', 'X',        ['icmp'], 'diagnóstico'],
  ['MGMT', 'Y',        ['icmp'], 'diagnóstico'],
  ['MGMT', 'INTERNET', WEB, 'actualizaciones'],
  ['SERVERS', 'INTERNET', WEB, 'actualizaciones'],
];

/** Equipos de prueba. attach = por dónde entra su tráfico a la red modelada. */
const adj = z => ({ router: 'Fortinet', iface: ZONAS[z].iface });
const HOSTS = {
  PC1:      { ip: '10.10.30.10', zona: 'X',        dest: 'X',        attach: adj('X') },
  PC7:      { ip: '10.10.40.11', zona: 'Y',        dest: 'Y',        attach: adj('Y') },
  Server3:  { ip: '10.10.10.20', zona: 'SERVERS',  dest: 'SERVERS',  attach: adj('SERVERS') },
  Printer6: { ip: '10.10.20.20', zona: 'PRINTERS', dest: 'PRINTERS', attach: adj('PRINTERS') },
  ADMIN:    { ip: '10.10.99.10', zona: 'MGMT',     dest: 'MGMT',     attach: adj('MGMT') },
  GW99:     { ip: '10.10.99.1',  zona: null,       dest: 'MGMT_GW',  owner: 'Fortinet', attach: adj('MGMT') },
  R1B:      { ip: R1B_IP,       zona: null,       dest: 'R1B',      owner: 'R1B', attach: { router: 'Fortinet', iface: 'G0/1' } },
  INTERNET: { ip: '203.0.113.10', zona: 'INTERNET', dest: 'INTERNET', attach: { router: 'Fortinet', iface: 'G0/0' } },
};

const permitidoPorMatriz = (origenZona, destKey, svc) =>
  FLUJOS.some(([o, d, s]) => o === origenZona && d === destKey && s.includes(svc));

module.exports = { ZONAS, DESTINOS, SERVICIOS, FLUJOS, HOSTS, FW_R1B_IP, R1B_IP, permitidoPorMatriz };
