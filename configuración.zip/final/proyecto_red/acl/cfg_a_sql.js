'use strict';
/**
 * Convierte un .cfg de IOS (ACL + aplicación a interfaces) en INSERT para las tablas acls/acl_reglas/acl_aplicaciones.
 * Uso: node cfg_a_sql.js <router> <version> <archivo.cfg> [mas.cfg ...]  > salida.sql
 * Los comandos "no ..." y los comentarios se ignoran (sirven solo para migrar el equipo).
 */
const fs = require('node:fs');
const [router, version, ...archivos] = process.argv.slice(2);
if (!router || !version || !archivos.length) { console.error('Uso: node cfg_a_sql.js <router> <version> <cfg...>'); process.exit(2); }
const POLITICA = { '10': 'P1', '11': 'P2', STD_GUEST_PRINTERS: 'P3', STD_BLOCK_GUEST_R1B: 'P4', '101': 'P5',
  '111': 'P6', EXT_USER_MGMT: 'P7', EXT_BLOCK_TELNET_R1B: 'P8' };
const q = s => `'${String(s).replace(/'/g, "''")}'`;

const acls = new Map();        // nombre -> {tipo, numerada, reglas:[]}
const apps = [];               // {acl, interfaz, sentido}
let nombrada = null, iface = null, m;
for (const crudo of archivos.map(f => fs.readFileSync(f, 'utf8')).join('\n').split(/\r?\n/)) {
  const l = crudo.trim();
  if (!l) continue;
  if (l.startsWith('!')) { nombrada = null; iface = null; continue; }
  if (l.startsWith('no ') || /remark /.test(l)) continue;
  if ((m = l.match(/^access-list (\d+) (permit|deny) (.+)$/))) {
    const n = Number(m[1]); const std = n < 100 || (n >= 1300 && n <= 1999);
    if (!acls.has(m[1])) acls.set(m[1], { tipo: std ? 'estandar' : 'extendida', numerada: true, reglas: [] });
    acls.get(m[1]).reglas.push([m[2], m[3]]); nombrada = null; continue;
  }
  if ((m = l.match(/^ip access-list (standard|extended) (\S+)$/))) {
    nombrada = m[2]; iface = null;
    acls.set(nombrada, { tipo: m[1] === 'standard' ? 'estandar' : 'extendida', numerada: false, reglas: [] }); continue;
  }
  if ((m = l.match(/^interface (\S+)$/))) { iface = m[1].replace(/^GigabitEthernet/, 'G'); nombrada = null; continue; }
  if ((m = l.match(/^ip access-group (\S+) (in|out)$/))) { if (iface && !apps.some(a => a.acl === m[1] && a.interfaz === iface && a.sentido === m[2])) apps.push({ acl: m[1], interfaz: iface, sentido: m[2] }); continue; }
  if (nombrada && (m = l.match(/^(permit|deny) (.+)$/))) { acls.get(nombrada).reglas.push([m[1], m[2]]); continue; }
}
const R = `(SELECT id_dispositivo FROM infra.dispositivos WHERE nombre = ${q(router)})`;
const out = [`-- Generado por cfg_a_sql.js (router ${router}, ${version})`, 'BEGIN;', 'SET LOCAL search_path = infra, extensions;'];
out.push(`DELETE FROM infra.acls WHERE id_router = ${R} AND version = ${q(version)};   -- reemplaza las ACL previas de este router y versión (borra sus reglas y aplicaciones)`);
for (const [nombre, a] of acls) {
  const pol = POLITICA[nombre] && (version === 'v1_informe' || nombre === 'EXT_BLOCK_TELNET_R1B') ? `(SELECT id_politica FROM infra.politicas_seguridad WHERE codigo = ${q(POLITICA[nombre])})` : 'NULL';
  out.push(`INSERT INTO infra.acls (id_router, nombre, tipo, numerada, version, id_politica) VALUES (${R}, ${q(nombre)}, ${q(a.tipo)}, ${a.numerada}, ${q(version)}, ${pol}) ON CONFLICT DO NOTHING;`);
  a.reglas.forEach(([acc, cond], i) => out.push(
    `INSERT INTO infra.acl_reglas (id_acl, secuencia, accion, condicion) SELECT id_acl, ${(i + 1) * 10}, ${q(acc)}, ${q(cond)} FROM infra.acls WHERE id_router = ${R} AND nombre = ${q(nombre)} AND version = ${q(version)} ON CONFLICT DO NOTHING;`));
}
for (const a of apps) out.push(
  `INSERT INTO infra.acl_aplicaciones (id_acl, interfaz, sentido) SELECT id_acl, ${q(a.interfaz)}, ${q(a.sentido)} FROM infra.acls WHERE id_router = ${R} AND nombre = ${q(a.acl)} AND version = ${q(version)} ON CONFLICT DO NOTHING;`);
out.push('COMMIT;');
console.log(out.join('\n'));
