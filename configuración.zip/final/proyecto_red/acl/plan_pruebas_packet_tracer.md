# Plan de pruebas en Packet Tracer

Resultado esperado según el simulador (probar_acls.js). Ejecútalo en PT y anota "obtenido". En PT las IP de PC1 y PC7 pueden variar (DHCP): ajusta el destino.

| # | Desde | Comando en PT | v1 (informe) | v2 (por defecto) | Motivo |
|---|---|---|---|---|---|
| 1 | PC1 | ping 10.10.10.20 | permitido | permitido | Tabla 16 #1 |
| 2 | PC7 | ping 10.10.10.20 | bloqueado | bloqueado | Tabla 16 #2 |
| 3 | PC7 | ping 10.10.20.20 | bloqueado | bloqueado | Tabla 16 #3 |
| 4 | PC1 | ping 10.10.40.11 | bloqueado | bloqueado | Tabla 16 #4 |
| 5 | PC7 | ping 10.0.1.2 | bloqueado | bloqueado | Tabla 16 #5 |
| 6 | PC1 | ping 10.0.1.2 | permitido | permitido | Tabla 16 #6 |
| 7 | PC1 | ping 10.10.99.10 | bloqueado | bloqueado | Tabla 16 #7 |
| 8 | PC7 | ping 10.10.99.1 | permitido | permitido | Tabla 16 #8 |
| 9 | PC1 | Web Browser: http://10.10.10.20 | bloqueado | bloqueado | Tabla 16 #9 |
| 10 | PC7 | Web Browser: https://10.10.99.10 | bloqueado | bloqueado | Tabla 16 #10 |
| 11 | PC1 | telnet 10.0.1.2 | bloqueado | bloqueado | Tabla 16 #11 |
| 12 | PC7 | ping 10.10.30.10 | unidireccional | bloqueado | Hallazgo: P2 en sentido Y→X |
| 13 | PC1 | ping 10.10.99.1 | permitido | bloqueado | Hallazgo: P7 hacia el gateway |
| 14 | PC1 | telnet 10.10.99.1 | permitido | bloqueado | Hallazgo: P7 hacia el gateway |
| 15 | PC7 | ssh -l admin 10.10.99.10 | permitido | bloqueado | Hallazgo: P6 solo cierra 443 |
| 16 | PC1 | Web Browser: https://10.10.10.20 | permitido | permitido | Servicio necesario |
| 17 | ADMIN | ssh -l admin 10.0.1.2 | permitido | permitido | Gestión SSH |
| 18 | ADMIN | ping 10.10.30.10 | unidireccional | permitido | Diagnóstico desde VLAN 99 |

**Cómo leerlo:** "unidireccional" = la petición llega pero la respuesta se descarta (en PT el ping falla igual que si estuviera bloqueado; confírmalo con `show access-lists` mirando los contadores `matches`).

**Antes de aplicar la v2 en PT:** `copy running-config startup-config` en R1 y R1B (respaldo), aplica desde la consola, prueba DHCP (`ipconfig /renew` en PC1 y PC7) y recién entonces las demás.
