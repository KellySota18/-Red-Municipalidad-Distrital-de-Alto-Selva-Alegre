'use strict';
/**
 * Simulador mínimo de ACL de Cisco IOS (sin dependencias).
 * Reproduce las reglas que importan para la práctica:
 *  - evaluación de arriba hacia abajo, primera coincidencia, deny implícito al final;
 *  - ACL estándar (origen) y extendida (protocolo, origen, destino, puertos, established, tipo ICMP);
 *  - una ACL por interfaz y sentido (in/out);
 *  - el tráfico generado por el propio router NO se filtra con ACL de salida;
 *  - ACL sin estado: la respuesta también se evalúa (por eso se prueba ida Y vuelta).
 * Límites: no simula NAT, ARP, STP, ni estados reales de TCP (solo el bit ACK para "established").
 */

/* ---------- direcciones ---------- */
const ip2n = ip => ip.split('.').reduce((a, o) => a * 256 + Number(o), 0);
const wildMatch = (ip, net, wild) => ((((ip2n(ip) ^ ip2n(net)) & ~ip2n(wild))) >>> 0) === 0;
const inPrefix = (ip, base, prefix) => {
  const mask = prefix === 0 ? 0 : (~0 << (32 - prefix)) >>> 0;
  return ((ip2n(ip) & mask) >>> 0) === ((ip2n(base) & mask) >>> 0);
};

/* ---------- parser de ACL ---------- */
const PUERTOS = { telnet: 23, www: 80, ftp: 21, 'ftp-data': 20, smtp: 25, domain: 53, pop3: 110,
  https: 443, ssh: 22, snmp: 161, bootps: 67, bootpc: 68, isakmp: 500 };
const puerto = p => (PUERTOS[p] !== undefined ? PUERTOS[p] : Number(p));
const IPRE = /^\d+\.\d+\.\d+\.\d+$/;

function parseDir(t) {
  const x = t.shift();
  if (x === 'any') return { net: '0.0.0.0', wild: '255.255.255.255' };
  if (x === 'host') return { net: t.shift(), wild: '0.0.0.0' };
  if (t.length && IPRE.test(t[0])) return { net: x, wild: t.shift() };
  return { net: x, wild: '0.0.0.0' };
}
function parsePuerto(t) {
  if (t.length && ['eq', 'neq', 'lt', 'gt', 'range'].includes(t[0])) {
    const op = t.shift(); const a = puerto(t.shift());
    return { op, a, b: op === 'range' ? puerto(t.shift()) : null };
  }
  return null;
}
const pmatch = (pm, p) => !pm || (pm.op === 'eq' ? p === pm.a : pm.op === 'neq' ? p !== pm.a
  : pm.op === 'lt' ? p < pm.a : pm.op === 'gt' ? p > pm.a : p >= pm.a && p <= pm.b);

function parseStd(accion, resto, texto) {
  const t = resto.split(/\s+/).filter(Boolean);
  const src = parseDir(t);
  return { accion, src, texto };
}
function parseExt(accion, resto, texto) {
  const t = resto.split(/\s+/).filter(Boolean);
  const proto = t.shift();
  const l4 = proto === 'tcp' || proto === 'udp';
  const src = parseDir(t); const sp = l4 ? parsePuerto(t) : null;
  const dst = parseDir(t); const dp = l4 ? parsePuerto(t) : null;
  let established = false, icmp = null, log = false;
  while (t.length) {
    const x = t.shift();
    if (x === 'established') established = true;
    else if (x === 'log' || x === 'log-input') log = true;
    else if (proto === 'icmp') icmp = x;
    else throw new Error(`Token no soportado "${x}" en: ${texto}`);
  }
  return { accion, proto, src, sp, dst, dp, established, icmp, log, texto };
}

function coincide(regla, tipo, p) {
  if (!wildMatch(p.src, regla.src.net, regla.src.wild)) return false;
  if (tipo === 'std') return true;
  if (regla.proto !== 'ip' && regla.proto !== p.proto) return false;
  if (!wildMatch(p.dst, regla.dst.net, regla.dst.wild)) return false;
  if (p.proto === 'tcp' || p.proto === 'udp') {
    if (!pmatch(regla.sp, p.sport) || !pmatch(regla.dp, p.dport)) return false;
  }
  if (regla.established && !(p.proto === 'tcp' && p.ack)) return false;
  if (regla.icmp && p.icmp !== regla.icmp) return false;
  return true;
}

const normIf = n => n.replace(/^GigabitEthernet/, 'G').replace(/^FastEthernet/, 'F');

/** Aplica texto de configuración sobre el estado del router (admite comandos "no ..."). */
function aplicarConfig(estado, texto) {
  const { acls, apps } = estado;
  let nombrada = null, tipoN = null, iface = null, m;
  for (const crudo of texto.split(/\r?\n/)) {
    const l = crudo.trim();
    if (!l) continue;
    if (l.startsWith('!')) { nombrada = null; iface = null; continue; }
    if ((m = l.match(/^no access-list (\d+)$/))) { delete acls[m[1]]; continue; }
    if ((m = l.match(/^no ip access-list (standard|extended) (\S+)$/))) { delete acls[m[2]]; continue; }
    if ((m = l.match(/^no ip access-group (\S+) (in|out)$/))) { if (apps[iface]) delete apps[iface][m[2]]; continue; }
    if ((m = l.match(/^access-list (\d+) remark/))) continue;
    if ((m = l.match(/^access-list (\d+) (permit|deny) (.+)$/))) {
      const n = Number(m[1]); const tipo = (n < 100 || (n >= 1300 && n <= 1999)) ? 'std' : 'ext';
      (acls[m[1]] ??= { tipo, reglas: [] }).reglas.push(
        tipo === 'std' ? parseStd(m[2], m[3], l) : parseExt(m[2], m[3], l));
      nombrada = null; continue;
    }
    if ((m = l.match(/^ip access-list (standard|extended) (\S+)$/))) {
      nombrada = m[2]; tipoN = m[1] === 'standard' ? 'std' : 'ext';
      acls[nombrada] ??= { tipo: tipoN, reglas: [] }; iface = null; continue;
    }
    if ((m = l.match(/^interface (\S+)$/))) { iface = normIf(m[1]); nombrada = null; continue; }
    if ((m = l.match(/^ip access-group (\S+) (in|out)$/))) {
      if (!iface) throw new Error('ip access-group fuera de una interfaz: ' + l);
      (apps[iface] ??= {})[m[2]] = m[1]; continue;
    }
    if (nombrada && /^remark /.test(l)) continue;
    if (nombrada && (m = l.match(/^(permit|deny) (.+)$/))) {
      acls[nombrada].reglas.push(tipoN === 'std' ? parseStd(m[1], m[2], l) : parseExt(m[1], m[2], l));
      continue;
    }
    // Cualquier otro comando de IOS se ignora.
  }
}

/* ---------- router y red ---------- */
class Router {
  constructor(nombre, interfaces, { defecto = null } = {}) {
    this.nombre = nombre; this.defecto = defecto;
    this.ifaces = Object.entries(interfaces).map(([n, cidr]) => {
      const [ip, pre] = cidr.split('/'); return { nombre: n, ip, prefijo: Number(pre) };
    });
    this.propias = new Set([...this.ifaces.map(i => i.ip), '255.255.255.255', '224.0.0.2']);
    this.estado = { acls: {}, apps: {} };
    this.aciertos = {};                                   // contadores tipo "show access-lists"
  }
  config(texto) { aplicarConfig(this.estado, texto); return this; }
  ruta(dst) {
    let mejor = null;
    for (const i of this.ifaces) if (inPrefix(dst, i.ip, i.prefijo) && (!mejor || i.prefijo > mejor.prefijo)) mejor = i;
    return mejor ? mejor.nombre : this.defecto;
  }
  evaluar(nombre, p) {
    const acl = this.estado.acls[nombre];
    if (!acl) return { accion: 'permit', texto: `(ACL ${nombre} inexistente: sin filtro)` };
    for (let i = 0; i < acl.reglas.length; i++) {
      if (coincide(acl.reglas[i], acl.tipo, p)) {
        const k = `${nombre}#${i}`; this.aciertos[k] = (this.aciertos[k] || 0) + 1;
        return { accion: acl.reglas[i].accion, texto: acl.reglas[i].texto, indice: i };
      }
    }
    return { accion: 'deny', texto: '(deny implícito)', implicito: true };
  }
}

class Red {
  constructor() { this.routers = {}; this.enlaces = {}; }
  agregar(r) { this.routers[r.nombre] = r; return this; }
  unir(r1, i1, r2, i2) { this.enlaces[`${r1}:${i1}`] = { router: r2, iface: i2 }; this.enlaces[`${r2}:${i2}`] = { router: r1, iface: i1 }; return this; }

  /** Recorre la red con un paquete que entra a (router, iface). */
  recorrer(p, rn, ingreso, traza = [], saltos = 0) {
    const r = this.routers[rn];
    const entrada = r.estado.apps[ingreso]?.in;
    if (entrada) {
      const v = r.evaluar(entrada, p);
      traza.push(`${rn} ${ingreso} in  ${entrada}: ${v.accion} [${v.texto}]`);
      if (v.accion === 'deny') return { entregado: false, router: rn, iface: ingreso, sentido: 'in', acl: entrada, regla: v.texto, traza };
    }
    if (r.propias.has(p.dst)) return { entregado: true, haciaRouter: rn, traza };
    const salida = r.ruta(p.dst);
    if (!salida) return { entregado: true, traza };
    const sal = r.estado.apps[salida]?.out;
    if (sal) {
      const v = r.evaluar(sal, p);
      traza.push(`${rn} ${salida} out ${sal}: ${v.accion} [${v.texto}]`);
      if (v.accion === 'deny') return { entregado: false, router: rn, iface: salida, sentido: 'out', acl: sal, regla: v.texto, traza };
    }
    const par = this.enlaces[`${rn}:${salida}`];
    if (par && saltos < 6 && par.iface !== ingreso) return this.recorrer(p, par.router, par.iface, traza, saltos + 1);
    return { entregado: true, traza };
  }

  /**
   * Prueba un flujo completo (ida y vuelta).
   *  'permitido'      : la petición llega y la respuesta regresa
   *  'bloqueado'      : la petición es descartada
   *  'unidireccional' : la petición llega pero la respuesta es descartada (ACL sin estado)
   */
  flujo(origen, destino, svc) {
    const sp = 40000 + (svc.puerto || 0) % 1000;
    const idaP = { proto: svc.proto, src: origen.ip, dst: destino.ip, sport: svc.proto === 'icmp' ? null : sp,
      dport: svc.puerto || null, ack: false, icmp: svc.proto === 'icmp' ? 'echo' : null };
    const ida = this.recorrer(idaP, origen.attach.router, origen.attach.iface);
    if (!ida.entregado) return { veredicto: 'bloqueado', ida, vuelta: null };
    // Si el destino es el propio router de entrada, la respuesta la genera el router: no se filtra con ACL de salida.
    if (destino.owner && destino.owner === origen.attach.router) return { veredicto: 'permitido', ida, vuelta: null };
    const vueP = { proto: svc.proto, src: destino.ip, dst: origen.ip, sport: svc.puerto || null,
      dport: svc.proto === 'icmp' ? null : sp, ack: true, icmp: svc.proto === 'icmp' ? 'echo-reply' : null };
    const vuelta = this.recorrer(vueP, destino.attach.router, destino.attach.iface);
    return { veredicto: vuelta.entregado ? 'permitido' : 'unidireccional', ida, vuelta };
  }
}

module.exports = { Router, Red, aplicarConfig };
