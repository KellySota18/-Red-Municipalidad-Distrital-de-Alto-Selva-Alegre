'use strict';
/**
 * Genera, a partir de la matriz de políticas, la configuración IOS con DENEGACIÓN POR DEFECTO:
 *   node generar_config.js        -> config/R1_v2_migracion.cfg  y  config/R1B_v2_migracion.cfg
 * Estrategia:
 *  - ACL extendida nombrada en SENTIDO IN en cada subinterfaz y en los enlaces externos (se filtra en el origen).
 *  - Cada lista: permit explícitos -> respuestas de los flujos autorizados -> "deny ip any any log".
 *  - Las respuestas (la ACL no tiene estado) se limitan a las redes que pueden iniciar el flujo.
 */
const fs = require('node:fs');
const path = require('node:path');
const { ZONAS, DESTINOS, SERVICIOS, FLUJOS, FW_R1B_IP, R1B_IP } = require('./politicas');

const nets = k => (k === 'INTERNET' ? 'any' : DESTINOS[k].txt);
const zonaNet = z => `${ZONAS[z].red} ${ZONAS[z].wild}`;
const L = [];
const w = (...x) => L.push(x.join(' '));

/** Regla de PETICIÓN origen->destino para un servicio. */
function peticion(srcTxt, dstTxt, svcKey) {
  const s = SERVICIOS[svcKey];
  if (s.proto === 'icmp') return `permit icmp ${srcTxt} ${dstTxt} echo`;
  return `permit ${s.proto} ${srcTxt} ${dstTxt} eq ${s.puerto}`;
}
/** Regla de RESPUESTA (viene del destino hacia el origen que inició). */
function respuesta(dstTxt, srcTxt, svcKey) {
  const s = SERVICIOS[svcKey];
  if (s.proto === 'icmp') return `permit icmp ${dstTxt} ${srcTxt} echo-reply`;
  if (s.proto === 'tcp') return `permit tcp ${dstTxt} eq ${s.puerto} ${srcTxt} established`;
  return `permit udp ${dstTxt} eq ${s.puerto} ${srcTxt}`;
}

/* ---------------- Fortinet (R1) ---------------- */
w('! ============================================================================');
w('! R1 (Fortinet) - PERÍMETRO CON DENEGACIÓN POR DEFECTO  (generado por generar_config.js)');
w('! Reemplaza las ACL del informe. Aplicar DESDE CONSOLA (no por red) y guardar solo tras probar.');
w('! Suposiciones: G0/1 = 10.0.1.1/30 hacia R1B; G0/0 = enlace al ISP. Confirmar antes de aplicar.');
w('! ============================================================================');
w('! 1) Quitar las ACL del informe de las interfaces');
const viejas = { 'GigabitEthernet0/2.10': ['10 out'], 'GigabitEthernet0/2.20': ['STD_GUEST_PRINTERS out'],
  'GigabitEthernet0/2.30': ['101 in'], 'GigabitEthernet0/2.40': ['111 in', '11 out'],
  'GigabitEthernet0/2.99': ['EXT_USER_MGMT out'], 'GigabitEthernet0/1': ['STD_BLOCK_GUEST_R1B out'] };
for (const [i, a] of Object.entries(viejas)) { w(`interface ${i}`); a.forEach(x => w(` no ip access-group ${x}`)); }
w('exit');
w('! 2) Borrar las ACL antiguas');
['10', '11', '101', '111'].forEach(n => w(`no access-list ${n}`));
['standard STD_GUEST_PRINTERS', 'standard STD_BLOCK_GUEST_R1B', 'extended EXT_USER_MGMT'].forEach(n => w(`no ip access-list ${n}`));
w('!');
w('! 3) Crear las ACL por zona de origen');

for (const [zk, z] of Object.entries(ZONAS)) {
  const origen = zonaNet(zk);
  w(`ip access-list extended ${z.acl}`);
  w(` remark ${z.nombre} - entrada. Todo lo no listado se deniega`);
  w(` permit udp host 0.0.0.0 eq 68 host 255.255.255.255 eq 67`);     // DHCP DISCOVER/REQUEST
  w(` permit udp ${origen} eq 68 host ${z.gw} eq 67`);                  // DHCP renovación
  const sale = FLUJOS.filter(([o]) => o === zk);
  for (const [, d, svcs] of sale.filter(f => f[1] !== 'INTERNET')) for (const s of svcs) w(' ' + peticion(origen, nets(d), s));
  // Respuestas a flujos que otras zonas inician hacia esta
  for (const [o, d, svcs] of FLUJOS.filter(f => f[1] === zk)) for (const s of svcs) w(' ' + respuesta(origen, zonaNet(o), s));
  const web = sale.filter(f => f[1] === 'INTERNET');
  if (web.length) {
    w(' remark Internet: antes se prohíbe todo destino privado (no se salta la matriz)');
    w(` deny ip any 10.0.0.0 0.255.255.255`);
    w(` deny ip any 172.16.0.0 0.15.255.255`);
    w(` deny ip any 192.168.0.0 0.0.255.255`);
    for (const [, , svcs] of web) for (const s of svcs) w(' ' + peticion(origen, 'any', s));
  }
  w(` deny ip any any log`);
}

w('ip access-list extended FW_IN_R1B_LINK');
w(` remark Enlace hacia R1B - entrada`);
w(` permit udp host ${R1B_IP} eq 1985 host 224.0.0.2 eq 1985`);        // HSRP (solo si se usa)
for (const [o, d, svcs] of FLUJOS.filter(f => f[1] === 'R1B')) for (const s of svcs) w(' ' + respuesta(`host ${R1B_IP}`, zonaNet(o), s));
w(` deny ip any any log`);

w('ip access-list extended FW_IN_PERIMETRO');
w(` remark ISP - entrada. Solo respuestas a conexiones iniciadas desde dentro`);
w(` deny ip 10.0.0.0 0.255.255.255 any log`);
w(` deny ip 172.16.0.0 0.15.255.255 any log`);
w(` deny ip 192.168.0.0 0.0.255.255 any log`);
w(` deny ip 127.0.0.0 0.255.255.255 any log`);
for (const [o, , svcs] of FLUJOS.filter(f => f[1] === 'INTERNET')) for (const s of svcs) w(' ' + respuesta('any', zonaNet(o), s));
w(` permit icmp any any unreachable`);
w(` permit icmp any any time-exceeded`);
w(` deny ip any any log`);

w('! 4) Aplicar (al final, para no cortar la sesión antes de tiempo)');
for (const z of Object.values(ZONAS)) { w(`interface ${z.iface.replace('G', 'GigabitEthernet')}`); w(` ip access-group ${z.acl} in`); }
w('interface GigabitEthernet0/1'); w(' ip access-group FW_IN_R1B_LINK in');
w('interface GigabitEthernet0/0'); w(' ip access-group FW_IN_PERIMETRO in');
w('exit');
w('!');
w('! 5) PAT para la salida a Internet (opcional; el simulador de ACL no lo prueba. Descomentar y revisar interfaces)');
w('! access-list 1 permit 10.10.0.0 0.0.255.255');
w('! interface GigabitEthernet0/2.10 ... GigabitEthernet0/2.99 / ip nat inside');
w('! interface GigabitEthernet0/0 / ip nat outside');
w('! ip nat inside source list 1 interface GigabitEthernet0/0 overload');
w('! 6) Verificación: show access-lists | show ip interface GigabitEthernet0/2.30 | show ip nat translations');
fs.writeFileSync(path.join(__dirname, 'config/R1_v2_migracion.cfg'), L.join('\n') + '\n');

/* ---------------- R1B ---------------- */
L.length = 0;
w('! ============================================================================');
w('! R1B - ACL de entrada con denegación por defecto (generado por generar_config.js)');
w('! Mantiene el nombre EXT_BLOCK_TELNET_R1B (P8). Telnet se prohíbe para TODOS; la gestión pasa a SSH.');
w('! ============================================================================');
w('no ip access-list extended EXT_BLOCK_TELNET_R1B');
w('ip access-list extended EXT_BLOCK_TELNET_R1B');
w(' remark P8 - Telnet prohibido; solo ICMP de usuarios y gestion SSH/SNMP desde VLAN 99');
w(' deny tcp any any eq telnet log');
for (const [o, , svcs] of FLUJOS.filter(f => f[1] === 'R1B'))
  for (const s of svcs) w(' ' + peticion(zonaNet(o), `host ${R1B_IP}`, s));
w(` permit udp host ${FW_R1B_IP} eq 1985 host 224.0.0.2 eq 1985`);
w(' deny ip any any log');
w('interface GigabitEthernet0/0');
w(' ip access-group EXT_BLOCK_TELNET_R1B in');
w('exit');
w('! Gestión remota: solo SSH desde la VLAN 99 (access-class en las líneas vty)');
w('! access-list 99 permit 10.10.99.0 0.0.0.255');
w('! line vty 0 4 / access-class 99 in / transport input ssh');
fs.writeFileSync(path.join(__dirname, 'config/R1B_v2_migracion.cfg'), L.join('\n') + '\n');
console.log('Generado: config/R1_v2_migracion.cfg y config/R1B_v2_migracion.cfg');
