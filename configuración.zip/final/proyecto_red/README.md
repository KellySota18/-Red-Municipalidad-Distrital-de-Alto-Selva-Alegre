# proyecto_red

Base de datos, API, ACL y copias de seguridad para la red de la Municipalidad Distrital de Alto Selva Alegre
(Diario de Ingeniería y práctica de ACL y NAT, Computación en Red II).

**Empieza por `MANUAL_IMPLEMENTACION.md`.** Resumen: PostgreSQL 16 + Node 20 en Windows; instalar la base
(sección 3), levantar la API (4), correr `node acl\probar_acls.js` (5) y aplicar la v2 en Packet Tracer (6).

Más detalle: `docs/guia_seguridad.md` (seguridad y hallazgos) y `acl/LEEME_ACL.md` (simulador de ACL).
