/* =====================================================================
   seed_acl_informe.sql
   Datos de la "Práctica Calificada - ACL y NAT" (Computación en Red II):
   routers, políticas P1-P8 y las 11 pruebas de la Tabla 16.
   Las ACL y sus reglas se cargan con cfg_a_sql.js (ver LEEME).
   Ejecutar tras infra_red_acl_extension.sql, como postgres. Re-ejecutable.
   ===================================================================== */
BEGIN;
SET LOCAL search_path = infra, extensions;

INSERT INTO dispositivos (nombre, tipo, marca, modelo, estado, observaciones) VALUES
  ('R1-FORTINET', 'router', 'Cisco', '2911 (Packet Tracer)', 'propuesto',
   'Router "Fortinet (R1)" de la simulacion: gateway y DHCP de todas las VLAN (router-on-a-stick). Aloja 7 de las 8 ACL.'),
  ('R1B', 'router', 'Cisco', '2911 (Packet Tracer)', 'propuesto',
   'Router secundario de interconexion (10.0.1.2). Aloja EXT_BLOCK_TELNET_R1B.')
ON CONFLICT DO NOTHING;

INSERT INTO politicas_seguridad (codigo, descripcion) VALUES
  ('P1', 'El Area Y (VLAN 40) no debe tener acceso a la red de servidores (VLAN 10).'),
  ('P2', 'Las areas de usuarios (Area X y Area Y) no deben comunicarse entre si.'),
  ('P3', 'Las impresoras (VLAN 20) solo las usa el personal autorizado; el Area Y no debe acceder.'),
  ('P4', 'El Area Y no debe alcanzar el router secundario R1B ni los segmentos que dependen de el.'),
  ('P5', 'Los usuarios del Area X no deben acceder por HTTP a los servidores; solo servicios necesarios.'),
  ('P6', 'El acceso web seguro (HTTPS) a la red de administracion (VLAN 99) esta restringido para el Area Y.'),
  ('P7', 'Los equipos del Area X no deben tener ningun acceso a la red de administracion.'),
  ('P8', 'La gestion remota de R1B por Telnet (sin cifrado) no debe estar disponible para el Area X.')
ON CONFLICT DO NOTHING;

-- Pruebas de la Tabla 16 tal como las reporta el informe (Packet Tracer). Origen/destino abreviados.
INSERT INTO pruebas_conectividad (version, n_tabla16, origen, destino, servicio, resultado_esperado, resultado_obtenido, fuente)
SELECT 'v1_informe', v.n, v.o, v.d, v.s, v.r::veredicto, v.r::veredicto, 'packet_tracer'
  FROM (VALUES
    (1,  'PC1',    'Server3',  'icmp',   'permitido'),
    (2,  'PC7',    'Server3',  'icmp',   'bloqueado'),
    (3,  'PC7',    'Printer6', 'icmp',   'bloqueado'),
    (4,  'PC1',    'PC7',      'icmp',   'bloqueado'),
    (5,  'PC7',    'R1B',      'icmp',   'bloqueado'),
    (6,  'PC1',    'R1B',      'icmp',   'permitido'),
    (7,  'PC1',    'Host99',   'icmp',   'bloqueado'),
    (8,  'PC7',    'GW99',     'icmp',   'permitido'),
    (9,  'VLAN30', 'VLAN10',   'tcp80',  'bloqueado'),
    (10, 'VLAN40', 'VLAN99',   'tcp443', 'bloqueado'),
    (11, 'VLAN30', 'R1B',      'tcp23',  'bloqueado')
  ) AS v(n, o, d, s, r)
 WHERE NOT EXISTS (SELECT 1 FROM pruebas_conectividad p WHERE p.n_tabla16 = v.n AND p.fuente = 'packet_tracer');
COMMIT;
