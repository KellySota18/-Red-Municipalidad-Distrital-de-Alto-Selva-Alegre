/* =====================================================================
   infra_red_schema_seguro.sql
   Base de datos PostgreSQL (>= 13) para documentar y gestionar la red de la
   Municipalidad Distrital de Alto Selva Alegre (Diario de Ingeniería,
   Computación en Red II): sedes, VLANs, subredes, dispositivos, interfaces,
   enlaces y mantenimientos.

   Adaptación de las tablas pedidas:
     Usuarios  -> usuarios       (técnicos y administradores de red)
     Productos -> dispositivos   (switches, routers, servidores, firewall...)
     Pedidos   -> mantenimientos (órdenes de mantenimiento por dispositivo)

   Cómo ejecutarlo: pgAdmin 4 > Query Tool, conectado a una BD vacía
   (ej. "infra_red_db"), con un superusuario (postgres). Es idempotente.
   Después, ejecuta seed_datos_municipalidad.sql para cargar los datos del informe.

   SEGURIDAD EN BD: CHECK/tipos fuertes, consultas parametrizadas en funciones,
   bcrypt + bloqueo por intentos, sesiones con hash SHA-256, roles de mínimo
   privilegio, Row Level Security por rol de aplicación, rate limit, auditoría
   inmutable que registra QUIÉN hizo cada cambio, y cero secretos en el script.
   El resto de controles (XSS, CSRF, CORS, SO, backups) está en guia_seguridad.md.
   ===================================================================== */

BEGIN;

/* ---- 0. EXTENSIONES Y ESQUEMAS ------------------------------------- */
CREATE SCHEMA IF NOT EXISTS extensions;
CREATE EXTENSION IF NOT EXISTS pgcrypto   SCHEMA extensions;  -- bcrypt, SHA-256, aleatorios
CREATE EXTENSION IF NOT EXISTS citext     SCHEMA extensions;  -- email sin distinguir mayúsculas
CREATE EXTENSION IF NOT EXISTS btree_gist SCHEMA extensions;  -- evita subredes solapadas
CREATE SCHEMA IF NOT EXISTS infra;
SET LOCAL search_path = infra, extensions;

/* ---- 1. ROLES DE BD (mínimo privilegio) ---------------------------- */
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'rol_app') THEN
        CREATE ROLE rol_app NOLOGIN;      -- backend/API
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'rol_lectura') THEN
        CREATE ROLE rol_lectura NOLOGIN;  -- reportes: solo lectura del inventario
    END IF;
END
$$;

DO $$
BEGIN
    EXECUTE format('REVOKE ALL ON DATABASE %I FROM PUBLIC', current_database());
    EXECUTE format('GRANT CONNECT ON DATABASE %I TO rol_app, rol_lectura', current_database());
END
$$;

REVOKE ALL ON SCHEMA public     FROM PUBLIC;
REVOKE ALL ON SCHEMA extensions FROM PUBLIC;
REVOKE ALL ON SCHEMA infra      FROM PUBLIC;
GRANT USAGE ON SCHEMA extensions TO rol_app, rol_lectura;
GRANT USAGE ON SCHEMA infra      TO rol_app, rol_lectura;
ALTER DEFAULT PRIVILEGES IN SCHEMA infra REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;

/* ---- 2. TIPOS ENUMERADOS ------------------------------------------- */
DO $$
DECLARE t record;
BEGIN
    FOR t IN SELECT * FROM (VALUES
        ('rol_usuario',        ARRAY['administrador','tecnico','consulta']),
        ('tipo_dispositivo',   ARRAY['firewall','router','switch','access_point','servidor',
                                     'ups','onu','radioenlace','modem','otro']),
        ('estado_dispositivo', ARRAY['operativo','en_mantenimiento','averiado','retirado','propuesto']),
        ('estado_diseno',      ARRAY['actual','propuesto']),
        ('asignacion_ip',      ARRAY['estatica','dhcp']),
        ('tipo_medio',         ARRAY['utp','ftp','stp','fibra_optica','coaxial','radioenlace']),
        ('tipo_mantenimiento', ARRAY['preventivo','correctivo','inspeccion']),
        ('estado_mantenimiento', ARRAY['programado','en_curso','completado','cancelado'])
    ) AS v(nombre, valores)
    LOOP
        IF NOT EXISTS (SELECT 1 FROM pg_type ty JOIN pg_namespace n ON n.oid = ty.typnamespace
                       WHERE n.nspname = 'infra' AND ty.typname = t.nombre) THEN
            EXECUTE format('CREATE TYPE infra.%I AS ENUM (%s)', t.nombre,
                           (SELECT string_agg(quote_literal(x), ',') FROM unnest(t.valores) x));
        END IF;
    END LOOP;
END
$$;

/* ---- 3. TABLAS PRINCIPALES ----------------------------------------- */

-- 3.1 USUARIOS (personal autorizado). Contraseña solo como hash bcrypt.
CREATE TABLE IF NOT EXISTS infra.usuarios (
    id_usuario        uuid          PRIMARY KEY DEFAULT gen_random_uuid(),
    nombre            varchar(100)  NOT NULL,
    email             citext        NOT NULL,
    contrasena_hash   text          NOT NULL,
    rol               infra.rol_usuario NOT NULL DEFAULT 'consulta',
    activo            boolean       NOT NULL DEFAULT true,
    intentos_fallidos smallint      NOT NULL DEFAULT 0,
    bloqueado_hasta   timestamptz,
    fecha_registro    timestamptz   NOT NULL DEFAULT now(),
    CONSTRAINT uq_usuarios_email UNIQUE (email),
    CONSTRAINT ck_usuarios_nombre CHECK (char_length(btrim(nombre)) BETWEEN 2 AND 100
                                         AND nombre !~ '[[:cntrl:]<>]'),
    CONSTRAINT ck_usuarios_email CHECK (char_length(email::text) <= 254
        AND email::text ~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
    CONSTRAINT ck_usuarios_hash_bcrypt CHECK (contrasena_hash ~ '^\$2[abxy]\$[0-9]{2}\$.{53}$'),
    CONSTRAINT ck_usuarios_intentos CHECK (intentos_fallidos BETWEEN 0 AND 100)
);

-- 3.2 UBICACIONES (sede / piso / ambiente)
CREATE TABLE IF NOT EXISTS infra.ubicaciones (
    id_ubicacion uuid         PRIMARY KEY DEFAULT gen_random_uuid(),
    sede         varchar(100) NOT NULL,
    piso         smallint,
    ambiente     varchar(100) NOT NULL,
    CONSTRAINT ck_ubicaciones_piso   CHECK (piso IS NULL OR piso BETWEEN -3 AND 30),
    CONSTRAINT ck_ubicaciones_texto  CHECK (sede !~ '[[:cntrl:]<>]' AND ambiente !~ '[[:cntrl:]<>]'
                                            AND char_length(btrim(sede)) >= 2 AND char_length(btrim(ambiente)) >= 2)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_ubicaciones ON infra.ubicaciones (sede, COALESCE(piso, -99), ambiente);

-- 3.3 VLANS (la red actual es plana; el diseño TO-BE propone VLANs)
CREATE TABLE IF NOT EXISTS infra.vlans (
    id_vlan       uuid         PRIMARY KEY DEFAULT gen_random_uuid(),
    numero        smallint     NOT NULL,
    nombre        varchar(40)  NOT NULL,
    funcion       varchar(150) NOT NULL,
    estado_diseno infra.estado_diseno NOT NULL DEFAULT 'actual',
    CONSTRAINT ck_vlans_numero CHECK (numero BETWEEN 1 AND 4094),
    CONSTRAINT ck_vlans_nombre CHECK (nombre ~ '^[A-Za-z0-9_-]{2,40}$'),
    CONSTRAINT uq_vlans_numero UNIQUE (numero, estado_diseno),
    CONSTRAINT uq_vlans_nombre UNIQUE (nombre, estado_diseno)
);

-- 3.4 SUBREDES (IPv4/IPv6). Sin solapamientos dentro del mismo diseño.
CREATE TABLE IF NOT EXISTS infra.subredes (
    id_subred     uuid         PRIMARY KEY DEFAULT gen_random_uuid(),
    red           cidr         NOT NULL,
    id_vlan       uuid         REFERENCES infra.vlans (id_vlan) ON DELETE RESTRICT,
    gateway       inet,
    funcion       varchar(150) NOT NULL,
    estado_diseno infra.estado_diseno NOT NULL DEFAULT 'actual',
    CONSTRAINT ck_subredes_gateway CHECK (gateway IS NULL OR (masklen(gateway) = (CASE family(gateway) WHEN 4 THEN 32 ELSE 128 END)
                                                              AND gateway <<= red)),
    CONSTRAINT ex_subredes_sin_solape EXCLUDE USING gist (estado_diseno WITH =, red inet_ops WITH &&)
);

-- 3.5 DISPOSITIVOS (equivale a "productos")
CREATE TABLE IF NOT EXISTS infra.dispositivos (
    id_dispositivo         uuid         PRIMARY KEY DEFAULT gen_random_uuid(),
    nombre                 varchar(100) NOT NULL,
    tipo                   infra.tipo_dispositivo NOT NULL,
    marca                  varchar(60),
    modelo                 varchar(100),
    numero_serie           varchar(100),
    id_ubicacion           uuid         REFERENCES infra.ubicaciones (id_ubicacion) ON DELETE RESTRICT,
    estado                 infra.estado_dispositivo NOT NULL DEFAULT 'operativo',
    fecha_instalacion      date,
    mantenimiento_cada_meses smallint,
    observaciones          varchar(500),
    CONSTRAINT uq_dispositivos_nombre UNIQUE (nombre),
    CONSTRAINT uq_dispositivos_serie  UNIQUE (numero_serie),
    CONSTRAINT ck_dispositivos_texto  CHECK (nombre !~ '[[:cntrl:]<>]' AND char_length(btrim(nombre)) >= 2
                                             AND COALESCE(observaciones, '') !~ '[[:cntrl:]]'),
    CONSTRAINT ck_dispositivos_mant   CHECK (mantenimiento_cada_meses IS NULL OR mantenimiento_cada_meses BETWEEN 1 AND 120)
);

-- 3.6 INTERFACES (puertos con IP/MAC)
CREATE TABLE IF NOT EXISTS infra.interfaces (
    id_interfaz    uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    id_dispositivo uuid        NOT NULL REFERENCES infra.dispositivos (id_dispositivo) ON DELETE CASCADE,
    nombre         varchar(40) NOT NULL,
    mac            macaddr,
    ip             inet,
    id_subred      uuid        REFERENCES infra.subredes (id_subred) ON DELETE RESTRICT,
    asignacion     infra.asignacion_ip NOT NULL DEFAULT 'estatica',
    CONSTRAINT uq_interfaces_nombre UNIQUE (id_dispositivo, nombre),
    CONSTRAINT uq_interfaces_ip     UNIQUE (ip),            -- evita IP duplicadas
    CONSTRAINT uq_interfaces_mac    UNIQUE (mac),
    CONSTRAINT ck_interfaces_nombre CHECK (nombre ~ '^[A-Za-z0-9/._:-]{1,40}$'),
    CONSTRAINT ck_interfaces_ip     CHECK (ip IS NULL OR masklen(ip) = (CASE family(ip) WHEN 4 THEN 32 ELSE 128 END))
);

-- 3.7 ENLACES (conexión física/lógica entre dos interfaces)
CREATE TABLE IF NOT EXISTS infra.enlaces (
    id_enlace      uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    id_interfaz_a  uuid        NOT NULL REFERENCES infra.interfaces (id_interfaz) ON DELETE CASCADE,
    id_interfaz_b  uuid        NOT NULL REFERENCES infra.interfaces (id_interfaz) ON DELETE CASCADE,
    medio          infra.tipo_medio NOT NULL,
    velocidad_mbps integer,
    descripcion    varchar(200),
    CONSTRAINT ck_enlaces_distintos CHECK (id_interfaz_a <> id_interfaz_b),
    CONSTRAINT ck_enlaces_vel       CHECK (velocidad_mbps IS NULL OR velocidad_mbps > 0),
    CONSTRAINT uq_enlaces_a UNIQUE (id_interfaz_a),
    CONSTRAINT uq_enlaces_b UNIQUE (id_interfaz_b)
);

-- 3.8 MANTENIMIENTOS (equivale a "pedidos")
CREATE TABLE IF NOT EXISTS infra.mantenimientos (
    id_mantenimiento uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    id_dispositivo   uuid        NOT NULL REFERENCES infra.dispositivos (id_dispositivo) ON DELETE RESTRICT,
    id_usuario       uuid        NOT NULL REFERENCES infra.usuarios (id_usuario) ON DELETE RESTRICT,  -- responsable
    tipo             infra.tipo_mantenimiento NOT NULL DEFAULT 'preventivo',
    descripcion      varchar(1000) NOT NULL,
    estado           infra.estado_mantenimiento NOT NULL DEFAULT 'programado',
    fecha_programada date        NOT NULL,
    fecha_realizada  date,
    fecha_registro   timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_mant_desc  CHECK (char_length(btrim(descripcion)) >= 3 AND descripcion !~ '[[:cntrl:]]'),
    CONSTRAINT ck_mant_fecha CHECK (estado <> 'completado' OR fecha_realizada IS NOT NULL),
    CONSTRAINT ck_mant_orden CHECK (fecha_realizada IS NULL OR fecha_realizada >= fecha_programada - 365)
);

/* ---- 4. TABLAS DE SEGURIDAD ---------------------------------------- */
CREATE TABLE IF NOT EXISTS infra.sesiones (
    id_sesion   uuid         PRIMARY KEY DEFAULT gen_random_uuid(),
    id_usuario  uuid         NOT NULL REFERENCES infra.usuarios (id_usuario) ON DELETE CASCADE,
    token_hash  bytea        NOT NULL,                    -- solo SHA-256; el token nunca se guarda
    ip          inet,
    user_agent  varchar(300),
    creada_en   timestamptz  NOT NULL DEFAULT now(),
    ultimo_uso  timestamptz  NOT NULL DEFAULT now(),
    expira_en   timestamptz  NOT NULL,
    revocada    boolean      NOT NULL DEFAULT false,
    CONSTRAINT uq_sesiones_token  UNIQUE (token_hash),
    CONSTRAINT ck_sesiones_expira CHECK (expira_en > creada_en)
);

CREATE UNLOGGED TABLE IF NOT EXISTS infra.rate_limit (
    clave           varchar(200) PRIMARY KEY,
    ventana_inicio  timestamptz  NOT NULL DEFAULT now(),
    contador        integer      NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS infra.auditoria (
    id_auditoria    bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fecha           timestamptz NOT NULL DEFAULT now(),
    id_usuario_app  uuid,                                 -- QUIÉN lo hizo (usuario de la aplicación)
    usuario_bd      text        NOT NULL DEFAULT session_user,
    tabla           text        NOT NULL,
    operacion       text        NOT NULL,
    id_registro     text,
    datos_antes     jsonb,
    datos_despues   jsonb
);

/* ---- 5. ÍNDICES ----------------------------------------------------- */
CREATE INDEX IF NOT EXISTS ix_dispositivos_tipo      ON infra.dispositivos (tipo);
CREATE INDEX IF NOT EXISTS ix_dispositivos_ubicacion ON infra.dispositivos (id_ubicacion);
CREATE INDEX IF NOT EXISTS ix_interfaces_disp        ON infra.interfaces (id_dispositivo);
CREATE INDEX IF NOT EXISTS ix_interfaces_subred      ON infra.interfaces (id_subred);
CREATE INDEX IF NOT EXISTS ix_subredes_vlan          ON infra.subredes (id_vlan);
CREATE INDEX IF NOT EXISTS ix_mant_dispositivo       ON infra.mantenimientos (id_dispositivo);
CREATE INDEX IF NOT EXISTS ix_mant_usuario           ON infra.mantenimientos (id_usuario);
CREATE INDEX IF NOT EXISTS ix_mant_fecha             ON infra.mantenimientos (fecha_programada);
CREATE INDEX IF NOT EXISTS ix_sesiones_usuario       ON infra.sesiones (id_usuario);
CREATE INDEX IF NOT EXISTS ix_sesiones_expira        ON infra.sesiones (expira_en);
CREATE INDEX IF NOT EXISTS ix_auditoria_tabla_fecha  ON infra.auditoria (tabla, fecha DESC);

/* ---- 6. CONTEXTO DEL USUARIO (base de la autorización) --------------
   La API fija el usuario de la sesión en cada transacción con
       SELECT set_config('app.user_id', '<uuid>', true);
   y la BD deduce su rol desde la tabla usuarios (no desde el cliente).  */
CREATE OR REPLACE FUNCTION infra.usuario_actual()
RETURNS uuid LANGUAGE sql STABLE
SET search_path = infra, pg_temp
AS $$ SELECT NULLIF(current_setting('app.user_id', true), '')::uuid; $$;

CREATE OR REPLACE FUNCTION infra.rol_actual()
RETURNS infra.rol_usuario LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = infra, pg_temp
AS $$ SELECT u.rol FROM infra.usuarios u WHERE u.id_usuario = infra.usuario_actual() AND u.activo; $$;

CREATE OR REPLACE FUNCTION infra.exigir_admin()
RETURNS void LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = infra, pg_temp
AS $$
BEGIN
    IF infra.rol_actual() IS DISTINCT FROM 'administrador' THEN
        RAISE EXCEPTION 'Permiso denegado' USING ERRCODE = '42501';
    END IF;
END
$$;

/* ---- 7. AUTENTICACIÓN Y SESIONES ------------------------------------
   SECURITY DEFINER + search_path fijo + parámetros tipados (sin SQL dinámico). */
CREATE OR REPLACE FUNCTION infra.validar_contrasena(p text)
RETURNS void LANGUAGE plpgsql IMMUTABLE
SET search_path = infra, extensions, pg_temp
AS $$
BEGIN
    -- bcrypt solo usa los primeros 72 BYTES: se rechaza más para no truncar en silencio.
    IF p IS NULL OR char_length(p) < 12 OR octet_length(p) > 72 THEN
        RAISE EXCEPTION 'La contraseña debe tener entre 12 caracteres y 72 bytes' USING ERRCODE = '22023';
    END IF;
    IF p !~ '[a-z]' OR p !~ '[A-Z]' OR p !~ '[0-9]' OR p !~ '[^A-Za-z0-9]' THEN
        RAISE EXCEPTION 'La contraseña debe incluir minúscula, mayúscula, número y símbolo' USING ERRCODE = '22023';
    END IF;
END
$$;

-- Solo para el dueño/DBA (NO se concede a rol_app). Así se crea el primer administrador.
CREATE OR REPLACE FUNCTION infra.registrar_usuario(
    p_nombre text, p_email text, p_contrasena text, p_rol infra.rol_usuario DEFAULT 'consulta')
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER
SET search_path = infra, extensions, pg_temp
AS $$
DECLARE v_id uuid;
BEGIN
    PERFORM infra.validar_contrasena(p_contrasena);
    INSERT INTO infra.usuarios (nombre, email, contrasena_hash, rol)
    VALUES (btrim(p_nombre), lower(btrim(p_email)), crypt(p_contrasena, gen_salt('bf', 12)), p_rol)
    RETURNING id_usuario INTO v_id;
    RETURN v_id;
EXCEPTION
    WHEN unique_violation THEN
        RAISE EXCEPTION 'No se pudo completar el registro' USING ERRCODE = '23505';
    WHEN check_violation OR not_null_violation THEN
        RAISE EXCEPTION 'Datos de registro inválidos' USING ERRCODE = '22023';
END
$$;

CREATE OR REPLACE FUNCTION infra.autenticar_usuario(p_email text, p_contrasena text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER
SET search_path = infra, extensions, pg_temp
AS $$
DECLARE u infra.usuarios%ROWTYPE;
BEGIN
    IF p_email IS NULL OR p_contrasena IS NULL OR octet_length(p_contrasena) > 72 THEN
        PERFORM crypt('relleno', gen_salt('bf', 12));
        RETURN NULL;
    END IF;

    SELECT * INTO u FROM infra.usuarios WHERE email = lower(btrim(p_email)) FOR UPDATE;

    -- Mismo coste de CPU exista o no el usuario: no se puede enumerar cuentas por tiempo.
    IF NOT FOUND OR NOT u.activo OR (u.bloqueado_hasta IS NOT NULL AND u.bloqueado_hasta > now()) THEN
        PERFORM crypt(p_contrasena, gen_salt('bf', 12));
        RETURN NULL;
    END IF;

    IF u.contrasena_hash = crypt(p_contrasena, u.contrasena_hash) THEN
        UPDATE infra.usuarios SET intentos_fallidos = 0, bloqueado_hasta = NULL
         WHERE id_usuario = u.id_usuario;
        RETURN u.id_usuario;
    END IF;

    UPDATE infra.usuarios
       SET bloqueado_hasta   = CASE WHEN intentos_fallidos + 1 >= 5 THEN now() + interval '15 minutes'
                                    ELSE bloqueado_hasta END,
           intentos_fallidos = CASE WHEN intentos_fallidos + 1 >= 5 THEN 0 ELSE intentos_fallidos + 1 END
     WHERE id_usuario = u.id_usuario;

    IF u.intentos_fallidos + 1 >= 5 THEN
        INSERT INTO infra.auditoria (id_usuario_app, tabla, operacion, id_registro)
        VALUES (u.id_usuario, 'usuarios', 'BLOQUEO_CUENTA', u.id_usuario::text);
    END IF;
    RETURN NULL;
END
$$;

CREATE OR REPLACE FUNCTION infra.crear_sesion(
    p_id_usuario uuid, p_ip inet DEFAULT NULL, p_user_agent text DEFAULT NULL,
    p_ttl interval DEFAULT interval '8 hours')
RETURNS text LANGUAGE plpgsql SECURITY DEFINER
SET search_path = infra, extensions, pg_temp
AS $$
DECLARE
    v_token text;
    v_ttl   interval := LEAST(COALESCE(p_ttl, interval '8 hours'), interval '24 hours');
BEGIN
    IF NOT EXISTS (SELECT 1 FROM infra.usuarios WHERE id_usuario = p_id_usuario AND activo) THEN
        RAISE EXCEPTION 'Usuario no válido' USING ERRCODE = '28000';
    END IF;
    v_token := encode(gen_random_bytes(32), 'hex');                 -- 256 bits
    INSERT INTO infra.sesiones (id_usuario, token_hash, ip, user_agent, expira_en)
    VALUES (p_id_usuario, digest(v_token, 'sha256'), p_ip, left(p_user_agent, 300), now() + v_ttl);
    RETURN v_token;
END
$$;

-- Expiración absoluta (8 h) + inactividad (30 min) + no revocada + usuario activo.
CREATE OR REPLACE FUNCTION infra.validar_sesion(p_token text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER
SET search_path = infra, extensions, pg_temp
AS $$
DECLARE v_id uuid;
BEGIN
    IF p_token IS NULL OR p_token !~ '^[0-9a-f]{64}$' THEN RETURN NULL; END IF;
    UPDATE infra.sesiones s SET ultimo_uso = now()
      FROM infra.usuarios u
     WHERE u.id_usuario = s.id_usuario AND u.activo
       AND s.token_hash = digest(p_token, 'sha256')
       AND NOT s.revocada AND s.expira_en > now()
       AND s.ultimo_uso > now() - interval '30 minutes'
    RETURNING s.id_usuario INTO v_id;
    RETURN v_id;
END
$$;

CREATE OR REPLACE FUNCTION infra.cerrar_sesion(p_token text)
RETURNS void LANGUAGE sql SECURITY DEFINER
SET search_path = infra, extensions, pg_temp
AS $$ UPDATE infra.sesiones SET revocada = true WHERE token_hash = digest(p_token, 'sha256'); $$;

-- Interna (no se concede a rol_app): la usan cambiar_contrasena y las funciones de admin.
CREATE OR REPLACE FUNCTION infra.revocar_sesiones_usuario(p_id_usuario uuid)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER
SET search_path = infra, extensions, pg_temp
AS $$
DECLARE n integer;
BEGIN
    UPDATE infra.sesiones SET revocada = true WHERE id_usuario = p_id_usuario AND NOT revocada;
    GET DIAGNOSTICS n = ROW_COUNT;
    RETURN n;
END
$$;

CREATE OR REPLACE FUNCTION infra.cambiar_contrasena(p_id_usuario uuid, p_actual text, p_nueva text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER
SET search_path = infra, extensions, pg_temp
AS $$
DECLARE v_hash text;
BEGIN
    -- Solo se puede cambiar la propia contraseña.
    IF p_id_usuario IS DISTINCT FROM infra.usuario_actual() THEN
        RAISE EXCEPTION 'Permiso denegado' USING ERRCODE = '42501';
    END IF;
    PERFORM infra.validar_contrasena(p_nueva);
    SELECT contrasena_hash INTO v_hash FROM infra.usuarios
     WHERE id_usuario = p_id_usuario AND activo FOR UPDATE;
    IF v_hash IS NULL OR p_actual IS NULL OR v_hash <> crypt(p_actual, v_hash) THEN RETURN false; END IF;
    UPDATE infra.usuarios SET contrasena_hash = crypt(p_nueva, gen_salt('bf', 12))
     WHERE id_usuario = p_id_usuario;
    PERFORM infra.revocar_sesiones_usuario(p_id_usuario);
    RETURN true;
END
$$;

-- Limitación de solicitudes (ventana fija, atómica).
CREATE OR REPLACE FUNCTION infra.permitir_solicitud(p_clave text, p_limite integer, p_ventana interval)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER
SET search_path = infra, extensions, pg_temp
AS $$
DECLARE v_cont integer;
BEGIN
    INSERT INTO infra.rate_limit AS r (clave, ventana_inicio, contador)
    VALUES (left(p_clave, 200), now(), 1)
    ON CONFLICT (clave) DO UPDATE
       SET contador       = CASE WHEN r.ventana_inicio < now() - p_ventana THEN 1 ELSE r.contador + 1 END,
           ventana_inicio = CASE WHEN r.ventana_inicio < now() - p_ventana THEN now() ELSE r.ventana_inicio END
    RETURNING contador INTO v_cont;
    RETURN v_cont <= p_limite;
END
$$;

CREATE OR REPLACE FUNCTION infra.limpieza_periodica()
RETURNS void LANGUAGE sql SECURITY DEFINER
SET search_path = infra, extensions, pg_temp
AS $$
    DELETE FROM infra.sesiones WHERE expira_en < now() - interval '7 days'
        OR (revocada AND creada_en < now() - interval '7 days');
    DELETE FROM infra.rate_limit WHERE ventana_inicio < now() - interval '1 day';
$$;

/* ---- 8. GESTIÓN DE USUARIOS (solo administradores) ------------------ */
CREATE OR REPLACE FUNCTION infra.admin_crear_usuario(
    p_nombre text, p_email text, p_contrasena text, p_rol infra.rol_usuario DEFAULT 'consulta')
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER
SET search_path = infra, extensions, pg_temp
AS $$
BEGIN
    PERFORM infra.exigir_admin();
    RETURN infra.registrar_usuario(p_nombre, p_email, p_contrasena, p_rol);
END
$$;

CREATE OR REPLACE FUNCTION infra.admin_listar_usuarios()
RETURNS TABLE (id_usuario uuid, nombre varchar, email citext, rol infra.rol_usuario,
               activo boolean, fecha_registro timestamptz)
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = infra, extensions, pg_temp
AS $$
BEGIN
    PERFORM infra.exigir_admin();
    RETURN QUERY SELECT u.id_usuario, u.nombre, u.email, u.rol, u.activo, u.fecha_registro
                   FROM infra.usuarios u ORDER BY u.nombre;
END
$$;

CREATE OR REPLACE FUNCTION infra.admin_cambiar_rol(p_id uuid, p_rol infra.rol_usuario)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER
SET search_path = infra, extensions, pg_temp
AS $$
BEGIN
    PERFORM infra.exigir_admin();
    IF p_id = infra.usuario_actual() THEN
        RAISE EXCEPTION 'No puedes cambiar tu propio rol' USING ERRCODE = '42501';
    END IF;
    UPDATE infra.usuarios SET rol = p_rol WHERE id_usuario = p_id;
END
$$;

CREATE OR REPLACE FUNCTION infra.admin_establecer_activo(p_id uuid, p_activo boolean)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER
SET search_path = infra, extensions, pg_temp
AS $$
BEGIN
    PERFORM infra.exigir_admin();
    IF p_id = infra.usuario_actual() THEN
        RAISE EXCEPTION 'No puedes desactivar tu propia cuenta' USING ERRCODE = '42501';
    END IF;
    UPDATE infra.usuarios SET activo = p_activo WHERE id_usuario = p_id;
    IF NOT p_activo THEN PERFORM infra.revocar_sesiones_usuario(p_id); END IF;
END
$$;

/* ---- 9. REGLAS DE INTEGRIDAD DE RED (triggers) ---------------------- */
-- La IP de una interfaz debe pertenecer a su subred.
CREATE OR REPLACE FUNCTION infra.fn_validar_interfaz()
RETURNS trigger LANGUAGE plpgsql
SET search_path = infra, pg_temp
AS $$
DECLARE v_red cidr;
BEGIN
    IF NEW.ip IS NOT NULL AND NEW.id_subred IS NOT NULL THEN
        SELECT red INTO v_red FROM infra.subredes WHERE id_subred = NEW.id_subred;
        IF NOT (NEW.ip <<= v_red) THEN
            RAISE EXCEPTION 'La IP % no pertenece a la subred %', NEW.ip, v_red USING ERRCODE = '23514';
        END IF;
    END IF;
    RETURN NEW;
END
$$;

DROP TRIGGER IF EXISTS tg_validar_interfaz ON infra.interfaces;
CREATE TRIGGER tg_validar_interfaz BEFORE INSERT OR UPDATE ON infra.interfaces
    FOR EACH ROW EXECUTE FUNCTION infra.fn_validar_interfaz();

/* ---- 10. AUDITORÍA (inmutable) -------------------------------------- */
CREATE OR REPLACE FUNCTION infra.fn_auditar()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
SET search_path = infra, extensions, pg_temp
AS $$
DECLARE v_old jsonb; v_new jsonb;
BEGIN
    IF TG_OP IN ('UPDATE','DELETE') THEN v_old := to_jsonb(OLD) - 'contrasena_hash'; END IF;
    IF TG_OP IN ('INSERT','UPDATE') THEN v_new := to_jsonb(NEW) - 'contrasena_hash'; END IF;
    INSERT INTO infra.auditoria (id_usuario_app, tabla, operacion, id_registro, datos_antes, datos_despues)
    VALUES (infra.usuario_actual(), TG_TABLE_NAME, TG_OP, COALESCE(v_new, v_old) ->> TG_ARGV[0], v_old, v_new);
    RETURN NULL;
END
$$;

DO $$
DECLARE t record;
BEGIN
    FOR t IN SELECT * FROM (VALUES
        ('usuarios','id_usuario'), ('ubicaciones','id_ubicacion'), ('vlans','id_vlan'),
        ('subredes','id_subred'), ('dispositivos','id_dispositivo'), ('interfaces','id_interfaz'),
        ('enlaces','id_enlace'), ('mantenimientos','id_mantenimiento')) AS v(tabla, pk)
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS tg_auditar ON infra.%I', t.tabla);
        EXECUTE format('CREATE TRIGGER tg_auditar AFTER INSERT OR UPDATE OR DELETE ON infra.%I
                        FOR EACH ROW EXECUTE FUNCTION infra.fn_auditar(%L)', t.tabla, t.pk);
    END LOOP;
END
$$;

CREATE OR REPLACE FUNCTION infra.fn_auditoria_inmutable()
RETURNS trigger LANGUAGE plpgsql
SET search_path = infra, pg_temp
AS $$ BEGIN RAISE EXCEPTION 'La tabla de auditoría es de solo inserción' USING ERRCODE = '42501'; END $$;

DROP TRIGGER IF EXISTS tg_auditoria_inmutable ON infra.auditoria;
CREATE TRIGGER tg_auditoria_inmutable BEFORE UPDATE OR DELETE ON infra.auditoria
    FOR EACH ROW EXECUTE FUNCTION infra.fn_auditoria_inmutable();
DROP TRIGGER IF EXISTS tg_auditoria_no_truncate ON infra.auditoria;
CREATE TRIGGER tg_auditoria_no_truncate BEFORE TRUNCATE ON infra.auditoria
    FOR EACH STATEMENT EXECUTE FUNCTION infra.fn_auditoria_inmutable();

/* ---- 11. VISTAS ÚTILES (solo para usuarios autenticados) ------------ */
-- Capacidad vs. IPs registradas por subred (detecta subredes demasiado chicas).
CREATE OR REPLACE VIEW infra.v_uso_subredes AS
SELECT s.id_subred, s.red, s.estado_diseno, s.funcion,
       GREATEST((2 ^ (32 - masklen(s.red)))::bigint - 2, 0) AS capacidad_hosts,
       count(i.ip) AS ips_registradas
  FROM infra.subredes s
  LEFT JOIN infra.interfaces i ON i.id_subred = s.id_subred
 WHERE infra.rol_actual() IS NOT NULL AND family(s.red) = 4
 GROUP BY s.id_subred;

-- Próximo mantenimiento = último completado (o instalación) + periodicidad.
CREATE OR REPLACE VIEW infra.v_proximos_mantenimientos AS
SELECT d.id_dispositivo, d.nombre, d.tipo, d.mantenimiento_cada_meses,
       u.ultimo AS ultimo_mantenimiento,
       (COALESCE(u.ultimo, d.fecha_instalacion)
            + make_interval(months => d.mantenimiento_cada_meses))::date AS proximo
  FROM infra.dispositivos d
  LEFT JOIN LATERAL (SELECT max(m.fecha_realizada) AS ultimo FROM infra.mantenimientos m
                      WHERE m.id_dispositivo = d.id_dispositivo AND m.estado = 'completado') u ON true
 WHERE infra.rol_actual() IS NOT NULL
   AND d.mantenimiento_cada_meses IS NOT NULL AND d.estado <> 'retirado';

/* ---- 12. ROW LEVEL SECURITY ----------------------------------------
   - Inventario (ubicaciones, vlans, subredes, dispositivos, interfaces, enlaces):
       cualquier usuario autenticado LEE; solo el administrador ESCRIBE.
     (El mapa de IPs de una red municipal es información sensible: sin sesión no se ve nada.)
   - Mantenimientos: todos leen; el técnico crea y edita SOLO los suyos; el admin todo.  */
DO $$
DECLARE t text;
BEGIN
    FOREACH t IN ARRAY ARRAY['ubicaciones','vlans','subredes','dispositivos','interfaces','enlaces','mantenimientos']
    LOOP
        EXECUTE format('ALTER TABLE infra.%I ENABLE ROW LEVEL SECURITY', t);
        EXECUTE format('DROP POLICY IF EXISTS p_lectura  ON infra.%I', t);
        EXECUTE format('DROP POLICY IF EXISTS p_admin    ON infra.%I', t);
        EXECUTE format('DROP POLICY IF EXISTS p_reportes ON infra.%I', t);
        EXECUTE format('CREATE POLICY p_lectura  ON infra.%I FOR SELECT TO rol_app
                        USING (infra.rol_actual() IS NOT NULL)', t);
        EXECUTE format('CREATE POLICY p_admin    ON infra.%I FOR ALL TO rol_app
                        USING (infra.rol_actual() = ''administrador'')
                        WITH CHECK (infra.rol_actual() = ''administrador'')', t);
        EXECUTE format('CREATE POLICY p_reportes ON infra.%I FOR SELECT TO rol_lectura USING (true)', t);
    END LOOP;
END
$$;

DROP POLICY IF EXISTS p_tecnico_insert ON infra.mantenimientos;
CREATE POLICY p_tecnico_insert ON infra.mantenimientos FOR INSERT TO rol_app
    WITH CHECK (infra.rol_actual() = 'tecnico' AND id_usuario = infra.usuario_actual());
DROP POLICY IF EXISTS p_tecnico_update ON infra.mantenimientos;
CREATE POLICY p_tecnico_update ON infra.mantenimientos FOR UPDATE TO rol_app
    USING (infra.rol_actual() = 'tecnico' AND id_usuario = infra.usuario_actual())
    WITH CHECK (infra.rol_actual() = 'tecnico' AND id_usuario = infra.usuario_actual());

/* ---- 13. PERMISOS --------------------------------------------------- */
REVOKE ALL ON ALL TABLES    IN SCHEMA infra FROM PUBLIC, rol_app, rol_lectura;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA infra FROM PUBLIC, rol_app, rol_lectura;

GRANT SELECT, INSERT, UPDATE, DELETE ON infra.ubicaciones, infra.vlans, infra.subredes,
      infra.dispositivos, infra.interfaces, infra.enlaces TO rol_app;      -- filtrado por RLS
GRANT SELECT, INSERT, DELETE ON infra.mantenimientos TO rol_app;           -- filtrado por RLS
GRANT UPDATE (descripcion, estado, fecha_programada, fecha_realizada) ON infra.mantenimientos TO rol_app;
GRANT SELECT ON infra.v_uso_subredes, infra.v_proximos_mantenimientos TO rol_app;
GRANT SELECT ON infra.ubicaciones, infra.vlans, infra.subredes, infra.dispositivos,
                infra.interfaces, infra.enlaces, infra.mantenimientos TO rol_lectura;

GRANT EXECUTE ON FUNCTION
    infra.usuario_actual(), infra.rol_actual(),
    infra.autenticar_usuario(text, text), infra.crear_sesion(uuid, inet, text, interval),
    infra.validar_sesion(text), infra.cerrar_sesion(text),
    infra.cambiar_contrasena(uuid, text, text), infra.permitir_solicitud(text, integer, interval),
    infra.admin_crear_usuario(text, text, text, infra.rol_usuario), infra.admin_listar_usuarios(),
    infra.admin_cambiar_rol(uuid, infra.rol_usuario), infra.admin_establecer_activo(uuid, boolean)
    TO rol_app;
-- usuarios, sesiones, rate_limit y auditoria: sin acceso directo para rol_app.

/* ---- 14. DOCUMENTACIÓN (visible en pgAdmin) ------------------------- */
COMMENT ON SCHEMA infra IS 'Inventario y gestión de la red - Municipalidad Distrital de Alto Selva Alegre';
COMMENT ON TABLE infra.usuarios       IS 'Personal autorizado. Contraseña solo como hash bcrypt.';
COMMENT ON TABLE infra.dispositivos   IS 'Equipos de red y servidores.';
COMMENT ON TABLE infra.mantenimientos IS 'Órdenes de mantenimiento por dispositivo.';
COMMENT ON TABLE infra.subredes       IS 'Segmentos IP; sin solapamientos dentro de un mismo diseño (actual/propuesto).';
COMMENT ON TABLE infra.auditoria      IS 'Bitácora inmutable: quién cambió qué y cuándo.';

COMMIT;

/* ---------------------------------------------------------------------
   15. CUENTAS (EJECUTAR APARTE; NO DEJAR CONTRASEÑAS EN EL SCRIPT)

   a) Primer administrador de la aplicación (como postgres):
      SELECT infra.registrar_usuario('Nombre Apellido', 'correo@dominio.pe',
             '<contraseña-larga-generada>', 'administrador');

   b) Cuenta de login para la API:
      CREATE ROLE app_backend LOGIN PASSWORD '<secreto-generado>' IN ROLE rol_app CONNECTION LIMIT 20;
      ALTER ROLE app_backend SET statement_timeout = '5s';
      ALTER ROLE app_backend SET idle_in_transaction_session_timeout = '15s';

   c) Cuenta de reportes (solo lectura):
      CREATE ROLE reportes LOGIN PASSWORD '<secreto-generado>' IN ROLE rol_lectura CONNECTION LIMIT 5;
   --------------------------------------------------------------------- */
