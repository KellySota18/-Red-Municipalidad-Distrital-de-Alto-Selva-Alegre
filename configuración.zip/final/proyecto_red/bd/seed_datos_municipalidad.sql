/* =====================================================================
   seed_datos_municipalidad.sql
   Carga los datos documentados en el "Diario de Ingeniería - Visita Académica
   a la Municipalidad de Alto Selva Alegre" (Computación en Red II, Julio 2025).
   Ejecutar DESPUÉS de infra_red_schema_seguro.sql, como postgres.
   Solo incluye lo que el informe afirma; lo que no figura queda en NULL.
   Es re-ejecutable (no duplica datos).
   ===================================================================== */
BEGIN;
SET LOCAL search_path = infra, extensions;

/* ---- Ubicaciones (secciones 5, 7.1 y 8) ---- */
INSERT INTO ubicaciones (sede, piso, ambiente) VALUES
  ('Municipalidad (edificio principal)', 4, 'Centro de datos / área de redes'),
  ('Municipalidad (edificio principal)', 3, 'Distribución de red del piso'),
  ('Municipalidad (edificio principal)', 2, 'Distribución de red del piso'),
  ('Municipalidad (edificio principal)', 1, 'Distribución de red del piso'),
  ('Oficina Roosevelt', NULL, 'Oficinas remotas (enlace por radioenlace)'),
  ('Seguridad Ciudadana (serenazgo)', NULL, 'Edificio de seguridad (enlace por cable UTP)')
ON CONFLICT DO NOTHING;

/* ---- VLANs: la red ACTUAL es plana (sin VLANs). Tabla 6 = diseño PROPUESTO ---- */
INSERT INTO vlans (numero, nombre, funcion, estado_diseno) VALUES
  (10, 'SERVERS',  'Red de servidores',        'propuesto'),
  (20, 'PRINTERS', 'Red de impresoras',        'propuesto'),
  (30, 'AREA_X',   'Usuarios (Pisos 1 y 3)',   'propuesto'),
  (40, 'AREA_Y',   'Usuarios (Pisos 2 y 4)',   'propuesto'),
  (99, 'MGMT',     'Administración/switches',  'propuesto'),
  -- El apartado 14.4 menciona la VLAN 50 (Seguridad Ciudadana) que NO figura en la Tabla 6.
  (50, 'SEGURIDAD','Enlace con Seguridad Ciudadana (mencionada en 14.4; sin gateway definido)', 'propuesto')
ON CONFLICT DO NOTHING;

/* ---- Subredes ---- */
-- Actuales (Tabla 1 del informe)
INSERT INTO subredes (red, gateway, funcion, estado_diseno) VALUES
  ('10.0.0.0/24', '10.0.0.1', 'Edificio central: servidores centrales (SIAF, Intranet, BD)', 'actual'),
  ('10.0.1.0/24', '10.0.1.1', 'Edificio derecho: PCs e impresoras administrativas',          'actual'),
  ('10.0.2.0/24', '10.0.2.1', 'Roosevelt: oficinas remotas por radioenlace',                 'actual')
ON CONFLICT DO NOTHING;

-- Propuestas (Tabla 6). El informe da solo el gateway; la máscara /24 es una SUPOSICIÓN a confirmar.
INSERT INTO subredes (red, id_vlan, gateway, funcion, estado_diseno)
SELECT v.red::cidr, vl.id_vlan, v.gw::inet, v.funcion, 'propuesto'
  FROM (VALUES
     ('10.10.10.0/24', 10, '10.10.10.1', 'Servidores (máscara /24 supuesta)'),
     ('10.10.20.0/24', 20, '10.10.20.1', 'Impresoras (máscara /24 supuesta)'),
     ('10.10.30.0/24', 30, '10.10.30.1', 'Usuarios pisos 1 y 3 (máscara /24 supuesta)'),
     ('10.10.40.0/24', 40, '10.10.40.1', 'Usuarios pisos 2 y 4 (máscara /24 supuesta)'),
     ('10.10.99.0/24', 99, '10.10.99.1', 'Administración (máscara /24 supuesta)')
  ) AS v(red, numero, gw, funcion)
  JOIN vlans vl ON vl.numero = v.numero AND vl.estado_diseno = 'propuesto'
ON CONFLICT DO NOTHING;

/* ---- Dispositivos (Tabla 12 y sección 7/10.3) ---- */
INSERT INTO dispositivos (nombre, tipo, marca, modelo, id_ubicacion, mantenimiento_cada_meses, observaciones)
SELECT d.nombre, d.tipo::tipo_dispositivo, d.marca, d.modelo,
       (SELECT id_ubicacion FROM ubicaciones WHERE ambiente LIKE 'Centro de datos%') AS ubic,
       d.mant, d.obs
  FROM (VALUES
    ('FW-FORTIGATE-90G', 'firewall', 'Fortinet', 'FortiGate 90G', 12,
        'Filtrado capa 3-7, DHCP centralizado. Verificar modelo contra la etiqueta física (la Figura 47 parece mostrar otro).'),
    ('UPS-APC-SRV1KRI', 'ups', 'APC', 'Easy UPS On-Line SRV1KRI (1000 VA)', 12, NULL),
    ('RT-MIKROTIK-L009', 'router', 'MikroTik', 'L009UiGS-RM', 12,
        'El informe lo lista como switch rackmount; el L009UiGS-RM es un router RouterOS.'),
    ('SW-TPLINK-SG3428MP', 'switch', 'TP-Link', 'SG3428MP (Omada, 24 PoE + 4 SFP)', 12, NULL),
    ('ONU-PHYHOME-EPON', 'onu', 'Phyhome', 'EPON ONU', 12, 'Enlace de fibra del ISP Misticom (simétrico 200 Mb).'),
    ('SW-HUAWEI-S2700', 'switch', 'Huawei', 'S2700-26TP-EI-AC (24 GE + 2 SFP)', NULL, 'Mantenimiento no indicado en el informe.'),
    ('RE-UBIQUITI-01', 'radioenlace', 'Ubiquiti', NULL, NULL, 'Enlace con oficina Roosevelt. Modelo y mantenimiento no indicados.'),
    ('SRV-GOB-1', 'servidor', NULL, NULL, NULL, 'Windows Server. Sistema del Estado (SIAF / recaudación / arbitrios).'),
    ('SRV-GOB-2', 'servidor', NULL, NULL, NULL, 'Windows Server. Sistema del Estado (SIAF / recaudación / arbitrios).'),
    ('SRV-GOB-3', 'servidor', NULL, NULL, NULL, 'Windows Server. Sistema del Estado (SIAF / recaudación / arbitrios).'),
    ('SRV-ADM-1', 'servidor', NULL, NULL, NULL, 'Windows Server. Administración interna (Intranet, recursos humanos).'),
    ('SRV-ADM-2', 'servidor', NULL, NULL, NULL, 'Windows Server. Administración interna (Intranet, recursos humanos).'),
    ('SRV-ARCH-1', 'servidor', NULL, NULL, NULL, 'Windows Server. Servicios compartidos y archivos internos.')
  ) AS d(nombre, tipo, marca, modelo, mant, obs)
ON CONFLICT DO NOTHING;

-- El informe fija los servidores en 10.0.0.10-15 pero NO indica qué IP corresponde a cuál.
-- Cuando lo confirmes, regístralo así (el trigger valida que la IP pertenezca a la subred):
--   INSERT INTO interfaces (id_dispositivo, nombre, ip, id_subred)
--   SELECT d.id_dispositivo, 'eth0', '10.0.0.10',
--          (SELECT id_subred FROM subredes WHERE red = '10.0.0.0/24' AND estado_diseno = 'actual')
--     FROM dispositivos d WHERE d.nombre = 'SRV-GOB-1';

COMMIT;
