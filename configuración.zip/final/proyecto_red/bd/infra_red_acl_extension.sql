/* =====================================================================
   infra_red_acl_extension.sql
   Extiende infra_red_schema_seguro.sql con el modelo de seguridad de red:
   políticas, ACL, reglas, aplicación por interfaz y pruebas de conectividad.
   Ejecutar DESPUÉS del esquema base, como postgres. Es re-ejecutable.
   La base guarda la ACL y puede REGENERAR el texto IOS (infra.generar_config_acl).
   ===================================================================== */
BEGIN;
SET LOCAL search_path = infra, extensions;

/* ---- Tipos ---- */
DO $$
DECLARE t record;
BEGIN
    FOR t IN SELECT * FROM (VALUES
        ('tipo_acl',   ARRAY['estandar','extendida']),
        ('accion_acl', ARRAY['permit','deny']),
        ('sentido_acl', ARRAY['in','out']),
        ('veredicto',  ARRAY['permitido','bloqueado','unidireccional'])
    ) AS v(nombre, valores)
    LOOP
        IF NOT EXISTS (SELECT 1 FROM pg_type ty JOIN pg_namespace n ON n.oid = ty.typnamespace
                       WHERE n.nspname = 'infra' AND ty.typname = t.nombre) THEN
            EXECUTE format('CREATE TYPE infra.%I AS ENUM (%s)', t.nombre,
                           (SELECT string_agg(quote_literal(x), ',') FROM unnest(t.valores) x));
        END IF;
    END LOOP;
END
$$;

/* ---- Tablas ---- */
CREATE TABLE IF NOT EXISTS infra.politicas_seguridad (
    id_politica uuid         PRIMARY KEY DEFAULT gen_random_uuid(),
    codigo      varchar(10)  NOT NULL,
    descripcion varchar(300) NOT NULL,
    CONSTRAINT uq_politicas_codigo UNIQUE (codigo),
    CONSTRAINT ck_politicas_codigo CHECK (codigo ~ '^P[0-9]{1,2}$'),
    CONSTRAINT ck_politicas_desc   CHECK (char_length(btrim(descripcion)) >= 5 AND descripcion !~ '[[:cntrl:]<>]')
);

CREATE TABLE IF NOT EXISTS infra.acls (
    id_acl      uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    id_router   uuid        NOT NULL REFERENCES infra.dispositivos (id_dispositivo) ON DELETE RESTRICT,
    nombre      varchar(60) NOT NULL,
    tipo        infra.tipo_acl NOT NULL,
    numerada    boolean     NOT NULL,
    version     varchar(20) NOT NULL,
    id_politica uuid        REFERENCES infra.politicas_seguridad (id_politica) ON DELETE SET NULL,
    CONSTRAINT uq_acls UNIQUE (id_router, nombre, version),
    CONSTRAINT ck_acls_nombre  CHECK (nombre ~ '^[A-Za-z0-9_-]{1,60}$'),
    CONSTRAINT ck_acls_version CHECK (version IN ('v1_informe', 'v2_default_deny')),
    CONSTRAINT ck_acls_numerada CHECK (numerada = (nombre ~ '^[0-9]+$'))
);

CREATE TABLE IF NOT EXISTS infra.acl_reglas (
    id_regla   uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    id_acl     uuid        NOT NULL REFERENCES infra.acls (id_acl) ON DELETE CASCADE,
    secuencia  integer     NOT NULL,
    accion     infra.accion_acl NOT NULL,
    condicion  varchar(200) NOT NULL,                      -- lo que sigue a permit/deny en IOS
    CONSTRAINT uq_acl_reglas UNIQUE (id_acl, secuencia),
    CONSTRAINT ck_acl_reglas_seq  CHECK (secuencia > 0),
    CONSTRAINT ck_acl_reglas_cond CHECK (condicion ~ '^[A-Za-z0-9 ./_-]+$')    -- sin comandos ni caracteres de control
);

CREATE TABLE IF NOT EXISTS infra.acl_aplicaciones (
    id_aplicacion uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    id_acl        uuid        NOT NULL REFERENCES infra.acls (id_acl) ON DELETE CASCADE,
    interfaz      varchar(40) NOT NULL,
    sentido       infra.sentido_acl NOT NULL,
    CONSTRAINT uq_acl_aplicaciones UNIQUE (id_acl, interfaz, sentido),
    CONSTRAINT ck_acl_aplic_if CHECK (interfaz ~ '^[A-Za-z0-9/._:-]+$')
);

CREATE TABLE IF NOT EXISTS infra.pruebas_conectividad (
    id_prueba          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    version            varchar(20) NOT NULL,
    n_tabla16          smallint,                               -- número de prueba en la Tabla 16 del informe
    origen             varchar(40) NOT NULL,
    destino            varchar(40) NOT NULL,
    servicio           varchar(20) NOT NULL,
    resultado_esperado infra.veredicto NOT NULL,
    resultado_obtenido infra.veredicto,
    fuente             varchar(20) NOT NULL,
    fecha              timestamptz NOT NULL DEFAULT now(),
    id_usuario         uuid        REFERENCES infra.usuarios (id_usuario) ON DELETE SET NULL,
    CONSTRAINT ck_pruebas_version CHECK (version IN ('v1_informe', 'v2_default_deny')),
    CONSTRAINT ck_pruebas_fuente  CHECK (fuente IN ('packet_tracer', 'simulador')),
    CONSTRAINT ck_pruebas_texto   CHECK (origen ~ '^[A-Za-z0-9_.-]+$' AND destino ~ '^[A-Za-z0-9_.-]+$' AND servicio ~ '^[a-z0-9]+$')
);

CREATE INDEX IF NOT EXISTS ix_acls_router      ON infra.acls (id_router);
CREATE INDEX IF NOT EXISTS ix_acl_reglas_acl   ON infra.acl_reglas (id_acl);
CREATE INDEX IF NOT EXISTS ix_acl_aplic_acl    ON infra.acl_aplicaciones (id_acl);
CREATE INDEX IF NOT EXISTS ix_pruebas_version  ON infra.pruebas_conectividad (version, fuente);

/* ---- Regla de integridad: una sola ACL por interfaz, sentido, router y versión ---- */
CREATE OR REPLACE FUNCTION infra.fn_validar_aplicacion()
RETURNS trigger LANGUAGE plpgsql
SET search_path = infra, pg_temp
AS $$
DECLARE v_router uuid; v_version varchar;
BEGIN
    SELECT id_router, version INTO v_router, v_version FROM infra.acls WHERE id_acl = NEW.id_acl;
    IF EXISTS (SELECT 1 FROM infra.acl_aplicaciones ap JOIN infra.acls a USING (id_acl)
                WHERE a.id_router = v_router AND a.version = v_version
                  AND ap.interfaz = NEW.interfaz AND ap.sentido = NEW.sentido
                  AND ap.id_acl <> NEW.id_acl) THEN        -- otra ACL distinta en la misma interfaz y sentido
        RAISE EXCEPTION 'La interfaz % ya tiene una ACL en sentido % (se permite una por interfaz y sentido)',
            NEW.interfaz, NEW.sentido USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
END
$$;
DROP TRIGGER IF EXISTS tg_validar_aplicacion ON infra.acl_aplicaciones;
CREATE TRIGGER tg_validar_aplicacion BEFORE INSERT OR UPDATE ON infra.acl_aplicaciones
    FOR EACH ROW EXECUTE FUNCTION infra.fn_validar_aplicacion();

/* ---- Auditoría ---- */
DO $$
DECLARE t record;
BEGIN
    FOR t IN SELECT * FROM (VALUES ('politicas_seguridad','id_politica'), ('acls','id_acl'),
        ('acl_reglas','id_regla'), ('acl_aplicaciones','id_aplicacion'), ('pruebas_conectividad','id_prueba')) AS v(tabla, pk)
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS tg_auditar ON infra.%I', t.tabla);
        EXECUTE format('CREATE TRIGGER tg_auditar AFTER INSERT OR UPDATE OR DELETE ON infra.%I
                        FOR EACH ROW EXECUTE FUNCTION infra.fn_auditar(%L)', t.tabla, t.pk);
    END LOOP;
END
$$;

/* ---- Vistas ---- */
-- Postura de cada ACL: ¿termina permitiendo todo (permitir por defecto) o denegando todo?
CREATE OR REPLACE VIEW infra.v_acl_postura AS
SELECT d.nombre AS router, a.version, a.nombre AS acl, a.tipo, r.total_reglas, r.ultima_regla,
       CASE WHEN r.ultima_regla ~ '^permit (ip )?any( any)?$' THEN 'PERMITIR por defecto'
            WHEN r.ultima_regla ~ '^deny ip any any' THEN 'DENEGAR por defecto'
            ELSE 'deny implícito (sin regla final explícita)' END AS postura
  FROM infra.acls a
  JOIN infra.dispositivos d ON d.id_dispositivo = a.id_router
  JOIN LATERAL (SELECT count(*) AS total_reglas,
                       (SELECT x.accion::text || ' ' || x.condicion FROM infra.acl_reglas x
                         WHERE x.id_acl = a.id_acl ORDER BY x.secuencia DESC LIMIT 1) AS ultima_regla
                  FROM infra.acl_reglas g WHERE g.id_acl = a.id_acl) r ON true
 WHERE infra.rol_actual() IS NOT NULL;

CREATE OR REPLACE VIEW infra.v_pruebas_resumen AS
SELECT version, fuente, count(*) AS pruebas,
       count(*) FILTER (WHERE resultado_obtenido = resultado_esperado) AS correctas,
       count(*) FILTER (WHERE resultado_obtenido IS DISTINCT FROM resultado_esperado) AS fallidas
  FROM infra.pruebas_conectividad
 WHERE infra.rol_actual() IS NOT NULL
 GROUP BY version, fuente;

/* ---- Generar el texto IOS desde la base (respeta RLS: requiere sesión) ---- */
CREATE OR REPLACE FUNCTION infra.generar_config_acl(p_router uuid, p_version text)
RETURNS text LANGUAGE sql STABLE
SET search_path = infra, pg_temp
AS $$
    WITH base AS (SELECT * FROM infra.acls WHERE id_router = p_router AND version = p_version),
    lineas AS (
        SELECT 1 AS grp, a.nombre AS clave, r.secuencia AS seq,
               'access-list ' || a.nombre || ' ' || r.accion || ' ' || r.condicion AS linea
          FROM base a JOIN infra.acl_reglas r USING (id_acl) WHERE a.numerada
        UNION ALL
        SELECT 2, a.nombre, 0, 'ip access-list ' || CASE a.tipo WHEN 'estandar' THEN 'standard ' ELSE 'extended ' END || a.nombre
          FROM base a WHERE NOT a.numerada
        UNION ALL
        SELECT 2, a.nombre, r.secuencia, ' ' || r.accion || ' ' || r.condicion
          FROM base a JOIN infra.acl_reglas r USING (id_acl) WHERE NOT a.numerada
        UNION ALL
        SELECT 3, ap.interfaz, 0, 'interface ' || ap.interfaz
          FROM base a JOIN infra.acl_aplicaciones ap USING (id_acl) GROUP BY ap.interfaz
        UNION ALL
        SELECT 3, ap.interfaz, 1 + row_number() OVER (PARTITION BY ap.interfaz ORDER BY ap.sentido), ' ip access-group ' || a.nombre || ' ' || ap.sentido
          FROM base a JOIN infra.acl_aplicaciones ap USING (id_acl)
    )
    SELECT string_agg(linea, E'\n' ORDER BY grp, clave, seq) FROM lineas
    WHERE infra.rol_actual() IS NOT NULL;
$$;

/* ---- Row Level Security: misma política que el inventario ---- */
DO $$
DECLARE t text;
BEGIN
    FOREACH t IN ARRAY ARRAY['politicas_seguridad','acls','acl_reglas','acl_aplicaciones','pruebas_conectividad']
    LOOP
        EXECUTE format('ALTER TABLE infra.%I ENABLE ROW LEVEL SECURITY', t);
        EXECUTE format('DROP POLICY IF EXISTS p_lectura  ON infra.%I', t);
        EXECUTE format('DROP POLICY IF EXISTS p_admin    ON infra.%I', t);
        EXECUTE format('DROP POLICY IF EXISTS p_reportes ON infra.%I', t);
        EXECUTE format('CREATE POLICY p_lectura  ON infra.%I FOR SELECT TO rol_app USING (infra.rol_actual() IS NOT NULL)', t);
        EXECUTE format('CREATE POLICY p_admin    ON infra.%I FOR ALL TO rol_app
                        USING (infra.rol_actual() = ''administrador'') WITH CHECK (infra.rol_actual() = ''administrador'')', t);
        EXECUTE format('CREATE POLICY p_reportes ON infra.%I FOR SELECT TO rol_lectura USING (true)', t);
    END LOOP;
END
$$;
-- El técnico puede REGISTRAR pruebas (evidencia), no modificar políticas ni ACL.
DROP POLICY IF EXISTS p_tecnico_insert ON infra.pruebas_conectividad;
CREATE POLICY p_tecnico_insert ON infra.pruebas_conectividad FOR INSERT TO rol_app
    WITH CHECK (infra.rol_actual() = 'tecnico' AND id_usuario = infra.usuario_actual());

/* ---- Permisos ---- */
GRANT SELECT, INSERT, UPDATE, DELETE ON infra.politicas_seguridad, infra.acls, infra.acl_reglas,
      infra.acl_aplicaciones, infra.pruebas_conectividad TO rol_app;
GRANT SELECT ON infra.v_acl_postura, infra.v_pruebas_resumen TO rol_app;
GRANT EXECUTE ON FUNCTION infra.generar_config_acl(uuid, text) TO rol_app;
GRANT SELECT ON infra.politicas_seguridad, infra.acls, infra.acl_reglas, infra.acl_aplicaciones,
                infra.pruebas_conectividad TO rol_lectura;

COMMENT ON TABLE infra.acls IS 'ACL de los routers, por versión: v1_informe (práctica) o v2_default_deny (propuesta).';
COMMENT ON TABLE infra.pruebas_conectividad IS 'Resultados de pruebas ping/TCP: esperado vs obtenido, desde Packet Tracer o desde el simulador.';
COMMENT ON VIEW  infra.v_acl_postura IS 'Marca las ACL que terminan en permit any (permitir por defecto).';

COMMIT;
