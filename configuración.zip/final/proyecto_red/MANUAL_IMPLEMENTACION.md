# Manual de implementación — Red de la Municipalidad de Alto Selva Alegre

Base de datos PostgreSQL + API segura + herramientas de ACL con denegación por defecto + copias de seguridad.
Pensado para **Windows 10/11 con PowerShell**. Cada comando de PostgreSQL, Node y del simulador de ACL se probó en
Linux con los mismos archivos; los comandos propios de Windows (PowerShell, BitLocker, tareas programadas) siguen
la documentación estándar pero **no se ejecutaron en Windows**: pruébalos primero en un equipo de laboratorio.

---

## 0. Qué incluye y cuánto toma
| Parte | Qué obtienes | Tiempo aprox. |
|---|---|---|
| 1. Base de datos | Inventario de red, usuarios con roles, auditoría, ACL y pruebas | 15 min |
| 2. API | Servicio web seguro (login, inventario, mantenimientos) | 15 min |
| 3. Pruebas de ACL | Simulador que ejecuta tu Tabla 16 y la propuesta por defecto | 5 min |
| 4. Packet Tracer | Aplicar y probar la v2 en tus routers | 30 min |
| 5. Copias de seguridad | Backup cifrado y prueba de restauración | 20 min |
| 6. Seguridad del equipo | Verificaciones de la PC/servidor | 15 min |

## 1. Requisitos
Instala una sola vez (PowerShell):
```powershell
winget install PostgreSQL.PostgreSQL.16      # anota la contraseña que definas para el usuario "postgres"
winget install OpenJS.NodeJS.LTS             # Node 20 o superior
winget install GnuPG.Gpg4win                 # solo para las copias de seguridad
```
Cierra y abre PowerShell. Comprueba:
```powershell
$env:Path += ";C:\Program Files\PostgreSQL\16\bin"
psql --version ; node -v ; gpg --version | Select-Object -First 1
```
Debes ver `psql ... 16.x`, `v20` o superior y la versión de GnuPG. Si `psql` no se reconoce, la carpeta de PostgreSQL es otra: ajústala.

> Cada vez que abras una PowerShell nueva repite la línea `$env:Path += ...` (o agrégala de forma permanente en *Variables de entorno*).

**Para no escribir la contraseña de `postgres` en cada comando**, crea el archivo de contraseñas (solo tu usuario puede leerlo):
```powershell
New-Item -ItemType Directory -Force "$env:APPDATA\postgresql" | Out-Null
"localhost:5432:*:postgres:TU_CONTRASEÑA_DE_POSTGRES" | Set-Content "$env:APPDATA\postgresql\pgpass.conf" -Encoding ascii
```
Nunca guardes contraseñas dentro de los `.sql`, `.js` ni en Git.

## 2. Preparar la carpeta
Descomprime el ZIP en `C:\proyecto_red`. Debe quedar así:
```
C:\proyecto_red\
├── MANUAL_IMPLEMENTACION.md   (este archivo)
├── bd\        esquema y datos (.sql)
├── api\       servicio web (server.js)
├── acl\       simulador y configuraciones de routers
├── scripts\   copias de seguridad
└── docs\      guía de seguridad
```
Si el ZIP viene bloqueado por Windows: clic derecho → Propiedades → *Desbloquear*, antes de descomprimir.

## 3. Base de datos

### 3.1 Crear la base y cargar todo (orden obligatorio)
```powershell
cd C:\proyecto_red\bd
psql -U postgres -c "CREATE DATABASE infra_red_db;"
$orden = "infra_red_schema_seguro","seed_datos_municipalidad","infra_red_acl_extension","seed_acl_informe","seed_acl_reglas","seed_pruebas_simulador"
foreach ($f in $orden) { Write-Host "== $f"; psql -U postgres -d infra_red_db -v ON_ERROR_STOP=1 -q -f "$f.sql"; if ($LASTEXITCODE -ne 0) { Write-Host "FALLÓ $f" -ForegroundColor Red; break } }
```
Si algún archivo falla, el bucle se detiene en ese archivo y no deja nada a medias (cada uno corre en una transacción). Todos son **re-ejecutables**.

### 3.2 Verificar
```powershell
psql -U postgres -d infra_red_db -Atc "SELECT 'dispositivos='||count(*) FROM infra.dispositivos UNION ALL SELECT 'subredes='||count(*) FROM infra.subredes UNION ALL SELECT 'acls='||count(*) FROM infra.acls UNION ALL SELECT 'reglas='||count(*) FROM infra.acl_reglas UNION ALL SELECT 'pruebas='||count(*) FROM infra.pruebas_conectividad"
```
Resultado esperado: `dispositivos=15`, `subredes=8`, `acls=16`, `reglas=127`, `pruebas=55`.

### 3.3 Crear el primer administrador
Usa una *here-string* con comillas simples para que PowerShell no interprete símbolos como `$` de tu contraseña:
```powershell
$sql = @'
SELECT infra.registrar_usuario('Tu Nombre', 'tu_correo@dominio.pe', 'Cambia-Esta-Clave-2026!', 'administrador');
'@
$sql | psql -U postgres -d infra_red_db -At
```
**`Cambia-Esta-Clave-2026!` es solo un ejemplo: reemplázala por una contraseña propia y única** (usa solo letras sin tilde, números y símbolos; evita la letra Ñ y el símbolo `$` por la codificación de la consola). La contraseña exige 12+ caracteres con mayúscula, minúscula, número y símbolo, y máximo 72 bytes; si no cumple, la base responde `La contraseña debe incluir...` y no crea el usuario. Si todo va bien devuelve un UUID. **No hay registro público**: el resto de usuarios los crea un administrador desde la API (sección 4.4).

### 3.4 Crear la cuenta de la API (sin superusuario)
```powershell
$b = New-Object byte[] 32; [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b)
$pw = ($b | ForEach-Object { $_.ToString('x2') }) -join ''
$sql = "CREATE ROLE app_backend LOGIN PASSWORD '$pw' IN ROLE rol_app CONNECTION LIMIT 20; ALTER ROLE app_backend SET statement_timeout='5s'; ALTER ROLE app_backend SET idle_in_transaction_session_timeout='15s';"
$sql | psql -U postgres -d infra_red_db
```
Deja abierta esta ventana: `$pw` se usa en el paso 4.1. Si `app_backend` ya existía: `ALTER ROLE app_backend PASSWORD '$pw';`.

### 3.5 Roles de la base
| Rol de BD | Quién lo usa | Qué puede |
|---|---|---|
| `postgres` | solo tú, para instalar y respaldar | todo |
| `rol_app` (`app_backend`) | la API | lo que permite su rol de aplicación (ver 4.3); jamás lee `usuarios`, `sesiones` ni `auditoria` |
| `rol_lectura` | reportes (opcional) | solo leer inventario |

Cuenta de reportes opcional: `CREATE ROLE reportes LOGIN PASSWORD '<generada>' IN ROLE rol_lectura CONNECTION LIMIT 5;`

## 4. API

### 4.1 Instalar y configurar
```powershell
cd C:\proyecto_red\api
npm ci
@"
DATABASE_URL=postgres://app_backend:$pw@localhost:5432/infra_red_db
ALLOWED_ORIGINS=http://localhost:5173
NODE_ENV=development
PORT=3000
"@ | Set-Content .env -Encoding ascii
node --env-file=.env server.js
```
Debe mostrar `API en 127.0.0.1:3000`. Déjala corriendo y abre **otra** PowerShell para probar. `.env` ya está en `.gitignore`: no lo compartas.

### 4.2 Probar el login
```powershell
$u = "http://127.0.0.1:3000"; $s = New-Object Microsoft.PowerShell.Commands.WebRequestSession
Invoke-RestMethod -Method Post "$u/auth/login" -ContentType 'application/json' -WebSession $s `
  -Body '{"email":"tu_correo@dominio.pe","contrasena":"Cambia-Esta-Clave-2026!"}'   # la misma que creaste en 3.3
Invoke-RestMethod "$u/me" -WebSession $s
Invoke-RestMethod "$u/dispositivos?tipo=servidor" -WebSession $s | Format-Table nombre, tipo, estado
Invoke-RestMethod "$u/subredes" -WebSession $s | Format-Table red, estado_diseno, capacidad_hosts, ips_registradas
```
Sin sesión (`Invoke-RestMethod "$u/dispositivos"`) debe responder **401**.

### 4.3 Roles de la aplicación
| Rol | Inventario | Mantenimientos | Usuarios | ACL y pruebas |
|---|---|---|---|---|
| `consulta` | lee | lee | — | lee |
| `tecnico` | lee | crea y edita **solo los suyos** | — | lee y registra pruebas |
| `administrador` | lee y escribe | todo | crea, cambia rol, desactiva | todo |

### 4.4 Operaciones habituales (requieren el token CSRF en toda escritura)
```powershell
$csrf = $s.Cookies.GetCookies($u)['csrf'].Value
$h = @{ 'X-CSRF-Token' = $csrf }
# Crear un técnico
Invoke-RestMethod -Method Post "$u/admin/usuarios" -ContentType 'application/json' -WebSession $s -Headers $h `
  -Body '{"nombre":"Tecnico Uno","email":"tecnico@dominio.pe","contrasena":"Otra-Clave-Larga#2026","rol":"tecnico"}'
# Registrar un dispositivo
Invoke-RestMethod -Method Post "$u/dispositivos" -ContentType 'application/json' -WebSession $s -Headers $h `
  -Body '{"nombre":"SW-PISO3-01","tipo":"switch","marca":"TP-Link","mantenimiento_cada_meses":12}'
# Programar un mantenimiento (el responsable es quien tiene la sesión)
$disp = (Invoke-RestMethod "$u/dispositivos?tipo=firewall" -WebSession $s)[0].id_dispositivo
Invoke-RestMethod -Method Post "$u/mantenimientos" -ContentType 'application/json' -WebSession $s -Headers $h `
  -Body "{`"id_dispositivo`":`"$disp`",`"descripcion`":`"Revision anual del firewall`",`"fecha_programada`":`"2026-12-01`"}"
Invoke-RestMethod "$u/mantenimientos/proximos" -WebSession $s | Format-Table
```
`mantenimientos/proximos` sale **vacío al inicio**: calcula el próximo mantenimiento desde la fecha de instalación o desde el último completado, y los equipos del Diario aún no tienen ninguno de los dos. Se llena al completar un mantenimiento (`PATCH /mantenimientos/:id` con `estado` y `fecha_realizada`) o al registrar `fecha_instalacion`.

Un `403` significa que tu rol no permite esa acción; un `400`, que los datos no cumplen las validaciones.

Endpoints: `POST /auth/login`, `POST /auth/logout`, `POST /auth/cambiar-contrasena`, `GET /me`, `GET|POST /dispositivos`, `GET /dispositivos/:id`, `GET /vlans`, `GET /subredes`, `GET|POST /mantenimientos`, `PATCH /mantenimientos/:id`, `GET /mantenimientos/proximos`, `GET|POST /admin/usuarios`.

### 4.5 Pasar a producción (checklist)
- [ ] `NODE_ENV=production` y `ALLOWED_ORIGINS=https://tu-dominio` (solo orígenes reales).
- [ ] La API escucha en `127.0.0.1`: ponla detrás de Nginx, Caddy o IIS con **TLS** (certificado válido) y define `TRUST_PROXY=1`.
- [ ] `PGSSL=1` y `ssl = on` en PostgreSQL si la API y la base están en equipos distintos.
- [ ] PostgreSQL con `listen_addresses = 'localhost'` (o IP privada), `password_encryption = scram-sha-256`, sin entradas `trust` en `pg_hba.conf`.
- [ ] Firewall: el puerto 5432 solo desde el equipo de la API; el 3000 no se expone.
- [ ] MFA para administradores (no incluido; ver `docs/guia_seguridad.md`).
- [ ] Programar limpieza diaria: `SELECT infra.limpieza_periodica();` (sesiones y contadores caducados).

## 5. ACL y perímetro con denegación por defecto

### 5.1 Ejecutar las pruebas
```powershell
cd C:\proyecto_red\acl
node probar_acls.js
```
Debe terminar con **`RESULTADO: TODAS LAS PRUEBAS ESPERADAS PASARON`**. La salida tiene cuatro bloques:
A) tu Tabla 16 contra el Anexo A (11/11), B) hallazgos adicionales, C) las 385 combinaciones origen × destino × servicio, D) perímetro, DHCP y HSRP; y al final la comparación v1 (73,2 % permitido) contra v2 (9,4 %).

### 5.2 Cambiar una política y regenerar
1. Edita la matriz `FLUJOS` en `politicas.js` (qué origen puede llegar a qué destino y con qué servicio; lo demás se deniega).
2. `node generar_config.js` → reescribe `config\R1_v2_migracion.cfg` y `R1B_v2_migracion.cfg`.
3. `node probar_acls.js` → comprueba que sigue todo correcto.
4. `node plan_pt.js` → regenera `plan_pruebas_packet_tracer.md`.

### 5.3 Guardar las ACL en la base de datos
Tras cambiar ACL, regenera los SQL y cárgalos:
```powershell
cd C:\proyecto_red\acl
node cfg_a_sql.js R1-FORTINET v2_default_deny config\R1_v2_migracion.cfg | psql -U postgres -d infra_red_db -v ON_ERROR_STOP=1 -q
node cfg_a_sql.js R1B v2_default_deny config\R1B_v2_migracion.cfg | psql -U postgres -d infra_red_db -v ON_ERROR_STOP=1 -q
node probar_acls.js --sql seed_pruebas_nuevas.sql | Out-Null ; psql -U postgres -d infra_red_db -v ON_ERROR_STOP=1 -q -f seed_pruebas_nuevas.sql
psql -U postgres -d infra_red_db -c "SELECT router, version, acl, postura FROM infra.v_acl_postura ORDER BY version, router, acl;"
```
`postura` debe decir **DENEGAR por defecto** en todas las ACL `FW_IN_*` de la v2 y **PERMITIR por defecto** en las del informe (v1). Para ver el texto IOS que guarda la base se usa `infra.generar_config_acl(router, versión)` con una sesión de la aplicación.

## 6. Aplicar y probar en Cisco Packet Tracer
1. Abre tu proyecto `TO-BE-ACTUAL-ACL.pkt` y **guárdalo con otro nombre** (`TO-BE-ACL-v2.pkt`): la v1 es la que entregas en la práctica.
2. En R1 (Fortinet) y R1B: `enable` → `copy running-config startup-config` (respaldo).
3. Entra por la **consola** de R1, `configure terminal` y pega el contenido de `acl\config\R1_v2_migracion.cfg`. Luego haz lo mismo en R1B con `R1B_v2_migracion.cfg`.
4. Verifica la sintaxis: `show access-lists` debe listar `FW_IN_VLAN10_SERVERS`, `FW_IN_VLAN20_PRINTERS`, `FW_IN_VLAN30_AREA_X`, `FW_IN_VLAN40_AREA_Y`, `FW_IN_VLAN99_MGMT`, `FW_IN_R1B_LINK` y `FW_IN_PERIMETRO`; `show ip interface GigabitEthernet0/2.30` debe indicar `Inbound access list is FW_IN_VLAN30_AREA_X`.
5. **Primero prueba DHCP**: en PC1 y PC7, *Desktop → IP Configuration → DHCP* (o `ipconfig /renew`). Si no obtienen IP, revisa la regla DHCP de esa VLAN.
6. Ejecuta las pruebas de `acl\plan_pruebas_packet_tracer.md` y anota "obtenido". Compara con la columna v2.
7. Tras las pruebas: `show access-lists` y mira los contadores `matches`; la regla `deny ip any any log` acumula los intentos bloqueados.
8. Si algo falla y no entiendes por qué, restaura: `reload` sin guardar vuelve a la configuración respaldada.

**Adapta antes de aplicar:** si en tu proyecto `G0/1` no es el enlace a R1B o `G0/0` no es el del ISP, cambia los nombres en `generar_config.js` y vuelve a generar. En PT, `established`, `echo-reply` y `log` dependen de la versión: si algún comando da error, avísame con el mensaje exacto.

## 7. Copias de seguridad

### 7.1 Preparar la clave de cifrado (una vez)
```powershell
gpg --quick-gen-key "backup@red.local" default default 2y
gpg --export-secret-keys --armor backup@red.local | Set-Content C:\clave_privada_backup.asc
```
Guarda `clave_privada_backup.asc` y su frase de paso **fuera de esta PC** (USB cifrado o caja fuerte) y bórrala del disco. Sin ella no se podrá restaurar.

### 7.2 Crear una copia
```powershell
powershell -ExecutionPolicy Bypass -File C:\proyecto_red\scripts\backup.ps1 -Destinatario backup@red.local
```
Genera `C:\backups\infra_red_db_AAAAMMDD_HHMMSS.dump.gpg` con su `.sha256` y rota las de más de 30 días.

### 7.3 Probar la restauración (hazlo al menos una vez al trimestre)
```powershell
powershell -ExecutionPolicy Bypass -File C:\proyecto_red\scripts\probar_restauracion.ps1
```
Debe terminar con `OK: la copia ... se restauró correctamente` y las cantidades de filas. **Una copia que nunca restauraste no es una copia.**
En un servidor nuevo crea antes los roles: `CREATE ROLE rol_app NOLOGIN; CREATE ROLE rol_lectura NOLOGIN;`, y luego recrea `app_backend` (sección 3.4).

### 7.4 Programarla (como administrador)
```powershell
schtasks /create /tn "BackupInfraRed" /tr "powershell -NoProfile -ExecutionPolicy Bypass -File C:\proyecto_red\scripts\backup.ps1 -Destinatario backup@red.local" /sc daily /st 02:00
```
Mantén una copia **fuera del equipo** (otro disco o nube cifrada) y otra desconectada.

## 8. Seguridad del equipo (solo consulta; no cambia nada)
Como administrador:
```powershell
manage-bde -status C:                                           # BitLocker: "Protection On"
Get-MpComputerStatus | Select RealTimeProtectionEnabled, AntivirusSignatureLastUpdated
Get-HotFix | Sort InstalledOn -Descending | Select -First 5     # últimos parches
Get-LocalGroupMember Administrators                              # ¿quién es administrador local?
Get-NetFirewallProfile | Select Name, Enabled                    # firewall activo
Get-NetTCPConnection -LocalPort 5432 -State Listen | Select LocalAddress   # debe ser 127.0.0.1 o ::1, no 0.0.0.0
```
Los pasos para corregir lo que no cumpla (cifrado, parches, EDR, USB, privilegios) están en `docs\guia_seguridad.md`, Parte C.

## 9. Problemas frecuentes
| Síntoma | Causa y solución |
|---|---|
| `psql no se reconoce` | Falta el PATH: `$env:Path += ";C:\Program Files\PostgreSQL\16\bin"` |
| `password authentication failed for user "postgres"` | Contraseña distinta a la definida al instalar; revisa `pgpass.conf` |
| `permission denied to create extension` | Ejecutaste con otro usuario; usa `-U postgres` |
| `role "rol_app" does not exist` | `infra_red_schema_seguro.sql` no terminó; vuelve a ejecutarlo antes que los demás |
| Un SQL falla a la mitad | Corre en una transacción: no queda nada a medias. Corrige y repite el mismo archivo |
| `role "app_backend" already exists` | `ALTER ROLE app_backend PASSWORD '...'` y actualiza `.env` |
| `Falta DATABASE_URL` | Arrancaste sin `--env-file=.env` o estás en otra carpeta |
| `EADDRINUSE` | Puerto ocupado: cambia `PORT` en `.env` y la URL de prueba |
| `npm` bloqueado | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |
| Login responde 429 | Pasaste el límite (10 intentos por correo en 15 min); espera o revisa que no sea un ataque |
| Cuenta bloqueada | 5 fallos = 15 min de bloqueo automático |
| `403 Permiso denegado` | Tu rol de aplicación no permite esa acción (ver 4.3) |
| `/me` da 401 tras el login | Falta `-WebSession $s` en esa llamada, o la sesión caducó (30 min de inactividad) |
| `probar_acls.js` falla con `Token no soportado` | Una ACL usa una palabra que el simulador no conoce; avísame con la línea |
| En PT: `% Invalid input detected` | Esa versión no admite el comando; comparte la línea y la adapto |
| Los PC pierden IP tras aplicar la v2 | Falta la regla DHCP en esa VLAN o `G0/0`/`G0/1` no coinciden con tu proyecto |

## 10. Lista de verificación final
- [ ] Sección 3.2: `dispositivos=15 subredes=8 acls=16 reglas=127 pruebas=55`.
- [ ] Sección 3.3: administrador creado; el login por la API funciona.
- [ ] Sección 4.2: sin sesión devuelve 401; un `consulta` no puede crear dispositivos (403).
- [ ] Sección 5.1: `TODAS LAS PRUEBAS ESPERADAS PASARON`.
- [ ] Sección 6: la v2 aplicada en PT y las pruebas del plan con el resultado esperado.
- [ ] Sección 7.3: restauración de prueba exitosa.
- [ ] Sección 4.5 completa antes de exponer nada a una red real.
- [ ] Contraseñas fuera de Git y de los documentos del informe (el informe del Diario publica la contraseña de VTP: cámbiala y retírala).

## 11. Mapa de archivos
| Archivo | Para qué sirve |
|---|---|
| `bd/infra_red_schema_seguro.sql` | Esquema, seguridad, roles, RLS, auditoría |
| `bd/seed_datos_municipalidad.sql` | Datos del Diario de Ingeniería (sedes, VLAN, subredes, dispositivos) |
| `bd/infra_red_acl_extension.sql` | Tablas de políticas, ACL, reglas y pruebas |
| `bd/seed_acl_informe.sql` | Routers, políticas P1–P8 y la Tabla 16 |
| `bd/seed_acl_reglas.sql` | ACL v1 (informe) y v2 (por defecto) |
| `bd/seed_pruebas_simulador.sql` | Resultados del simulador |
| `api/server.js` | API segura |
| `acl/politicas.js` | Matriz de políticas (fuente única) |
| `acl/simulador.js`, `topologia.js` | Motor de ACL y red del informe |
| `acl/generar_config.js` | Genera la configuración v2 |
| `acl/probar_acls.js` | Pruebas |
| `acl/plan_pt.js`, `plan_pruebas_packet_tracer.md` | Plan de pruebas manual |
| `acl/config/*.cfg` | Configuraciones de R1 y R1B (v1 y v2) |
| `scripts/backup.ps1`, `probar_restauracion.ps1`, `backup_postgres.sh` | Copias de seguridad (Windows / Linux) |
| `docs/guia_seguridad.md` | Guía de seguridad completa y hallazgos del informe |
