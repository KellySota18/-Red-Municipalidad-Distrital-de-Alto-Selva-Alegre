# backup.ps1 - Copia de seguridad CIFRADA de infra_red_db en Windows.
# Requisitos: PostgreSQL 16 (pg_dump) y Gpg4win (gpg) instalados; clave PÚBLICA GPG importada.
# Credenciales: usa %APPDATA%\postgresql\pgpass.conf; nada de contraseñas en este archivo.
# Uso:  powershell -ExecutionPolicy Bypass -File backup.ps1 -Destinatario backup@red.local
# NOTA: escrito para Windows pero NO probado en Windows (la versión Linux backup_postgres.sh sí se probó).
param(
  [string]$Bd = 'infra_red_db',
  [string]$Destino = 'C:\backups',                 # sin espacios en la ruta
  [Parameter(Mandatory = $true)][string]$Destinatario,
  [string]$Usuario = 'postgres',
  [int]$RetencionDias = 30
)
$ErrorActionPreference = 'Stop'
$env:Path += ';C:\Program Files\PostgreSQL\16\bin'
New-Item -ItemType Directory -Force $Destino | Out-Null
$archivo = Join-Path $Destino ("{0}_{1}.dump.gpg" -f $Bd, (Get-Date -Format 'yyyyMMdd_HHmmss'))

# El volcado se cifra en la tubería: nunca queda en claro en el disco.
cmd /c "pg_dump -U $Usuario -Fc $Bd | gpg --batch --yes --trust-model always --encrypt --recipient $Destinatario --output $archivo"
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $archivo) -or (Get-Item $archivo).Length -eq 0) {
  if (Test-Path $archivo) { Remove-Item $archivo }
  throw 'Copia de seguridad fallida (revisa credenciales, clave GPG y que PostgreSQL esté activo).'
}
(Get-FileHash $archivo -Algorithm SHA256).Hash | Set-Content "$archivo.sha256"

# Rotación
Get-ChildItem $Destino -Filter "${Bd}_*" |
  Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-$RetencionDias) } | Remove-Item -Force
Write-Host "OK: $archivo ($([math]::Round((Get-Item $archivo).Length/1KB)) KB)"
