# probar_restauracion.ps1 - Restaura la ÚLTIMA copia en una base temporal y cuenta filas. Luego la elimina.
# Requiere la clave PRIVADA GPG en este equipo. NO probado en Windows (equivalente Linux sí probado).
# En un servidor NUEVO, crea antes los roles del clúster:  CREATE ROLE rol_app NOLOGIN; CREATE ROLE rol_lectura NOLOGIN;
param([string]$Destino = 'C:\backups', [string]$Usuario = 'postgres')
$ErrorActionPreference = 'Stop'
$env:Path += ';C:\Program Files\PostgreSQL\16\bin'
$ultima = Get-ChildItem "$Destino\*.dump.gpg" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $ultima) { throw 'No hay copias en ' + $Destino }
$hashGuardado = (Get-Content "$($ultima.FullName).sha256").Trim()
if ((Get-FileHash $ultima.FullName -Algorithm SHA256).Hash -ne $hashGuardado) { throw 'El checksum NO coincide: copia alterada o dañada.' }
$tmp = "$Destino\restauracion_temporal.dump"; $bd = 'infra_prueba_restauracion'
try {
  gpg --batch --yes --output $tmp --decrypt $ultima.FullName
  createdb -U $Usuario $bd
  pg_restore -U $Usuario -d $bd --no-owner --exit-on-error $tmp
  psql -U $Usuario -d $bd -Atc "SELECT 'usuarios='||count(*) FROM infra.usuarios UNION ALL SELECT 'dispositivos='||count(*) FROM infra.dispositivos UNION ALL SELECT 'acls='||count(*) FROM infra.acls UNION ALL SELECT 'mantenimientos='||count(*) FROM infra.mantenimientos"
  Write-Host "OK: la copia $($ultima.Name) se restauró correctamente"
} finally {
  dropdb -U $Usuario --if-exists $bd
  if (Test-Path $tmp) { Remove-Item $tmp -Force }
}
