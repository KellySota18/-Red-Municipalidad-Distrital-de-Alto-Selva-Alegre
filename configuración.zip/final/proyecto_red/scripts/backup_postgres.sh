#!/usr/bin/env bash
# backup_postgres.sh - Copia de seguridad CIFRADA de PostgreSQL con verificación y rotación.
#
# Uso:    ./backup_postgres.sh backup     # crea, cifra y verifica una copia
#         ./backup_postgres.sh prueba     # restaura la última copia en una BD temporal y comprueba
#         ./backup_postgres.sh rotar      # borra copias más antiguas que RETENCION_DIAS
#
# Requisitos: pg_dump, pg_restore, gpg, sha256sum.
# Credenciales: usa ~/.pgpass (chmod 600) o variables PG* del entorno; NADA hardcodeado aquí.
# Cifrado: clave PÚBLICA GPG. La clave privada se guarda OFFLINE (otro equipo/caja fuerte);
#          así un atacante que robe el servidor no puede leer las copias.
set -euo pipefail
umask 077

PGHOST="${PGHOST:-localhost}"
PGPORT="${PGPORT:-5432}"
PGUSER="${PGUSER:-postgres}"
BD="${BD:-infra_red_db}"
DESTINO="${DESTINO:-/var/backups/postgres}"
GPG_DESTINATARIO="${GPG_DESTINATARIO:?Define GPG_DESTINATARIO (email o huella de la clave pública)}"
RETENCION_DIAS="${RETENCION_DIAS:-30}"

mkdir -p "$DESTINO"

backup() {
  local sello archivo
  sello="$(date +%Y%m%d_%H%M%S)"
  archivo="$DESTINO/${BD}_${sello}.dump.gpg"

  # Formato custom (-Fc): comprimido y restaurable por partes. Se cifra en tubería:
  # el volcado en claro jamás toca el disco.
  pg_dump -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -Fc --no-password "$BD" \
    | gpg --batch --yes --trust-model always --encrypt --recipient "$GPG_DESTINATARIO" \
          --cipher-algo AES256 --output "$archivo"

  [ -s "$archivo" ] || { echo "ERROR: copia vacía" >&2; rm -f "$archivo"; exit 1; }
  sha256sum "$archivo" > "$archivo.sha256"
  echo "OK: $archivo ($(du -h "$archivo" | cut -f1))"
}

ultima() { ls -1t "$DESTINO"/${BD}_*.dump.gpg 2>/dev/null | head -n1; }

prueba() {
  # Requiere la clave privada disponible en este equipo (hazlo en el equipo de recuperación).
  local archivo tmp
  archivo="$(ultima)"; [ -n "$archivo" ] || { echo "No hay copias" >&2; exit 1; }
  sha256sum -c "$archivo.sha256"                       # integridad
  tmp="${BD}_restauracion_$$"
  createdb -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" "$tmp"
  # Comillas dobles: $tmp se expande AHORA (es local y no existirá cuando corra el trap).
  trap "dropdb -h '$PGHOST' -p '$PGPORT' -U '$PGUSER' --if-exists '$tmp'" EXIT
  gpg --batch --decrypt "$archivo" \
    | pg_restore -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$tmp" --no-owner --exit-on-error
  psql -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$tmp" -Atc \
    "SELECT 'usuarios='||count(*) FROM infra.usuarios UNION ALL
     SELECT 'dispositivos='||count(*) FROM infra.dispositivos UNION ALL
     SELECT 'subredes='||count(*) FROM infra.subredes UNION ALL
     SELECT 'mantenimientos='||count(*) FROM infra.mantenimientos;"
  echo "OK: la copia $archivo se restauró correctamente"
}

rotar() {
  find "$DESTINO" -name "${BD}_*.dump.gpg*" -mtime +"$RETENCION_DIAS" -print -delete
}

case "${1:-}" in
  backup) backup ;;
  prueba) prueba ;;
  rotar)  rotar ;;
  *) echo "Uso: $0 {backup|prueba|rotar}" >&2; exit 2 ;;
esac
