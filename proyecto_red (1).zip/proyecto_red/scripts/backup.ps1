# backup.ps1 - Copia de seguridad CIFRADA de infra_red_db en Windows.
# Requisitos: PostgreSQL 16 (pg_dump) y Gpg4win (gpg) instalados; clave PÚBLICA GPG importada.
# Credenciales: usa %APPDATA%\postgresql\pgpass.conf; nada de contraseñas en este archivo.
# Uso:  powershell -ExecutionPolicy Bypass -File backup.ps1 -Destinatario backup@red.local
# NOTA: escrito para Windows pero NO probado en Windows (la versión Linux backup_postgres.sh sí se probó).
param(
  [string]$Bd = 'infra_red_db',
  [string]$Destino = 'C:\backups',
  [Parameter(Mandatory = $true)][string]$Destinatario,
  [string]$Usuario = 'postgres',
  [int]$RetencionDias = 30
)
$ErrorActionPreference = 'Stop'
$env:Path += ';C:\Program Files\PostgreSQL\16\bin'
New-Item -ItemType Directory -Force $Destino | Out-Null
$archivo = Join-Path $Destino ("{0}_{1}.dump.gpg" -f $Bd, (Get-Date -Format 'yyyyMMdd_HHmmss'))

# El volcado se cifra en la tubería: nunca queda en claro en el disco.
$quoteArgument = {
  param([string]$Value)
  $escaped = [regex]::Replace($Value, '(\\*)"', '$1$1\"')
  $escaped = [regex]::Replace($escaped, '(\\+)$', '$1$1')
  '"' + $escaped + '"'
}

$pgDumpInfo = New-Object System.Diagnostics.ProcessStartInfo
$pgDumpInfo.FileName = 'pg_dump'
$pgDumpInfo.Arguments = "-U $(& $quoteArgument $Usuario) -Fc $(& $quoteArgument $Bd)"
$pgDumpInfo.UseShellExecute = $false
$pgDumpInfo.RedirectStandardOutput = $true
$pgDumpInfo.RedirectStandardError = $true

$gpgInfo = New-Object System.Diagnostics.ProcessStartInfo
$gpgInfo.FileName = 'gpg'
$gpgInfo.Arguments = "--batch --yes --trust-model always --encrypt --recipient $(& $quoteArgument $Destinatario) --output $(& $quoteArgument $archivo)"
$gpgInfo.UseShellExecute = $false
$gpgInfo.RedirectStandardInput = $true
$gpgInfo.RedirectStandardError = $true

$pgDump = New-Object System.Diagnostics.Process
$pgDump.StartInfo = $pgDumpInfo
$gpg = New-Object System.Diagnostics.Process
$gpg.StartInfo = $gpgInfo
$pgDumpStarted = $false
$gpgStarted = $false
try {
  if (-not $pgDump.Start()) { throw 'No se pudo iniciar pg_dump.' }
  $pgDumpStarted = $true
  if (-not $gpg.Start()) { throw 'No se pudo iniciar gpg.' }
  $gpgStarted = $true

  $pgDumpErrorTask = $pgDump.StandardError.ReadToEndAsync()
  $gpgErrorTask = $gpg.StandardError.ReadToEndAsync()
  $copyTask = $pgDump.StandardOutput.BaseStream.CopyToAsync($gpg.StandardInput.BaseStream)
  $copyTask.GetAwaiter().GetResult()
  $gpg.StandardInput.Close()
  $pgDump.WaitForExit()
  $gpg.WaitForExit()

  $pgDumpError = $pgDumpErrorTask.GetAwaiter().GetResult()
  $gpgError = $gpgErrorTask.GetAwaiter().GetResult()
  if ($pgDump.ExitCode -ne 0) { throw "pg_dump falló: $pgDumpError" }
  if ($gpg.ExitCode -ne 0) { throw "gpg falló: $gpgError" }
  if (-not (Test-Path $archivo) -or (Get-Item $archivo).Length -eq 0) {
    throw 'gpg no produjo una copia cifrada válida.'
  }
}
catch {
  if (Test-Path $archivo) { Remove-Item $archivo -Force }
  throw
}
finally {
  if ($gpgStarted -and -not $gpg.HasExited) { $gpg.Kill(); $gpg.WaitForExit() }
  if ($pgDumpStarted -and -not $pgDump.HasExited) { $pgDump.Kill(); $pgDump.WaitForExit() }
  $gpg.Dispose()
  $pgDump.Dispose()
}

(Get-FileHash $archivo -Algorithm SHA256).Hash | Set-Content "$archivo.sha256"

# Rotación
Get-ChildItem $Destino -Filter "${Bd}_*" |
  Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-$RetencionDias) } | Remove-Item -Force
Write-Host "OK: $archivo ($([math]::Round((Get-Item $archivo).Length/1KB)) KB)"
